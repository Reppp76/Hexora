import logging
import os
import time
from dataclasses import dataclass

import requests

from core.redact import redact_text

log = logging.getLogger("hexora.telegram")

API = "https://api.telegram.org"
MAX_UPLOAD = 50 * 1024 * 1024  # Bot API limit for sendDocument
RETRIES = 3


@dataclass
class Delivery:
    artifact: str
    status: str  # delivered | failed | not_configured | disabled | skipped
    detail: str = ""

    @property
    def delivered(self):
        return self.status == "delivered"


class TelegramClient:
    def __init__(self, settings, session=None, sleep=time.sleep):
        self.settings = settings
        self.session = session or requests.Session()
        self._sleep = sleep

    def config_problem(self):
        s = self.settings
        if not s.telegram_enabled:
            return "disabled", "Telegram delivery is disabled (HEXORA_TELEGRAM_ENABLED=false)."
        if not s.telegram_token:
            return "not_configured", "TELEGRAM_BOT_TOKEN is not set in .env."
        if not s.telegram_chat_id:
            return "not_configured", "TELEGRAM_CHAT_ID is not set in .env."
        return None

    def send_document(self, path, caption=""):
        name = os.path.basename(str(path))
        problem = self.config_problem()
        if problem:
            return Delivery(name, *problem)
        try:
            size = os.path.getsize(path)
        except OSError as exc:
            return Delivery(name, "failed", f"file not readable: {exc.strerror}")
        if size > MAX_UPLOAD:
            return Delivery(name, "failed", f"file is {size / 1e6:.1f} MB, above Telegram's 50 MB bot upload limit; the file was kept locally")
        url = f"{API}/bot{self.settings.telegram_token}/sendDocument"
        last = "no attempt made"
        for attempt in range(1, RETRIES + 1):
            try:
                with open(path, "rb") as fh:
                    r = self.session.post(
                        url, data={"chat_id": self.settings.telegram_chat_id, "caption": caption[:900]},
                        files={"document": (name, fh)}, timeout=self.settings.telegram_timeout,
                    )
            except requests.exceptions.RequestException as exc:
                last = f"network error ({type(exc).__name__})"
                log.warning("telegram upload attempt %d failed: %s", attempt, redact_text(str(exc)))
                self._sleep(min(2 ** attempt, 8))
                continue
            try:
                body = r.json()
            except ValueError:
                body = {}
            if r.status_code == 200 and body.get("ok") is True:
                return Delivery(name, "delivered", "confirmed by Telegram")
            desc = redact_text(str(body.get("description", f"HTTP {r.status_code}")))
            last = f"Telegram API error {r.status_code}: {desc}"
            if r.status_code == 429:
                wait = (body.get("parameters") or {}).get("retry_after", 2)
                self._sleep(min(float(wait), 30))
                continue
            if r.status_code >= 500:
                self._sleep(min(2 ** attempt, 8))
                continue
            break  # 400/401/403/404: retrying will not help
        return Delivery(name, "failed", last)
