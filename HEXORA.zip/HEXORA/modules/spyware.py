import re
from urllib.parse import urlsplit

from core.models import ModuleResult
from modules import _clientside as cs
from modules import _intel as intel
from modules._common import mk

KEY = "spyware"
TITLE = "Spyware Check"
DESCRIPTION = "Sensitive browser capabilities, collection-to-transmission correlation and destination attribution."

REF = ["https://owasp.org/www-project-web-security-testing-guide/", "https://developer.mozilla.org/docs/Web/Security/Permissions_Policy"]

VERDICT_LABEL = {
    "spyware_confirmed": "Spyware behavior confirmed", "spyware_probable": "Spyware behavior probable", "spyware_suspected": "Spyware behavior suspected",
    "no_spyware_indicators_detected": "No spyware indicators detected", "inconclusive": "Inconclusive",
}
_RISK = {"spyware_confirmed": "critical", "spyware_probable": "high", "spyware_suspected": "medium", "inconclusive": "low", "no_spyware_indicators_detected": "none"}
_SEV = {"spyware_confirmed": "critical", "spyware_probable": "high", "spyware_suspected": "medium", "inconclusive": "informational"}
_STATUS = {"spyware_confirmed": "confirmed", "spyware_probable": "probable", "spyware_suspected": "potential", "inconclusive": "inconclusive"}

# Evidence states. Only the first six can be produced by static analysis; the others need a running browser.
STATES = ["capability_detected", "permission_requested", "permission_granted_observed", "data_collection_inferred", "outbound_transmission_observed",
          "suspicious_behavior_correlated", "confirmed_malicious_behavior", "not_observed", "inconclusive"]
_RANK = {"capability_detected": 1, "permission_requested": 2, "data_collection_inferred": 3, "suspicious_behavior_correlated": 4, "confirmed_malicious_behavior": 5}

HIGH = {"credentials", "authentication_tokens", "clipboard_content", "camera_microphone", "screen_capture", "uploaded_files", "payment_card_details",
        "one_time_codes", "session_values", "keystrokes"}
MEDIUM = {"geolocation", "device_motion", "browser_fingerprint", "personal_identifiers", "form_fields"}
CATEGORY_LABEL = {"credentials": "Credentials", "authentication_tokens": "Authentication tokens", "session_values": "Session-related values",
                  "personal_identifiers": "Personal identifiers", "geolocation": "Geolocation", "clipboard_content": "Clipboard content",
                  "camera_microphone": "Camera or microphone streams", "screen_capture": "Screen capture", "uploaded_files": "Uploaded files",
                  "browser_fingerprint": "Browser fingerprinting attributes", "keystrokes": "Keystrokes / interaction events", "device_motion": "Device motion",
                  "payment_card_details": "Payment card details", "one_time_codes": "One-time codes", "form_fields": "Form field contents"}

# Page wording that explains why a capability would be needed. Used only to judge "unrelated to apparent functionality".
_CUES = {
    "geolocation": r"near(?:by| me|est)|location|store locator|find (?:a |the )?(?:store|branch|atm|outlet)|directions|weather|\bmap\b|delivery|lokasi|berdekatan|cawangan|peta",
    "camera_microphone": r"video (?:call|chat|meeting)|webcam|camera|selfie|take (?:a )?photo|scan|\bqr\b|ekyc|identity verification|microphone|voice|record|kamera|imbas|mikrofon|rakam",
    "screen_capture": r"share (?:your )?screen|screen ?share|present|kongsi skrin",
    "clipboard_content": r"\bpaste\b|\bcopy\b|clipboard|salin|tampal",
    "notifications": r"notif|subscribe|alert|breaking news|reminder|langgan|push",
    "device_motion": r"shake|tilt|compass|gyro|\bgame\b|\bar\b|\bvr\b",
    "uploaded_files": r"upload|attach|choose file|browse|muat naik",
}
_AUTO_PROMPT_WEIGHT = {"camera_microphone": 3.5, "screen_capture": 3.5, "clipboard_content": 3.0, "geolocation": 1.5, "notifications": 1.0}
CAPS = {"permission_use": 6.0, "data_flow": 8.0, "fingerprinting": 2.0, "obfuscation": 1.5, "dynamic_loading": 1.5, "persistence": 1.0, "analytics": 1.5, "threat_intelligence": 6.0}


def justified(page_text, category):
    rx = _CUES.get(category)
    return bool(rx and re.search(rx, page_text))


def _flow_weight(sensitivity, cls, relation):
    """Weight for a statically correlated flow of sensitive data to a destination."""
    if relation == "same_origin" or cls in ("first_party", "first_party_other_origin"):
        return 0.0
    benign = cls in ("analytics", "advertising", "session_replay", "payment_provider", "identity_provider", "cdn_library")
    if sensitivity == "high":
        return 2.5 if benign else 6.0 if cls in ("messaging_webhook_api", "request_capture_or_tunnel") else 5.0
    if sensitivity == "medium":
        return 1.0 if benign else 3.0
    return 0.3 if benign else 0.5


def _sensitivity(cat):
    return "high" if cat in HIGH else "medium" if cat in MEDIUM else "low"


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    corpus, analysis = cs.get_analysis(ctx)
    if not corpus.docs:
        r.status = "failed"
        r.error = corpus.errors[0] if corpus.errors else "no HTML page could be retrieved"
        r.not_performed("Spyware assessment: no page content was available.")
        return r
    net = intel.network_context(ctx)
    t = ctx.target
    page_text = " ".join(f"{d.title} {' '.join(d.headings)} {d.text}" for d in corpus.docs).lower()
    r.performed(f"Scanned {len(corpus.units)} script unit(s) and {len(corpus.docs)} page(s) for sensitive browser APIs and network calls without executing any code.")

    indicators, uncertainty = [], []

    def add(ind, category, weight, detail, resource="", **extra):
        indicators.append({"indicator": ind, "category": category, "weight": weight, "detail": detail, "resource": resource, **extra})

    # --- links: sensitive access -> network call, only where code shows a data dependency
    link_by_access = {}
    for acc, sink, how, name in analysis.links:
        link_by_access.setdefault(id(acc), []).append((sink, how, name))
    obfuscated_units = {o["resource"] for o in analysis.obfuscation}

    caps, flows, correlated = [], [], []
    seen_flow = set()
    for a in analysis.accesses:
        if a.key in ("persistent_storage", "cookie_read", "clipboard_write", "canvas_readback") and a.state == "capability_detected" and id(a) not in link_by_access:
            state_only = True
        else:
            state_only = False
        has_cue = a.category in _CUES
        just = justified(page_text, a.category)
        state = a.state
        links = link_by_access.get(id(a), [])
        weight_here = 0.0
        for sink, how, name in links:
            dest = sink.dest.get("url")
            host = (urlsplit(dest).hostname or "").lower() if dest else None
            relation = intel.origin_relation(ctx, host, urlsplit(dest).scheme, urlsplit(dest).port) if dest else "unresolved"
            cls = intel.classify_host(host, dest)[0] if dest else "unknown"
            if relation != "cross_origin" and cls == "unknown":
                cls = "first_party" if relation == "same_origin" else "first_party_other_origin"
            sens = _sensitivity(a.category)
            w = _flow_weight(sens, cls, relation) if dest else (3.0 if sens == "high" else 1.0)
            key = (a.category, dest, sink.kind, sink.unit.origin)
            state = "data_collection_inferred" if _RANK.get(state, 0) < 3 else state
            if w >= 2.5:
                state = "suspicious_behavior_correlated"
            if key not in seen_flow:
                seen_flow.add(key)
                extras = [x for x, on in (("automatic_trigger", a.trigger == "automatic_on_load"), ("not_justified_by_page", has_cue and not just),
                                          ("obfuscated_code", sink.unit.origin in obfuscated_units), ("dynamic_or_partial_destination", bool(sink.dest["dynamic"] or sink.dest["partial"])),
                                          ("capture_or_webhook_destination", cls in ("messaging_webhook_api", "request_capture_or_tunnel"))) if on]
                rec = intel.flow_record(
                    ctx, source=f"{a.label} in {a.unit.origin}:{a.line}", data_category=a.category, dest_url=dest, method=sink.method,
                    observation_type="statically_inferred" if dest else "unresolved_dynamic",
                    evidence=[f"{a.label} (line {a.line}) reaches {sink.kind}() at line {sink.line} via {how.replace('_', ' ')}" + (f" '{name}'" if name else ""),
                              cs.snippet(sink.unit.text, sink.pos, 90)],
                    confidence="low" if (not dest or sink.dest["partial"]) else "medium", page=sink.unit.origin, trigger=a.trigger,
                    extra={"sensitivity": sens, "justified_by_page": just if has_cue else None, "corroborating_indicators": extras, "link_type": how, "data_access_state": state})
                flows.append(rec)
                if w > 0:
                    add("sensitive_data_flow", "data_flow", w, f"{CATEGORY_LABEL.get(a.category, a.category)} reaches a request to {host or 'an unresolved destination'} ({cls.replace('_', ' ')})",
                        sink.unit.origin, sensitivity=sens, destination=host, destination_class=cls, extras=extras)
                    correlated.append({"sens": sens, "cls": cls, "relation": relation, "extras": extras, "host": host, "category": a.category, "w": w})
                if not dest:
                    uncertainty.append(f"{a.label} data reaches a request whose destination could not be resolved statically ({sink.unit.origin}:{sink.line}).")
            weight_here = max(weight_here, w)
        if a.key in _CAP_PROMPT_KEYS and a.state == "permission_requested":
            if a.trigger == "automatic_on_load" and not just:
                add("permission_prompt_on_load_without_context", "permission_use", _AUTO_PROMPT_WEIGHT.get(a.category, 1.0),
                    f"{a.label} permission is requested when the page loads and the page text does not explain why", a.unit.origin)
            elif a.trigger == "unknown_trigger" and not just and a.category in ("camera_microphone", "screen_capture", "clipboard_content"):
                uncertainty.append(f"{a.label} is requested at {a.unit.origin}:{a.line} and what triggers it could not be determined statically.")
        if a.key == "clipboard_read" and a.state != "capability_detected" and a.trigger == "automatic_on_load" and not just and not links:
            add("clipboard_read_on_load", "permission_use", 3.0, "Clipboard is read when the page loads", a.unit.origin)
        caps.append({
            "capability": a.key, "label": a.label, "data_category": a.category, "state": state, "resource": a.unit.origin, "line": a.line,
            "trigger": a.trigger, "justified_by_page": just if a.category in _CUES else None, "observation_basis": "static_code",
            "evidence": cs.snippet(a.unit.text, a.pos, 90), "detail": a.detail, "linked_to_network_call": bool(links), "state_only": state_only,
        })

    # --- file inputs, websockets, fingerprint cluster, persistence
    for d in corpus.docs:
        for f in d.forms:
            if any(x["type"] == "file" for x in f["fields"]):
                caps.append({"capability": "file_selection", "label": "file input", "data_category": "uploaded_files", "state": "capability_detected", "resource": d.url, "line": None,
                             "trigger": "user_gesture_handler", "justified_by_page": justified(page_text, "uploaded_files"), "observation_basis": "static_markup",
                             "evidence": "<input type=file> in a form", "detail": "user-initiated file selection", "linked_to_network_call": False, "state_only": True})
    for s in analysis.sinks:
        if s.kind == "websocket":
            caps.append({"capability": "websocket", "label": "WebSocket", "data_category": "network", "state": "capability_detected", "resource": s.unit.origin, "line": s.line,
                         "trigger": s.trigger, "justified_by_page": None, "observation_basis": "static_code", "evidence": cs.snippet(s.unit.text, s.pos, 80),
                         "detail": s.dest.get("url") or "dynamic destination", "linked_to_network_call": False, "state_only": True})
    fp = analysis.fingerprints
    strong = [k for k, v in fp.items() if v["strong"]]
    if len(strong) >= 3 or (len(fp) >= 5 and len(strong) >= 2):
        add("fingerprinting_cluster", "fingerprinting", 2.0, f"{len(fp)} fingerprinting-related APIs used together ({', '.join(sorted(fp)[:6])})", next(iter(fp.values()))["resource"])
        for k, v in list(fp.items())[:6]:
            caps.append({"capability": f"fingerprint:{k}", "label": k.replace("_", " "), "data_category": "browser_fingerprint", "state": "data_collection_inferred", "resource": v["resource"],
                         "line": v["line"], "trigger": "unknown_trigger", "justified_by_page": None, "observation_basis": "static_code", "evidence": v["evidence"],
                         "detail": "part of a fingerprinting cluster; co-location is not proof of transmission", "linked_to_network_call": False, "state_only": False})
    elif fp:
        for k, v in list(fp.items())[:6]:
            caps.append({"capability": f"fingerprint:{k}", "label": k.replace("_", " "), "data_category": "browser_fingerprint", "state": "capability_detected", "resource": v["resource"],
                         "line": v["line"], "trigger": "unknown_trigger", "justified_by_page": None, "observation_basis": "static_code", "evidence": v["evidence"],
                         "detail": "isolated API reference", "linked_to_network_call": False, "state_only": True})
    sw = [a for a in analysis.accesses if a.key == "service_worker" and a.state == "permission_requested" or (a.key == "service_worker" and a.detail == "call")]
    persist = [a for a in analysis.accesses if a.key in ("background_sync",) or (a.key == "notifications" and a.detail == "call")]
    if sw and persist:
        add("service_worker_with_background_activity", "persistence", 1.0, "A service worker is registered together with push or background-sync code", sw[0].unit.origin)

    # --- obfuscation, dynamic loading, third-party scripts, replay SDKs
    if analysis.obfuscation:
        o = analysis.obfuscation[0]
        add("obfuscated_code", "obfuscation", 1.5, f"{o['technique'].replace('_', ' ')} in {o['resource']}", o["resource"])
        uncertainty.append("Obfuscated code could not be fully analysed statically; data flows inside it may be missed.")
    for dl in analysis.dynamic_loads:
        host = (urlsplit(dl["destination"]).hostname or "") if dl["destination"] else ""
        if dl["dynamic"]:
            add("script_loaded_from_computed_url", "dynamic_loading", 0.5, f"{dl['technique']} with a computed URL", dl["resource"])
            uncertainty.append(f"Code is loaded from a computed URL ({dl['resource']}:{dl['line']}); the loaded script is unknown.")
        elif host and not ctx.scope.host_in_scope(host) and intel.classify_host(host)[0] not in intel.BENIGN_SCRIPT_CLASSES:
            add("script_loaded_from_unknown_host", "dynamic_loading", 1.0, f"{dl['technique']} loads code from {host}", dl["resource"])
    ext_classes = {}
    for e in corpus.external_scripts:
        ext_classes.setdefault(intel.classify_host(e["host"])[0], []).append(e)
    for cls, items in ext_classes.items():
        if cls == "session_replay":
            add("session_replay_sdk", "analytics", 1.0, f"Session-replay SDK referenced ({', '.join(sorted({i['host'] for i in items})[:3])}); a common, disclosed product category", items[0]["page"])
        elif cls in ("analytics", "advertising"):
            add("analytics_sdk", "analytics", 0.3, f"Analytics/advertising SDK referenced ({', '.join(sorted({i['host'] for i in items})[:3])})", items[0]["page"])
    unknown_ext = [e for e in corpus.external_scripts if intel.classify_host(e["host"])[0] not in intel.BENIGN_SCRIPT_CLASSES]
    if unknown_ext:
        uncertainty.append(f"{len(unknown_ext)} third-party script(s) from unrecognised hosts were referenced but not retrieved (outside scope); their behavior is unknown.")
    if corpus.errors:
        r.limit("Some resources could not be collected: " + "; ".join(corpus.errors[:3]))

    # --- threat intelligence
    ext_hosts = [c["host"] for c in correlated if c["host"]] + [e["host"] for e in unknown_ext]
    records = intel.threat_intel(ctx, ext_hosts)
    flags = intel.intel_flags(records)
    for rec in records:
        if rec["result"] == "match":
            w = 4.0 if rec["source"] == "urlhaus" and rec["query_type"] == "url" else 3.0 if rec["source"] == "phishtank" else 2.0
            add(f"threat_intel_{rec['source']}_{rec['query_type']}", "threat_intelligence", w, rec["detail"], rec["queried"], source=rec["source"])
    r.performed("Queried public threat-intelligence sources where configured and permitted (see threat_intelligence in the report).")

    # --- verdict
    per_cat = {}
    for i in indicators:
        per_cat[i["category"]] = per_cat.get(i["category"], 0.0) + i["weight"]
    capped = {c: min(v, CAPS.get(c, 3.0)) for c, v in per_cat.items() if v > 0}
    score = round(sum(capped.values()), 2)
    off_site = [c for c in correlated if c["relation"] != "same_origin" and c["cls"] not in ("first_party", "first_party_other_origin")]
    high_unknown = [c for c in off_site if c["sens"] == "high" and c["w"] >= 5.0]
    intel_pos = flags["malware_url_listed"] or flags["malware_host_listed"] or flags["phish_listed"]
    if intel_pos and high_unknown:
        verdict = "spyware_confirmed"
    elif high_unknown and (any(c["extras"] for c in high_unknown) or score >= 8):
        verdict = "spyware_probable"
    elif score >= 3 or any(c["w"] >= 2.5 for c in off_site):
        verdict = "spyware_suspected"
    elif score >= 1.5 or uncertainty:
        verdict = "inconclusive"
    else:
        verdict = "no_spyware_indicators_detected"
    confidence = {"spyware_confirmed": "medium", "spyware_probable": "medium"}.get(verdict, "low")
    if verdict == "spyware_confirmed":
        for c in caps:
            if c["state"] == "suspicious_behavior_correlated" and c["data_category"] in HIGH:
                c["state"] = "confirmed_malicious_behavior"

    # --- capability summary (every capability class gets an explicit state)
    summary = {}
    watched = {"camera_microphone": "camera_microphone", "screen_capture": "screen_capture", "geolocation": "geolocation", "clipboard": "clipboard_content",
               "notifications": "notifications", "device_motion": "device_motion", "file_access": "uploaded_files", "persistence": "persistence",
               "browser_storage": "browser_storage", "session_values": "session_values", "keystroke_listeners": "keystrokes", "fingerprinting": "browser_fingerprint"}
    absent = "inconclusive" if unknown_ext or analysis.obfuscation else "not_observed"
    for label, cat in watched.items():
        found = [c["state"] for c in caps if c["data_category"] == cat]
        summary[label] = max(found, key=lambda s: _RANK.get(s, 0)) if found else absent

    # --- potential data categories (only where code goes beyond a bare API reference)
    cats = sorted({c["data_category"] for c in caps if c["data_category"] in CATEGORY_LABEL and _RANK.get(c["state"], 0) >= 3} |
                  {c["data_category"] for c in caps if c["data_category"] in CATEGORY_LABEL and c["state"] == "permission_requested"})

    # --- findings
    if verdict != "no_spyware_indicators_detected":
        why = [i["detail"] for i in sorted(indicators, key=lambda x: -x["weight"]) if i["weight"] > 0][:5] or uncertainty[:3]
        r.add(mk(f"Spyware assessment: {VERDICT_LABEL[verdict].lower()}", "spyware", _SEV[verdict], confidence, _STATUS[verdict], t.url,
                 f"Evidence-weighted static assessment gave '{verdict}' (score {score}). Capability references alone, permission requests alone and analytics libraries alone are not treated as spyware."
                 + (" Confirmation requires both a threat-intelligence listing and a statically correlated sensitive-data flow." if verdict == "spyware_confirmed" else ""),
                 "Visitor data may be collected or transmitted without clear awareness." if verdict != "inconclusive" else "",
                 evidence=why, remediation=_recommendations(verdict)[:3], references=REF, method="static_code_analysis", verified=False))
    done = set()
    for i in indicators:
        if i["category"] == "data_flow" and i["weight"] >= 2.5:
            k = (i["detail"])
            if k in done or len(done) >= 5:
                continue
            done.add(k)
            r.add(mk(f"{i['detail'].split(' reaches ')[0]} sent to {i.get('destination') or 'unresolved destination'}", "spyware", "high" if i["weight"] >= 5 else "medium", "medium", "potential",
                     t.url, f"{i['detail']}. The link is inferred from code (data dependency); no request was observed and the destination's operator is not established.",
                     "Sensitive data may leave the page for a party the visitor does not expect.", evidence=[i["detail"]] + [f"corroborating: {x}" for x in i.get("extras", [])],
                     remediation=["Confirm the destination is an intended, contractually covered processor.", "Remove the collection code if it is not needed."], references=REF,
                     method="static_code_analysis"))
    for i in indicators:
        if i["category"] == "permission_use":
            r.add(mk(f"Permission API used on page load: {i['indicator'].replace('_', ' ')}", "spyware", "low", "low", "potential", i["resource"], i["detail"] + ". A permission request alone is not spyware.",
                     evidence=[i["detail"]], remediation=["Request the permission only after a user action that explains the need."], references=REF, method="static_code_analysis"))
        elif i["category"] == "fingerprinting":
            r.add(mk("Browser fingerprinting techniques in page code", "spyware", "low", "low", "potential", i["resource"], i["detail"] + ". Fingerprinting is also used for fraud prevention; transmission was not shown.",
                     evidence=[i["detail"]], remediation=["Disclose and justify fingerprinting, or remove it."], references=REF, method="static_code_analysis"))
    for rec in records:
        if rec["result"] == "match":
            r.add(mk(f"Threat-intelligence listing ({rec['source']}, {rec['query_type']})", "spyware", "high", "medium", "probable", rec["queried"], rec["detail"],
                     "The target or a referenced host appears in a public threat feed.", evidence=[f"{rec['source']} at {rec['observed_at']}: {rec['detail']}"],
                     remediation=_recommendations(verdict)[:2], references=REF, method="threat_intelligence_lookup", verified=True))

    # --- destinations
    refs = {}
    for s in analysis.sinks:
        if s.dest.get("url") and not ctx.scope.host_in_scope(urlsplit(s.dest["url"]).hostname or ""):
            refs.setdefault(s.dest["url"], []).append(f"{s.kind} at {s.unit.origin}:{s.line}")
    for e in corpus.external_scripts:
        refs.setdefault(e["url"], []).append(f"script tag on {e['page']}")
    for d in corpus.docs:
        for f in d.iframes:
            if not ctx.scope.host_in_scope(urlsplit(f["src"]).hostname or ""):
                refs.setdefault(f["src"], []).append(("hidden " if f["hidden"] else "") + f"iframe on {d.url}")
    destinations, seen_host = [], set()
    for url, by in refs.items():
        h = urlsplit(url).hostname
        if h in seen_host:
            continue
        seen_host.add(h)
        rec = intel.destination_record(ctx, url, by, records)
        if any(e["host"] == h for e in corpus.external_scripts):
            rec["observation"] = "referenced_in_source (script not retrieved)"
        destinations.append(rec)

    tests_not = [
        "Runtime browser observation: no page was rendered, so no permission prompt, grant or outbound request was observed.",
        "Request payload inspection: no data was captured or sent anywhere.",
        "Analysis of out-of-scope third-party scripts (listed, not retrieved).",
        "Reverse engineering of obfuscated code.",
        "Domain registration (WHOIS/RDAP) and hosting-ownership lookups.",
        "TLS and HTTP inspection of external destinations (outside the authorized scope; only DNS was resolved).",
    ]
    limits = [
        "Static, non-executing analysis: computed destinations, obfuscation and code in unretrieved scripts can hide behavior.",
        "The states permission_granted_observed and outbound_transmission_observed require a running browser and cannot be produced by this check.",
        "A correlation means the code shows a data dependency between collection and a network call; it does not show that a request was made.",
        "The page-purpose check compares permission use with the page's visible wording only.",
        "A missing threat-intelligence match is not evidence that the site is safe.",
        *intel.intel_limitations(records),
    ]
    if unknown_ext:
        limits.append(f"{len(unknown_ext)} third-party script(s) were referenced but not retrieved.")
    for x in tests_not:
        r.not_performed(x)
    for x in limits:
        r.limit(x)

    r.data.update({
        "verdict": verdict, "verdict_label": VERDICT_LABEL[verdict], "confidence": confidence, "risk_level": _RISK[verdict],
        "threat_category": "website spyware / suspicious data collection" if verdict != "no_spyware_indicators_detected" else None,
        "score": score, "indicator_categories": sorted(capped), "impersonated_brand": None,
        "developer_attribution": intel.developer_attribution(corpus, analysis), "kit_fingerprints": intel.kit_fingerprints(corpus, ctx.settings, "spyware"),
        "capabilities": caps[:80], "capability_summary": summary, "evidence_states": STATES,
        "data_flows": flows, "potential_data_categories": [CATEGORY_LABEL[c] for c in cats], "destinations": destinations,
        "network_observations": net, "threat_intelligence": records,
        "evidence": sorted(indicators, key=lambda x: -x["weight"]), "uncertainty": uncertainty[:8],
        "tests_performed": list(r.tests_performed), "tests_not_performed": tests_not, "limitations": limits, "recommendations": _recommendations(verdict),
    })
    return r


_CAP_PROMPT_KEYS = {"camera_microphone", "screen_capture", "geolocation", "clipboard_read", "notifications"}


def _recommendations(verdict):
    if verdict in ("spyware_confirmed", "spyware_probable", "spyware_suspected"):
        return [
            "If you own this site, review the flagged scripts and remove any collection code or third-party tag you did not intend to deploy.",
            "Check every third-party script and tag manager container for unexpected changes (supply-chain tampering).",
            "Restrict powerful features with a Permissions-Policy header and limit outbound destinations with a Content-Security-Policy connect-src.",
            "Visitors should avoid granting camera, microphone, location or clipboard permissions to this site until its behavior is explained.",
        ]
    if verdict == "inconclusive":
        return ["Review the unresolved scripts and destinations manually or in an isolated browser profile.",
                "Repeat the check with threat-intelligence keys configured (URLHAUS_AUTH_KEY, PHISHTANK_APP_KEY)."]
    return ["No spyware indicators were found by the tests that ran; this is not proof of safety."]
