from core.models import ModuleResult
from modules._common import mk

KEY = "authorization"
TITLE = "Authorization & Access Control Review"
DESCRIPTION = "Publicly reachable admin-style paths; IDOR/BOLA needs test accounts."

RESTRICTED_LOOKING = ["/admin", "/admin/", "/administrator", "/dashboard", "/manage", "/console", "/internal", "/private", "/backoffice"]
LOGIN_HINTS = ("login", "sign in", "log in", "password", "authenticate")
REF = ["https://owasp.org/Top10/A01_2021-Broken_Access_Control/"]


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    if not ctx.home().reached:
        r.status = "failed"
        r.error = ctx.home().blocked or ctx.home().error or "target unreachable"
        return r
    home_len = len(ctx.home().body)
    for p in RESTRICTED_LOOKING:
        resp = ctx.client.get(ctx.url(p), follow=False, max_bytes=100_000)
        if not resp.reached:
            continue
        if resp.status == 200 and "html" in resp.content_type and not any(h in resp.text.lower() for h in LOGIN_HINTS):
            if abs(len(resp.body) - home_len) < 20 and resp.body == ctx.home().body:
                continue  # catch-all route returning the home page
            r.add(mk(f"Admin-style path {p} is reachable without a login prompt", "authorization", "medium", "low", "potential", p,
                     "The path answered 200 with content that does not look like a login page. It may be restricted content, or a harmless public page.",
                     "If this is an administrative area, access control may be missing.",
                     [f"HTTP 200, {len(resp.body)} bytes, no login wording found"],
                     ["Require authentication and authorization on administrative routes."], REF, "unauthenticated_get", False))
    r.performed(f"Requested {len(RESTRICTED_LOOKING)} restricted-looking paths without credentials.")
    r.not_performed("IDOR/BOLA and cross-role checks: HEXORA has no authenticated test-account support, so object-level and "
                    "function-level authorization were not tested.")
    r.limit("No claim is made that authorization is secure. Verification needs two test accounts and permitted test resources.")
    return r
