import socket
import ssl
import time

from core.models import ModuleResult
from modules._common import mk

KEY = "tls"
TITLE = "TLS & Certificate Assessment"
DESCRIPTION = "Certificate validity, hostname match, protocol versions and HTTPS availability."

REF = ["https://wiki.mozilla.org/Security/Server_Side_TLS"]
_LEGACY = [("TLSv1", ssl.TLSVersion.TLSv1), ("TLSv1.1", ssl.TLSVersion.TLSv1_1)]


def _connect(host, port, ctx, timeout):
    with socket.create_connection((host, port), timeout=timeout) as sock:
        with ctx.wrap_socket(sock, server_hostname=host) as tls:
            return tls.version(), tls.cipher(), tls.getpeercert()


def _probe_legacy(host, port, version, timeout):
    """True accepted, False rejected by server, None cannot be tested locally."""
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.minimum_version = ctx.maximum_version = version
        try:
            ctx.set_ciphers("ALL:@SECLEVEL=0")
        except ssl.SSLError:
            pass
        _connect(host, port, ctx, timeout)
        return True
    except (ValueError, ssl.SSLError) as exc:
        text = str(exc).upper()
        if any(s in text for s in ("NO_PROTOCOLS_AVAILABLE", "UNSUPPORTED_PROTOCOL", "NO CIPHERS", "NO_CIPHERS", "MINIMUM_VERSION")) or isinstance(exc, ValueError):
            return None
        return False
    except OSError:
        return False


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    t = ctx.target
    if t.scheme != "https":
        r.add(mk("Target is not served over HTTPS", "tls", "medium", "high", "confirmed", "/",
                 "The target URL uses plain HTTP, so there is no TLS configuration to assess.",
                 "Traffic is not encrypted or authenticated.", [f"Target scheme: {t.scheme}"],
                 ["Serve the site over HTTPS with a valid certificate."], REF, "target_url_inspection", True))
        r.not_performed("Certificate, protocol and cipher checks: target is not HTTPS.")
        return r
    timeout = ctx.settings.request_timeout
    try:
        ctx.scope.check_url(t.url)
    except Exception as exc:
        r.status = "failed"
        r.error = str(exc)
        return r
    default = ssl.create_default_context()
    verified = False
    try:
        version, cipher, cert = _connect(t.hostname, t.port, default, timeout)
        verified = True
        r.performed(f"Completed a verified TLS handshake ({version}, cipher {cipher[0] if cipher else 'unknown'}).")
        r.data.update({"negotiated_protocol": version, "cipher": cipher[0] if cipher else None})
        try:
            expires = ssl.cert_time_to_seconds(cert["notAfter"])
            days = int((expires - time.time()) // 86400)
            r.data["certificate_days_remaining"] = days
            r.performed(f"Read certificate expiry ({days} days remaining).")
            if days < 0:
                r.add(mk("Certificate has expired", "tls", "high", "high", "confirmed", "/", "The certificate's notAfter date is in the past.",
                         "Browsers will warn or block users.", [f"Expired {-days} day(s) ago"], ["Renew the certificate."], REF, "tls_handshake", True))
            elif days < 14:
                r.add(mk("Certificate expires within 14 days", "tls", "medium", "high", "confirmed", "/", f"The certificate expires in {days} day(s).",
                         "An outage is likely if it is not renewed.", [f"{days} days remaining"], ["Renew or automate renewal."], REF, "tls_handshake", True))
            elif days < 30:
                r.add(mk("Certificate expires within 30 days", "tls", "low", "high", "confirmed", "/", f"The certificate expires in {days} day(s).",
                         "", [f"{days} days remaining"], ["Confirm renewal is automated."], REF, "tls_handshake", True))
        except (KeyError, ValueError):
            r.limit("Certificate expiry could not be parsed.")
    except ssl.SSLCertVerificationError as exc:
        reason = getattr(exc, "verify_message", str(exc))
        mismatch = "hostname" in reason.lower() or "match" in reason.lower()
        title = "Certificate hostname mismatch" if mismatch else "Certificate failed validation"
        r.performed("Attempted a verified TLS handshake.")
        r.add(mk(title, "tls", "high", "high", "confirmed", "/", f"Certificate verification failed: {reason}.",
                 "Clients cannot trust the connection; users see warnings and are exposed to interception if they proceed.",
                 [f"verify_message: {reason}"], ["Install a valid certificate chain issued for this hostname."], REF, "tls_handshake", True))
    except (ssl.SSLError, OSError) as exc:
        r.status = "partial"
        r.limit(f"TLS handshake could not be completed: {type(exc).__name__}: {exc}")
        r.not_performed("Certificate inspection: handshake failed.")
    for name, ver in _LEGACY:
        res = _probe_legacy(t.hostname, t.port, ver, timeout)
        if res is None:
            r.not_performed(f"{name} acceptance test: not supported by the local OpenSSL build, so the result is unknown.")
        elif res:
            r.performed(f"Attempted a {name}-only handshake.")
            r.add(mk(f"Server accepts deprecated {name}", "tls", "medium", "high", "confirmed", "/",
                     f"A {name}-only handshake succeeded. {name} is deprecated (RFC 8996).", "Legacy protocols have known weaknesses.",
                     [f"{name} handshake succeeded"], [f"Disable {name}; allow TLS 1.2 and 1.3."], REF, "tls_handshake", True))
        else:
            r.performed(f"Attempted a {name}-only handshake; the connection was refused (consistent with it being disabled).")
    r.not_performed("Full cipher-suite enumeration, key size analysis, OCSP stapling and certificate transparency checks.")
    r.limit("This is a basic TLS check, not a complete cryptographic audit.")
    return r
