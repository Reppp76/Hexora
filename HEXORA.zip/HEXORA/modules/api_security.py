import json

from core.models import ModuleResult
from modules._common import mk, path_of, stack_trace

KEY = "api_security"
TITLE = "API Security Assessment"
DESCRIPTION = "API discovery, exposed docs, CORS policy, data exposure and verbose errors."

DOC_PATHS = ["/openapi.json", "/swagger.json", "/swagger/v1/swagger.json", "/v2/api-docs", "/v3/api-docs",
             "/api-docs", "/api/docs", "/docs", "/redoc", "/swagger-ui/"]
SENSITIVE_KEYS = ("password", "passwd", "secret", "api_key", "apikey", "token", "ssn", "credit_card", "private_key")
ORIGIN = "https://hexora-cors-test.invalid"
REF = ["https://owasp.org/API-Security/"]


def _keys(obj, depth=0):
    if depth > 4:
        return
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield str(k).lower()
            yield from _keys(v, depth + 1)
    elif isinstance(obj, list):
        for v in obj[:20]:
            yield from _keys(v, depth + 1)


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    if not ctx.home().reached:
        r.status = "failed"
        r.error = ctx.home().blocked or ctx.home().error or "target unreachable"
        return r
    crawl = ctx.crawl()
    api_paths = sorted(p for p in crawl.js_endpoints if "{" not in p and ":" not in p)[:12]
    api_paths += [u for u in sorted(crawl.discovered) if "/api/" in u][:5]
    api_urls = [ctx.url(p) if p.startswith("/") else p for p in api_paths]
    r.data["api_candidates"] = api_urls
    r.performed(f"Collected {len(api_urls)} candidate API endpoint(s) from crawl and JavaScript.")

    for p in DOC_PATHS:
        resp = ctx.client.get(ctx.url(p), max_bytes=300_000)
        if resp.ok:
            body = resp.text[:2000].lower()
            if any(s in body for s in ('"openapi"', '"swagger"', "swagger-ui", "redoc")):
                r.add(mk("API documentation is publicly accessible", "api", "low", "high", "confirmed", p,
                         "An API specification or documentation UI is reachable without authentication.",
                         "It maps the full API surface for an attacker, including hidden endpoints.",
                         [f"HTTP {resp.status} with API documentation markers"],
                         ["Restrict documentation to authenticated users or internal networks in production."], REF,
                         "http_response_inspection", True))
                api_urls.append(ctx.url(p))
    r.performed(f"Probed {len(DOC_PATHS)} common documentation paths.")

    gql = ctx.client.get(ctx.url("/graphql?query=%7B__typename%7D"), max_bytes=100_000)
    if gql.ok and "__typename" in gql.text or (gql.ok and '"data"' in gql.text):
        r.add(mk("GraphQL endpoint is publicly reachable", "api", "informational", "medium", "confirmed", "/graphql",
                 "A GraphQL endpoint answered an unauthenticated __typename query. Introspection and authorization were not tested.",
                 "", ["HTTP 200 with GraphQL-shaped JSON"], ["Disable introspection in production; enforce per-field authorization."], REF,
                 "http_response_inspection", True))
        api_urls.append(ctx.url("/graphql"))
    r.performed("Checked for a GraphQL endpoint with a read-only __typename query.")

    seen = set()
    for url in dict.fromkeys(api_urls):
        resp = ctx.client.get(url, headers={"Origin": ORIGIN, "Accept": "application/json"}, max_bytes=300_000)
        if not resp.reached:
            continue
        res = path_of(url)
        acao = resp.headers.get("access-control-allow-origin", "")
        acac = resp.headers.get("access-control-allow-credentials", "").lower() == "true"
        if acao == ORIGIN and acac and ("cors", res) not in seen:
            seen.add(("cors", res))
            r.add(mk("CORS reflects arbitrary origins with credentials", "api", "high", "high", "confirmed", res,
                     "The endpoint echoed a made-up Origin in Access-Control-Allow-Origin and allowed credentials.",
                     "Any website a logged-in user visits could read this endpoint's responses.",
                     [f"Origin: {ORIGIN} -> Access-Control-Allow-Origin: {acao}; Allow-Credentials: true"],
                     ["Allow only an explicit list of trusted origins.", "Never combine reflected origins with credentials."], REF,
                     "cors_probe", True))
        elif acao == ORIGIN and ("cors", res) not in seen:
            seen.add(("cors", res))
            r.add(mk("CORS reflects arbitrary origins", "api", "low", "high", "confirmed", res,
                     "The endpoint echoes any Origin without allowing credentials.", "Matters if the data is non-public.",
                     [f"Access-Control-Allow-Origin: {acao}"], ["Restrict to trusted origins."], REF, "cors_probe", True))
        elif acao == "*" and ("cors", res) not in seen:
            seen.add(("cors", res))
            r.add(mk("CORS allows any origin (*)", "api", "informational", "high", "confirmed", res,
                     "A wildcard origin is acceptable for public data but not for private data.", "",
                     ["Access-Control-Allow-Origin: *"], ["Confirm this endpoint is meant to be public."], REF, "cors_probe", True))
        trace = stack_trace(resp.text)
        if trace:
            r.add(mk("API response contains implementation details", "api", "medium", "medium", "confirmed", res,
                     "The response included a stack trace or framework error markers.", "Reveals internals that help targeted attacks.",
                     [f"Marker: {trace}"], ["Return generic error bodies in production."], REF, "http_response_inspection", True))
        if resp.ok and "json" in resp.content_type:
            try:
                keys = set(_keys(json.loads(resp.text)))
            except ValueError:
                continue
            hit = sorted(k for k in keys if any(s in k for s in SENSITIVE_KEYS))
            if hit:
                r.add(mk("Unauthenticated API response contains sensitive-looking fields", "api", "medium", "medium", "potential", res,
                         "A request without credentials returned JSON with field names that suggest sensitive data. Values were not recorded.",
                         "Possible excessive data exposure.", [f"Field names: {', '.join(hit[:8])}"],
                         ["Return only the fields clients need.", "Require authentication where data is private."], REF,
                         "response_field_inspection", False))
            else:
                r.add(mk("API endpoint answers without authentication", "api", "informational", "medium", "inconclusive", res,
                         "The endpoint returned JSON to an unauthenticated request. Whether that is intended cannot be judged remotely.",
                         "", [f"HTTP {resp.status}, {resp.content_type}"], ["Confirm the endpoint is meant to be public."], REF,
                         "http_response_inspection", False))
    r.performed(f"Sent CORS and response-content checks to {len(set(api_urls))} endpoint(s).")
    r.not_performed("Authorization checks across roles and rate-limit measurement on API routes (needs test accounts / see availability module).")
    r.limit("Only unauthenticated GET requests were made. Input-validation testing of write endpoints was not performed.")
    return r
