from urllib.parse import urlsplit

from core.models import ModuleResult
from modules._common import mk

KEY = "attack_surface"
TITLE = "Attack Surface & Endpoint Discovery"
DESCRIPTION = "Bounded same-scope crawl: pages, forms, scripts, API routes, robots.txt and sitemap."


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    if not ctx.home().reached:
        r.status = "failed"
        r.error = ctx.home().blocked or ctx.home().error or "target unreachable"
        return r
    c = ctx.crawl()
    r.performed(f"Crawled up to depth {ctx.settings.crawl_depth} / {ctx.settings.crawl_max_pages} pages inside the authorized scope.")
    forms = [{"page": p.url, "action": f["action"], "method": f["method"], "fields": [i["name"] for i in f["inputs"]]}
             for p in c.pages.values() for f in p.forms]
    params = sorted({f"{urlsplit(u).path}?{urlsplit(u).query.split('=')[0]}" for u in c.discovered if urlsplit(u).query})
    r.data["inventory"] = {
        "pages": sorted(c.pages),
        "discovered_urls": sorted(c.discovered)[:300],
        "forms": forms,
        "scripts": sorted({s for p in c.pages.values() for s in p.scripts}),
        "api_routes_from_javascript": sorted(c.js_endpoints),
        "parameters": params,
        "robots_disallow": c.robots_disallow,
        "sitemap_urls": c.sitemap_urls[:200],
        "external_references": sorted(c.external)[:100],
    }
    r.performed(f"Read robots.txt ({'found' if c.robots_found else 'not found'}) and sitemap ({len(c.sitemap_urls)} URL(s)).")
    r.performed(f"Inventory: {len(c.pages)} page(s), {len(forms)} form(s), {len(c.js_endpoints)} API route(s) in JavaScript, {len(c.external)} external reference(s).")
    for d in c.robots_disallow[:20]:
        if any(w in d.lower() for w in ("admin", "backup", "private", "internal", "config", "secret")):
            r.add(mk(f"robots.txt lists a sensitive-looking path: {d}", "attack_surface", "informational", "medium", "confirmed", "/robots.txt",
                     "robots.txt asks crawlers to avoid this path, which also tells readers it exists. robots.txt is not access control.",
                     "", [f"Disallow: {d}"], ["Protect such paths with authentication instead of relying on robots.txt."], [],
                     "http_response_inspection", True))
    if c.truncated:
        r.status = "partial"
        r.limit("The crawl stopped at its depth, page or request limit, so the inventory is incomplete.")
    for e in c.errors[:10]:
        r.limit(f"Crawl note: {e}")
    r.not_performed("Subdomain enumeration, IP-range scanning and credential discovery (outside the authorized scope by design).")
    return r
