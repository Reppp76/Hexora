import re
from urllib.parse import parse_qsl, urlsplit

from core.models import ModuleResult
from modules._common import cookie_findings, mk, path_of

KEY = "authentication"
TITLE = "Authentication & Session Security"
DESCRIPTION = "Cookie flags, session data in URLs, login form transport and information disclosure."

SESSION_PARAMS = re.compile(r"^(sessionid|session_id|sid|phpsessid|jsessionid|token|access_token|auth|auth_token)$", re.I)
REF = ["https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/06-Session_Management_Testing/"]


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    home = ctx.home()
    if not home.reached:
        r.status = "failed"
        r.error = home.blocked or home.error or "target unreachable"
        return r
    crawl = ctx.crawl()
    https_site = ctx.target.scheme == "https"

    for f in cookie_findings(home, https_site):
        r.add(f)
    r.performed(f"Checked cookie attributes on the start page ({len(home.set_cookies)} cookie(s)).")

    hits = {u for u in crawl.discovered | set(crawl.pages) if any(SESSION_PARAMS.match(k) for k, _ in parse_qsl(urlsplit(u).query))}
    for u in sorted(hits)[:5]:
        names = [k for k, _ in parse_qsl(urlsplit(u).query) if SESSION_PARAMS.match(k)]
        r.add(mk("Session or token parameter appears in a URL", "authentication", "medium", "medium", "potential", path_of(u).split("?")[0],
                 f"A link carries the parameter {', '.join(names)} in its query string. Values were not recorded.",
                 "URLs leak through logs, history and Referer headers.", [f"Parameter names: {', '.join(names)}"],
                 ["Carry session identifiers in cookies, not URLs."], REF, "link_inspection", False))
    r.performed(f"Scanned {len(crawl.discovered)} discovered URL(s) for session identifiers in query strings.")

    login_forms = [(p.url, f) for p in crawl.pages.values() for f in p.forms if f["has_password"]]
    r.data["login_forms"] = [{"page": u, "action": f["action"], "method": f["method"]} for u, f in login_forms]
    for page_url, f in login_forms:
        action = urlsplit(f["action"])
        if action.scheme == "http" or (page_url.startswith("http://") and action.scheme != "https"):
            r.add(mk("Login form submits over plain HTTP", "authentication", "high", "high", "confirmed", path_of(f["action"]).split("?")[0],
                     "A form with a password field is served from or posts to an unencrypted URL.",
                     "Credentials can be read by anyone on the network path.", [f"Form action scheme: {action.scheme}"],
                     ["Serve login pages and post credentials over HTTPS only."], REF, "form_inspection", True))
        if f["method"] == "get":
            r.add(mk("Login form uses GET", "authentication", "medium", "high", "confirmed", path_of(f["action"]).split("?")[0],
                     "A password field is submitted with the GET method, which places credentials in the URL.",
                     "Credentials end up in logs and browser history.", ["Form method: get"], ["Submit credentials with POST."], REF,
                     "form_inspection", True))
    r.performed(f"Inspected {len(login_forms)} login form(s) for transport and method.")

    r.not_performed("Password-reset and account-recovery behavior (requires explicitly authorized test accounts).")
    r.not_performed("Brute force, credential stuffing and account takeover tests (never performed by HEXORA).")
    r.limit("Only unauthenticated, observable behavior was assessed. No login was attempted.")
    return r
