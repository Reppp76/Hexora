import base64
import json
import mimetypes
import re
from datetime import datetime, timezone
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup

from core.exceptions import BudgetExceeded, CollectionError
from core.scope import site_name
from reporting.html_export import wrap_page
from reporting.io import safe_filename, write_atomic

KEY = "source_collector"
TITLE = "Get Source Code"
DESCRIPTION = "Collect public client-side resources into one standalone HTML file."

_CSS_URL = re.compile(r"""url\(\s*(['"]?)(?!data:|#)([^'")]+)\1\s*\)""", re.I)
_CSS_IMPORT = re.compile(r"""@import\s+(?:url\()?\s*['"]?([^'")\s;]+)['"]?\s*\)?\s*([^;]*);""", re.I)
_DATA_LIMIT_NOTE = "exceeds per-asset size limit"


class Collector:
    def __init__(self, ctx):
        self.ctx = ctx
        self.s = ctx.settings
        self.embedded, self.failed, self.external = [], [], []
        self.total = 0
        self._cache = {}

    def _fetch(self, url, kind):
        """Fetch one in-scope asset. Returns Resp or None; records why when it fails."""
        if url in self._cache:
            return self._cache[url]
        host = urlsplit(url).hostname
        out = None
        if not self.ctx.scope.host_in_scope(host):
            self.external.append({"url": url, "type": kind, "reason": "outside authorized scope; left as an external reference"})
        elif self.total >= self.s.source_max_total_bytes:
            self.failed.append({"url": url, "type": kind, "reason": "total size limit reached"})
        else:
            resp = self.ctx.client.get(url, max_bytes=self.s.source_max_asset_bytes)
            if not resp.reached:
                self.failed.append({"url": url, "type": kind, "reason": resp.blocked or resp.error or "no response"})
            elif resp.status >= 400:
                self.failed.append({"url": url, "type": kind, "reason": f"HTTP {resp.status}"})
            elif resp.truncated:
                self.failed.append({"url": url, "type": kind, "reason": _DATA_LIMIT_NOTE})
            else:
                out = resp
                self.total += len(resp.body)
                self.embedded.append({"url": url, "type": kind, "bytes": len(resp.body)})
        self._cache[url] = out
        return out

    def data_url(self, url, kind):
        resp = self._fetch(url, kind)
        if resp is None:
            return None
        mime = resp.content_type or mimetypes.guess_type(urlsplit(url).path)[0] or "application/octet-stream"
        return f"data:{mime};base64," + base64.b64encode(resp.body).decode("ascii")

    def css(self, text, base, depth=0):
        """Inline @import rules and turn url() references into data URLs."""
        def do_import(m):
            if depth >= 3:
                return m.group(0)
            resp = self._fetch(urljoin(base, m.group(1)), "css")
            if resp is None:
                return m.group(0)
            media = m.group(2).strip()
            inner = self.css(resp.text, urljoin(base, m.group(1)), depth + 1)
            return f"@media {media} {{\n{inner}\n}}" if media else inner

        def do_url(m):
            ref = m.group(2).strip()
            target = urljoin(base, ref)
            kind = "font" if re.search(r"\.(woff2?|ttf|otf|eot)(\?|#|$)", ref, re.I) else "image"
            d = self.data_url(target, kind)
            return f"url({d})" if d else m.group(0)

        text = _CSS_IMPORT.sub(do_import, text)
        return _CSS_URL.sub(do_url, text)

    def process(self, html, page_url):
        soup = BeautifulSoup(html, "html.parser")
        base_tag = soup.find("base", href=True)
        base = urljoin(page_url, base_tag["href"]) if base_tag else page_url

        for link in soup.find_all("link", href=True):
            rel = " ".join(link.get("rel", [])).lower()
            url = urljoin(base, link["href"])
            if "stylesheet" in rel:
                resp = self._fetch(url, "css")
                if resp is not None:
                    style = soup.new_tag("style")
                    style["data-hexora-source"] = url
                    if link.get("media"):
                        style["media"] = link["media"]
                    style.string = self.css(resp.text, url).replace("</style", "<\\/style")
                    link.replace_with(style)
            elif "icon" in rel:
                d = self.data_url(url, "image")
                if d:
                    link["href"] = d
        for tag in soup.find_all("script", src=True):
            url = urljoin(base, tag["src"])
            resp = self._fetch(url, "javascript")
            if resp is None:
                continue
            script = soup.new_tag("script")
            script["data-hexora-source"] = url
            if tag.get("type"):
                script["type"] = tag["type"]
                if tag["type"].lower() == "module":
                    self.failed.append({"url": url, "type": "javascript", "reason": "ES module inlined; relative imports inside it will not resolve"})
            script.string = resp.text.replace("</script", "<\\/script")
            tag.replace_with(script)
        for img in soup.find_all("img"):
            src = img.get("src")
            if src and not src.startswith("data:"):
                d = self.data_url(urljoin(base, src), "image")
                if d:
                    img["src"] = d
                    for attr in ("srcset", "loading"):
                        img.attrs.pop(attr, None)
        for tag in soup.find_all(style=True):
            tag["style"] = self.css(tag["style"], base)
        for style in soup.find_all("style"):
            if style.string and not style.get("data-hexora-source"):
                style.string = self.css(style.string, base)
        return soup


def collect(ctx):
    """Build the standalone HTML. Returns (path, manifest) or raises CollectionError."""
    started = datetime.now(timezone.utc)
    c = Collector(ctx)
    home = ctx.home()
    if not home.reached:
        raise CollectionError(home.blocked or home.error or "the target did not respond")
    if home.status >= 400:
        raise CollectionError(f"the start page returned HTTP {home.status}")
    if "html" not in home.content_type:
        raise CollectionError(f"the start page is {home.content_type or 'not HTML'}, not an HTML document")
    try:
        main_soup = c.process(home.text, home.url)
        extra = []
        crawl = ctx.crawl()
        for url in sorted(crawl.pages):
            if len(extra) >= ctx.settings.source_max_pages - 1:
                break
            page = crawl.pages[url]
            if url == home.url or url.rstrip("/") == ctx.target.url.rstrip("/") or page.status >= 400:
                continue
            resp = ctx.client.get(url)
            if resp.ok and "html" in resp.content_type:
                extra.append((url, str(c.process(resp.text, resp.url))))
    except BudgetExceeded as exc:
        c.failed.append({"url": "*", "type": "collection", "reason": str(exc)})
        extra = []
    pages_note = [u for u, _ in extra]
    manifest = {
        "source": ctx.target.url,
        "collected_at": started.isoformat(timespec="seconds"),
        "embedded": c.embedded,
        "not_embedded": c.failed,
        "external_dependencies": c.external,
        "extra_pages": pages_note,
        "notes": [
            "Only client-side resources that the website serves publicly were collected. No backend source code is included or obtainable.",
            "Server-rendered data, API responses, authentication state, databases and third-party services are not reproduced.",
            "Collected scripts run as-is when this file is opened. Open it only in a browser you trust for that content.",
            "Behavior may differ from the live site where resources were missing, external, or dependent on the server.",
        ],
    }
    html = wrap_page(main_soup, extra, manifest)
    name = safe_filename(site_name(ctx.target.hostname), ext="html")
    path = write_atomic(ctx.settings.source_dir, name, html)
    manifest["file"] = str(path)
    manifest["size_bytes"] = path.stat().st_size
    return path, manifest
