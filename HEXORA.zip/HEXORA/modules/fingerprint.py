import re

from bs4 import BeautifulSoup

from core.models import ModuleResult
from modules._common import mk, path_of

KEY = "fingerprint"
TITLE = "Backend & Technology Fingerprinting"
DESCRIPTION = "Identify web servers, frameworks and libraries from headers, HTML and assets."

_VER = r"(\d+(?:\.\d+){0,3})"

# (name, category, where, regex, confidence, needs verification note)
HEADER_RULES = [
    ("Apache HTTP Server", "web_server", "server", re.compile(r"apache(?:/" + _VER + ")?", re.I)),
    ("nginx", "web_server", "server", re.compile(r"nginx(?:/" + _VER + ")?", re.I)),
    ("Microsoft IIS", "web_server", "server", re.compile(r"microsoft-iis(?:/" + _VER + ")?", re.I)),
    ("LiteSpeed", "web_server", "server", re.compile(r"litespeed", re.I)),
    ("Caddy", "web_server", "server", re.compile(r"caddy", re.I)),
    ("PHP", "language", "x-powered-by", re.compile(r"php(?:/" + _VER + ")?", re.I)),
    ("Express (Node.js)", "framework", "x-powered-by", re.compile(r"express", re.I)),
    ("Next.js", "framework", "x-powered-by", re.compile(r"next\.js(?:\s+" + _VER + ")?", re.I)),
    ("ASP.NET", "framework", "x-powered-by", re.compile(r"asp\.net", re.I)),
    ("ASP.NET", "framework", "x-aspnet-version", re.compile(_VER)),
    ("Phusion Passenger", "web_server", "x-powered-by", re.compile(r"phusion passenger", re.I)),
    ("Werkzeug (Python)", "web_server", "server", re.compile(r"werkzeug(?:/" + _VER + ")?", re.I)),
    ("Gunicorn (Python)", "web_server", "server", re.compile(r"gunicorn(?:/" + _VER + ")?", re.I)),
    ("Uvicorn (Python)", "web_server", "server", re.compile(r"uvicorn", re.I)),
    ("Kestrel (.NET)", "web_server", "server", re.compile(r"kestrel", re.I)),
    ("Jetty (Java)", "web_server", "server", re.compile(r"jetty(?:\(" + _VER + r"\))?", re.I)),
    ("Apache Tomcat (Java)", "web_server", "server", re.compile(r"tomcat", re.I)),
    ("Cloudflare", "cdn", "server", re.compile(r"cloudflare", re.I)),
]
COOKIE_RULES = [
    ("PHP", "language", "PHPSESSID"),
    ("ASP.NET", "framework", "ASP.NET_SessionId"),
    ("Java servlet container", "language", "JSESSIONID"),
    ("Laravel", "framework", "laravel_session"),
    ("Django", "framework", "csrftoken"),
    ("Ruby on Rails", "framework", "_rails_session"),
    ("Express (Node.js)", "framework", "connect.sid"),
]
HTML_RULES = [
    ("WordPress", "cms", re.compile(r"/wp-content/|/wp-includes/", re.I)),
    ("Next.js", "framework", re.compile(r"/_next/static/|__NEXT_DATA__", re.I)),
    ("Nuxt", "framework", re.compile(r"/_nuxt/|__NUXT__", re.I)),
    ("React", "frontend", re.compile(r"data-reactroot|react(?:\.production|-dom)", re.I)),
    ("Vue.js", "frontend", re.compile(r"vue(?:\.runtime)?(?:\.min)?\.js|data-v-[0-9a-f]{6,}", re.I)),
    ("AngularJS/Angular", "frontend", re.compile(r"ng-app|ng-version|angular(?:\.min)?\.js", re.I)),
    ("Laravel", "framework", re.compile(r"name=\"csrf-token\"|laravel", re.I)),
    ("Django", "framework", re.compile(r"csrfmiddlewaretoken", re.I)),
    ("Drupal", "cms", re.compile(r"drupal-settings-json|/sites/default/files", re.I)),
    ("Joomla", "cms", re.compile(r"/media/jui/|joomla", re.I)),
    ("GraphQL API", "api", re.compile(r"/graphql", re.I)),
]
SEC_NOTE = {
    "web_server": "Server banners help attackers match known vulnerabilities; consider trimming version detail.",
    "language": "Runtime exposure narrows attacker guesswork; keep the runtime patched.",
    "framework": "Framework identity narrows attacker guesswork; keep the framework patched.",
    "cms": "CMS platforms are common targets; keep core and plugins patched.",
    "frontend": "Client-side library; check its version against known advisories (see dependency audit).",
    "cdn": "Traffic passes through a CDN/WAF, so scan results reflect the edge, not necessarily the origin.",
    "api": "API surface; see API security assessment.",
}


def detect(ctx):
    """Return technology records. Shared with CVE and dependency modules."""
    home = ctx.home()
    techs = {}

    def record(name, cat, version, source, confidence):
        t = techs.setdefault(name, {"technology": name, "category": cat, "version": None, "version_basis": "unknown",
                                    "evidence": [], "confidence": confidence})
        if source not in t["evidence"]:
            t["evidence"].append(source)
        if version and not t["version"]:
            t["version"], t["version_basis"] = version, "banner"
        order = {"low": 0, "medium": 1, "high": 2}
        if order[confidence] > order[t["confidence"]]:
            t["confidence"] = confidence

    if not home.reached:
        return []
    for name, cat, header, rx in HEADER_RULES:
        value = home.headers.get(header, "")
        m = rx.search(value) if value else None
        if m:
            ver = m.group(1) if m.lastindex else None
            record(name, cat, ver, f"HTTP header {header}: {value}", "high" if ver else "medium")
    cookie_names = [c.split("=", 1)[0].strip() for c in home.set_cookies]
    for name, cat, cookie in COOKIE_RULES:
        if cookie in cookie_names:
            record(name, cat, None, f"Cookie name {cookie}", "medium")
    soup = BeautifulSoup(home.text, "html.parser")
    gen = soup.find("meta", attrs={"name": re.compile("^generator$", re.I)})
    if gen and gen.get("content"):
        content = gen["content"].strip()
        m = re.search(r"^(.*?)[\s/]+v?" + _VER + r"\b", content)
        name, ver = (m.group(1), m.group(2)) if m else (content, None)
        record(name or content, "cms", ver, f"meta generator: {content}", "high" if ver else "medium")
    blob = home.text[:300_000]
    crawl = ctx.crawl()
    asset_urls = " ".join(u for p in crawl.pages.values() for u in p.scripts + p.styles)
    for name, cat, rx in HTML_RULES:
        if rx.search(blob) or rx.search(asset_urls):
            record(name, cat, None, "HTML/asset signature", "medium")
    return list(techs.values())


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    home = ctx.home()
    if not home.reached:
        r.status = "failed"
        r.error = home.blocked or home.error or "target unreachable"
        r.not_performed("Fingerprinting: the target did not respond.")
        return r
    techs = detect(ctx)
    r.performed("Matched response headers, cookie names, HTML meta tags and asset URLs against signatures.")
    r.limit("Fingerprinting identifies what the server chooses to reveal. Versions come from banners and can be hidden or false; "
            "the real backend runtime version is not determinable from outside.")
    r.data["technologies"] = []
    for t in techs:
        verify = t["version"] is None or t["confidence"] != "high"
        r.data["technologies"].append({
            "technology": t["technology"], "category": t["category"],
            "version": t["version"] or "unknown", "version_basis": t["version_basis"],
            "evidence": t["evidence"], "confidence": t["confidence"],
            "security_relevance": SEC_NOTE.get(t["category"], ""), "needs_verification": verify,
        })
        if t["version"] and t["category"] in ("web_server", "language", "framework", "cms"):
            r.add(mk(f"{t['technology']} version disclosed", "fingerprint", "low", t["confidence"], "confirmed", "/",
                     f"The response discloses {t['technology']} {t['version']} ({t['version_basis']}). "
                     "A banner is a claim by the server, not proof of the installed version.",
                     "Version detail helps attackers pick known exploits.", t["evidence"],
                     ["Remove or genericise version information in server and framework headers."], [],
                     "http_response_inspection", False))
    if not techs:
        r.add(mk("No technologies identified", "fingerprint", "informational", "low", "inconclusive", "/",
                 "No signatures matched. This does not mean the site uses no framework.", "", [], [], [],
                 "http_response_inspection", False))
    return r
