import json
import re
from pathlib import Path

from core.models import ModuleResult
from modules._common import mk

KEY = "dependencies"
TITLE = "Dependency & Client-Side Library Audit"
DESCRIPTION = "Detect front-end libraries and compare versions with advisories HEXORA ships with."

# Advisories bundled with the tool: (library, fixed_in, id, severity, summary).
# Only versions strictly below fixed_in are reported. Confirm against the vendor advisory.
ADVISORIES = [
    ("jquery", "3.5.0", "CVE-2020-11022", "medium", "XSS when passing untrusted HTML to DOM manipulation methods"),
    ("jquery", "3.5.0", "CVE-2020-11023", "medium", "XSS via HTML containing <option> elements"),
    ("jquery", "3.4.0", "CVE-2019-11358", "medium", "Prototype pollution in jQuery.extend"),
    ("bootstrap", "3.4.1", "CVE-2019-8331", "medium", "XSS in tooltip/popover data-template (3.x)"),
    ("lodash", "4.17.21", "CVE-2021-23337", "high", "Command injection via template function"),
    ("lodash", "4.17.12", "CVE-2019-10744", "critical", "Prototype pollution in defaultsDeep"),
    ("moment", "2.29.4", "CVE-2022-31129", "high", "Regular expression denial of service in date parsing"),
]
EOL = {"angularjs": "AngularJS 1.x reached end of life in January 2022 and receives no security fixes."}

URL_RULES = [
    ("jquery", re.compile(r"jquery[-.@/]v?(\d+\.\d+(?:\.\d+)?)(?:\.min)?\.js", re.I)),
    ("bootstrap", re.compile(r"bootstrap[-.@/]v?(\d+\.\d+(?:\.\d+)?)(?:\.min)?\.(?:js|css)", re.I)),
    ("lodash", re.compile(r"lodash[-.@/]v?(\d+\.\d+(?:\.\d+)?)(?:\.min)?\.js", re.I)),
    ("moment", re.compile(r"moment[-.@/]v?(\d+\.\d+(?:\.\d+)?)(?:\.min)?\.js", re.I)),
    ("angularjs", re.compile(r"angular(?:js)?[-.@/]v?(1\.\d+(?:\.\d+)?)(?:\.min)?\.js", re.I)),
]
BANNER_RULES = [
    ("jquery", re.compile(r"jQuery (?:JavaScript Library )?v(\d+\.\d+(?:\.\d+)?)", re.I)),
    ("bootstrap", re.compile(r"Bootstrap v(\d+\.\d+(?:\.\d+)?)", re.I)),
    ("lodash", re.compile(r"lodash\s+(?:v|@)?(\d+\.\d+\.\d+)", re.I)),
    ("moment", re.compile(r"//! version\s*:\s*(\d+\.\d+\.\d+)", re.I)),
    ("angularjs", re.compile(r"AngularJS v(1\.\d+(?:\.\d+)?)", re.I)),
]
REF = ["https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components/"]


def vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4])


def below(version, fixed):
    a, b = vtuple(version), vtuple(fixed)
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) < b + (0,) * (n - len(b))


def libraries(ctx):
    """Return {(lib, version): [evidence]} from script/style URLs and file banners."""
    found = {}
    crawl = ctx.crawl()
    urls = {u for p in crawl.pages.values() for u in p.scripts + p.styles}
    for u in urls:
        for lib, rx in URL_RULES:
            m = rx.search(u)
            if m:
                found.setdefault((lib, m.group(1)), []).append(f"Asset URL: {u.split('://', 1)[-1]}")
    for u, text in crawl.js_files.items():
        head = text[:4000]
        for lib, rx in BANNER_RULES:
            m = rx.search(head)
            if m:
                found.setdefault((lib, m.group(1)), []).append(f"File banner in {u.split('://', 1)[-1]}")
    return found


def manifest_libraries(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    deps = {}
    for key in ("dependencies", "devDependencies"):
        deps.update(data.get(key, {}) or {})
    for name, meta in (data.get("packages") or {}).items():  # package-lock v2/v3
        if name.startswith("node_modules/") and isinstance(meta, dict) and meta.get("version"):
            deps[name.split("node_modules/")[-1]] = meta["version"]
    out = {}
    for name, ver in deps.items():
        m = re.search(r"(\d+\.\d+(?:\.\d+)?)", str(ver))
        if m and name.lower() in {a[0] for a in ADVISORIES}:
            out[(name.lower(), m.group(1))] = [f"{Path(path).name}: {name}@{ver}"]
    return out


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    if not ctx.home().reached:
        r.status = "failed"
        r.error = ctx.home().blocked or ctx.home().error or "target unreachable"
        return r
    found = libraries(ctx)
    r.performed("Identified libraries from script URLs and file banners.")
    for path in ctx.settings.manifest_paths:
        try:
            for k, v in manifest_libraries(path).items():
                found.setdefault(k, []).extend(v)
            r.performed(f"Analyzed supplied manifest {Path(path).name}.")
        except (OSError, ValueError) as exc:
            r.limit(f"Manifest {path} could not be read: {type(exc).__name__}")
    r.data["libraries"] = [{"library": l, "version": v, "evidence": e} for (l, v), e in sorted(found.items())]
    for (lib, ver), evidence in sorted(found.items()):
        for name, fixed, adv, sev, summary in ADVISORIES:
            if name == lib and below(ver, fixed):
                r.add(mk(f"{lib} {ver} is affected by {adv}", "dependencies", sev, "medium", "potential", "client-side libraries",
                         f"{lib} {ver} is below {fixed}, the release that fixes {adv}: {summary}. "
                         "Whether the vulnerable code path is used on this site was not verified.",
                         "Exploitability depends on how the application uses the library.", evidence[:3] + [f"Fixed in {fixed}"],
                         [f"Upgrade {lib} to {fixed} or later."], [f"https://nvd.nist.gov/vuln/detail/{adv}"],
                         "version_comparison", False))
        if lib in EOL:
            r.add(mk(f"{lib} {ver} is end-of-life", "dependencies", "medium", "medium", "confirmed", "client-side libraries",
                     EOL[lib], "No security patches are issued.", evidence[:3], ["Migrate to a supported framework."], REF,
                     "version_comparison", False))
    if not found:
        r.limit("No versioned client-side libraries were identified. Bundled or minified code without version banners cannot be audited this way.")
    r.limit(f"Advisory data is a small bundled list ({len(ADVISORIES)} entries), not a full vulnerability database. Use the CVE module and your lockfile tooling for broader coverage.")
    return r
