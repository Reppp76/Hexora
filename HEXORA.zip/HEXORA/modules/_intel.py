"""Infrastructure context, destination classification, threat intelligence and attribution helpers.

Shared by the Phishing Check and Spyware Check modules. Nothing in here connects to a destination found in a
page: external hosts are only resolved through DNS. Threat-intelligence lookups go to fixed, documented API
hosts and send only the already-authorized target URL/hostname (or a referenced hostname), never page data.
"""
import hashlib
import json
import re
import ssl
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import requests

from core.exceptions import ScopeError
from core.scope import ip_problem, resolve
from modules._clientside import clean
from modules.tls import _connect

URLHAUS_API = "https://urlhaus-api.abuse.ch/v1"
PHISHTANK_API = "https://checkurl.phishtank.com/checkurl/"
INTEL_TTL = 6 * 3600
MAX_DNS_HOSTS = 15
MAX_INTEL_HOSTS = 4


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------------------------
# names


_SECOND_LEVEL = {"co", "com", "org", "net", "gov", "edu", "ac", "or", "ne", "go", "mil", "sch"}


def registrable(host):
    """Registrable domain without a public-suffix list: handles common two-part country suffixes only."""
    host = (host or "").lower().rstrip(".")
    labels = host.split(".")
    if len(labels) <= 2 or re.fullmatch(r"[\d.]+", host) or ":" in host:
        return host
    if len(labels[-1]) == 2 and labels[-2] in _SECOND_LEVEL:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


# suffix -> (class, publicly documented operator, note)
_KNOWN = [
    ("api.telegram.org", "messaging_webhook_api", "Telegram", "Bot API endpoint; the bot owner, not Telegram, controls who reads the data."),
    ("discord.com", "messaging_webhook_api", "Discord", "Webhook endpoints deliver to whoever created the webhook."),
    ("discordapp.com", "messaging_webhook_api", "Discord", "Webhook endpoints deliver to whoever created the webhook."),
    ("hooks.slack.com", "messaging_webhook_api", "Slack", "Incoming webhooks deliver to the workspace that created them."),
    ("webhook.site", "request_capture_or_tunnel", "webhook.site", "Public request-capture service; anyone can create an endpoint."),
    ("requestbin.com", "request_capture_or_tunnel", "RequestBin", "Public request-capture service."),
    ("pipedream.net", "request_capture_or_tunnel", "Pipedream", "Workflow/request-capture service."),
    ("ngrok.io", "request_capture_or_tunnel", "ngrok", "Tunnel to a machine of the account holder."),
    ("ngrok-free.app", "request_capture_or_tunnel", "ngrok", "Tunnel to a machine of the account holder."),
    ("ngrok.app", "request_capture_or_tunnel", "ngrok", "Tunnel to a machine of the account holder."),
    ("trycloudflare.com", "request_capture_or_tunnel", "Cloudflare", "Quick tunnel to a machine of the account holder."),
    ("pastebin.com", "request_capture_or_tunnel", "Pastebin", "Public paste service."),
    ("formspree.io", "form_processing_service", "Formspree", "Legitimate form backend; forwards submissions to the account owner."),
    ("getform.io", "form_processing_service", "Getform", "Legitimate form backend; forwards submissions to the account owner."),
    ("web3forms.com", "form_processing_service", "Web3Forms", "Legitimate form backend; forwards submissions to the account owner."),
    ("formsubmit.co", "form_processing_service", "FormSubmit", "Legitimate form backend; forwards submissions to the account owner."),
    ("formspark.io", "form_processing_service", "Formspark", "Legitimate form backend; forwards submissions to the account owner."),
    ("google-analytics.com", "analytics", "Google", "Web analytics."),
    ("analytics.google.com", "analytics", "Google", "Web analytics."),
    ("googletagmanager.com", "analytics", "Google", "Tag manager; loads whatever tags the site owner configures."),
    ("doubleclick.net", "advertising", "Google", "Advertising."),
    ("connect.facebook.net", "advertising", "Meta", "Social/advertising SDK."),
    ("analytics.tiktok.com", "advertising", "TikTok", "Advertising analytics."),
    ("segment.io", "analytics", "Segment", "Customer-data analytics."),
    ("segment.com", "analytics", "Segment", "Customer-data analytics."),
    ("mixpanel.com", "analytics", "Mixpanel", "Product analytics."),
    ("amplitude.com", "analytics", "Amplitude", "Product analytics."),
    ("plausible.io", "analytics", "Plausible", "Web analytics."),
    ("matomo.cloud", "analytics", "Matomo", "Web analytics."),
    ("sentry.io", "analytics", "Sentry", "Error monitoring."),
    ("hotjar.com", "session_replay", "Hotjar", "Session recording/heatmaps; collects interaction events."),
    ("hotjar.io", "session_replay", "Hotjar", "Session recording/heatmaps; collects interaction events."),
    ("clarity.ms", "session_replay", "Microsoft", "Session recording/heatmaps; collects interaction events."),
    ("fullstory.com", "session_replay", "FullStory", "Session recording; collects interaction events."),
    ("logrocket.com", "session_replay", "LogRocket", "Session recording; collects interaction events."),
    ("lr-ingest.io", "session_replay", "LogRocket", "Session recording; collects interaction events."),
    ("mouseflow.com", "session_replay", "Mouseflow", "Session recording; collects interaction events."),
    ("accounts.google.com", "identity_provider", "Google", "Federated sign-in."),
    ("login.microsoftonline.com", "identity_provider", "Microsoft", "Federated sign-in."),
    ("login.live.com", "identity_provider", "Microsoft", "Federated sign-in."),
    ("appleid.apple.com", "identity_provider", "Apple", "Federated sign-in."),
    ("okta.com", "identity_provider", "Okta", "Identity provider."),
    ("auth0.com", "identity_provider", "Auth0", "Identity provider."),
    ("onelogin.com", "identity_provider", "OneLogin", "Identity provider."),
    ("amazoncognito.com", "identity_provider", "Amazon", "Identity provider."),
    ("stripe.com", "payment_provider", "Stripe", "Payment processor."),
    ("paypal.com", "payment_provider", "PayPal", "Payment processor."),
    ("paypalobjects.com", "payment_provider", "PayPal", "Payment assets."),
    ("adyen.com", "payment_provider", "Adyen", "Payment processor."),
    ("braintreegateway.com", "payment_provider", "Braintree", "Payment processor."),
    ("squareup.com", "payment_provider", "Square", "Payment processor."),
    ("razorpay.com", "payment_provider", "Razorpay", "Payment processor."),
    ("billplz.com", "payment_provider", "Billplz", "Payment gateway."),
    ("toyyibpay.com", "payment_provider", "ToyyibPay", "Payment gateway."),
    ("cdnjs.cloudflare.com", "cdn_library", "Cloudflare", "Public library CDN."),
    ("cdn.jsdelivr.net", "cdn_library", "jsDelivr", "Public library CDN."),
    ("unpkg.com", "cdn_library", "unpkg", "Public npm CDN."),
    ("ajax.googleapis.com", "cdn_library", "Google", "Public library CDN."),
    ("fonts.googleapis.com", "cdn_library", "Google", "Font hosting."),
    ("fonts.gstatic.com", "cdn_library", "Google", "Font hosting."),
    ("code.jquery.com", "cdn_library", "jQuery", "Library CDN."),
    ("cdn.tailwindcss.com", "cdn_library", "Tailwind Labs", "Library CDN."),
    ("maxcdn.bootstrapcdn.com", "cdn_library", "BootstrapCDN", "Library CDN."),
    ("stackpath.bootstrapcdn.com", "cdn_library", "BootstrapCDN", "Library CDN."),
    ("use.fontawesome.com", "cdn_library", "Font Awesome", "Icon font hosting."),
    ("kit.fontawesome.com", "cdn_library", "Font Awesome", "Icon font hosting."),
    ("workers.dev", "shared_hosting_platform", "Cloudflare Workers", "Anyone can host code on a subdomain; the platform is not the operator."),
    ("pages.dev", "shared_hosting_platform", "Cloudflare Pages", "Anyone can host content on a subdomain; the platform is not the operator."),
    ("herokuapp.com", "shared_hosting_platform", "Heroku", "Anyone can host an app on a subdomain; the platform is not the operator."),
    ("vercel.app", "shared_hosting_platform", "Vercel", "Anyone can host an app on a subdomain; the platform is not the operator."),
    ("netlify.app", "shared_hosting_platform", "Netlify", "Anyone can host content on a subdomain; the platform is not the operator."),
    ("web.app", "shared_hosting_platform", "Firebase", "Anyone can host content on a subdomain; the platform is not the operator."),
    ("firebaseapp.com", "shared_hosting_platform", "Firebase", "Anyone can host content on a subdomain; the platform is not the operator."),
    ("github.io", "shared_hosting_platform", "GitHub Pages", "Anyone can host content on a subdomain; the platform is not the operator."),
    ("glitch.me", "shared_hosting_platform", "Glitch", "Anyone can host content on a subdomain; the platform is not the operator."),
    ("000webhostapp.com", "shared_hosting_platform", "000webhost", "Free hosting; the platform is not the operator."),
    ("blogspot.com", "shared_hosting_platform", "Blogger", "Anyone can publish on a subdomain; the platform is not the operator."),
]
BENIGN_SCRIPT_CLASSES = {"cdn_library", "analytics", "advertising", "identity_provider", "payment_provider", "session_replay"}
ENDPOINT_LIMITS = [
    "The operator of an endpoint is not necessarily the person who receives or reads the data.",
    "An endpoint can belong to a hosting provider, proxy, legitimate processor, compromised server or unrelated third party.",
    "The request payload was not inspected; transmission was not observed.",
]


def classify_host(host, url=""):
    """(class, operator, note) for a hostname, using only the bundled public-service table."""
    host = (host or "").lower().rstrip(".")
    path = urlsplit(url).path.lower() if url else ""
    for suffix, cls, op, note in _KNOWN:
        if host == suffix or host.endswith("." + suffix):
            if suffix in ("discord.com", "discordapp.com") and "/api/webhooks/" not in path and url:
                return "unknown", None, ""
            return cls, op, note
    return "unknown", None, ""


def origin_relation(ctx, host, scheme="", port=None):
    t = ctx.target
    if ctx.scope.host_in_scope(host):
        eff = port or (443 if scheme in ("https", "wss") else 80 if scheme in ("http", "ws") else t.port)
        same_scheme = not scheme or scheme in (t.scheme, "ws" if t.scheme == "http" else "wss")
        return "same_origin" if eff == t.port and same_scheme else "same_site_cross_origin"
    if registrable(host) == registrable(t.hostname):
        return "same_site_cross_origin"
    return "cross_origin"


# ---------------------------------------------------------------------------------------------
# DNS


def dns_info(ctx, host):
    cache = ctx.__dict__.setdefault("_dns_cache", {})
    if host in cache:
        return cache[host]
    if len([h for h in cache if h != ctx.target.hostname]) >= MAX_DNS_HOSTS and host != ctx.target.hostname:
        return {"a": [], "aaaa": [], "addresses": [], "error": "DNS lookup limit reached; host not resolved", "flags": []}
    try:
        ips = resolve(host)
        info = {"a": [str(i) for i in ips if i.version == 4], "aaaa": [str(i) for i in ips if i.version == 6], "addresses": [str(i) for i in ips],
                "error": None, "flags": sorted({r for i in ips if (r := ip_problem(i))})}
    except ScopeError as exc:
        info = {"a": [], "aaaa": [], "addresses": [], "error": clean(str(exc), 120), "flags": []}
    cache[host] = info
    return info


# ---------------------------------------------------------------------------------------------
# target infrastructure

_HEADERS = ("server", "via", "x-powered-by", "x-served-by", "x-cache", "cf-ray", "cf-cache-status", "x-amz-cf-id",
            "strict-transport-security", "content-security-policy", "referrer-policy", "x-frame-options")
_REDIRECT_BLOCKED = re.compile(r"redirect to (\S+) refused")


def tls_info(host, port, timeout):
    try:
        version, cipher, cert = _connect(host, port, ssl.create_default_context(), timeout)
    except ssl.SSLCertVerificationError as exc:
        return {"verified": False, "error": clean(getattr(exc, "verify_message", str(exc)), 120)}
    except (ssl.SSLError, OSError) as exc:
        return {"verified": None, "error": clean(f"{type(exc).__name__}: {exc}", 120)}
    subject = {k: v for rdn in cert.get("subject", ()) for k, v in rdn}
    issuer = {k: v for rdn in cert.get("issuer", ()) for k, v in rdn}
    san = [v for k, v in cert.get("subjectAltName", ()) if k == "DNS"][:12]
    info = {"verified": True, "protocol": version, "cipher": cipher[0] if cipher else None, "subject_cn": subject.get("commonName"),
            "issuer": issuer.get("organizationName") or issuer.get("commonName"), "san": san, "not_before": cert.get("notBefore"),
            "not_after": cert.get("notAfter"), "error": None}
    try:
        info["age_days"] = int((time.time() - ssl.cert_time_to_seconds(cert["notBefore"])) // 86400)
        info["days_remaining"] = int((ssl.cert_time_to_seconds(cert["notAfter"]) - time.time()) // 86400)
    except (KeyError, ValueError):
        pass
    return info


def _hints(headers):
    h = {k.lower(): v for k, v in headers.items()}
    out = []
    if "cf-ray" in h or "cloudflare" in h.get("server", "").lower():
        out.append("Cloudflare (CDN/reverse proxy) indicated by response headers")
    if "x-amz-cf-id" in h or "cloudfront" in h.get("via", "").lower():
        out.append("Amazon CloudFront indicated by response headers")
    if "akamai" in h.get("server", "").lower():
        out.append("Akamai indicated by the Server header")
    if "fastly" in h.get("x-served-by", "").lower() or "fastly" in h.get("via", "").lower():
        out.append("Fastly indicated by response headers")
    if "via" in h and not out:
        out.append("A Via header indicates at least one intermediary proxy")
    return out


def network_context(ctx):
    cached = ctx.__dict__.get("_network_context")
    if cached:
        return cached
    t = ctx.target
    home = ctx.home()
    dns = dns_info(ctx, t.hostname)
    info = {
        "observed_at": now_iso(), "target_url": t.url, "hostname": t.hostname, "scheme": t.scheme.upper(),
        "effective_port": t.port, "explicit_port": urlsplit(t.url).port,
        "dns_a": dns["a"], "dns_aaaa": dns["aaaa"], "resolved_ip_addresses": dns["addresses"], "dns_error": dns["error"],
        "final_url": home.url if home.reached else None, "redirect_chain": [{"url": u, "status": s} for u, s in home.chain],
        "redirect_refused": None, "response_status": home.status or None,
        "response_headers": {}, "infrastructure_hints": [], "tls": None, "errors": [],
        "notes": ["A resolved IP address does not identify the website owner; CDNs, proxies and shared hosts return infrastructure addresses.",
                  "Origin servers behind protective infrastructure were not sought."],
    }
    if home.blocked:
        m = _REDIRECT_BLOCKED.search(home.blocked)
        info["redirect_refused"] = clean(m.group(1), 200) if m else clean(home.blocked, 200)
    if home.reached:
        info["response_headers"] = {k: clean(v, 100) for k, v in home.headers.items() if k.lower() in _HEADERS}
        info["infrastructure_hints"] = _hints(home.headers)
    elif home.error or home.blocked:
        info["errors"].append(clean(home.blocked or home.error, 160))
    if t.scheme == "https":
        info["tls"] = tls_info(t.hostname, t.port, ctx.settings.request_timeout)
    ctx.__dict__["_network_context"] = info
    return info


# ---------------------------------------------------------------------------------------------
# threat intelligence


class IntelUnavailable(Exception):
    pass


def _cache_file(settings, key):
    return Path(settings.cache_dir) / ("intel-" + hashlib.sha256(key.encode()).hexdigest()[:24] + ".json")


def _cached_post(settings, key, send):
    path = _cache_file(settings, key)
    try:
        if path.exists() and time.time() - path.stat().st_mtime < INTEL_TTL:
            return json.loads(path.read_text())
    except (OSError, ValueError):
        pass
    data = send()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))
    except OSError:
        pass
    return data


def _post(settings, url, data, headers, timeout):
    h = {"User-Agent": "phishtank/hexora (authorized security assessment)" if "phishtank" in url else settings.user_agent, **headers}
    try:
        r = requests.post(url, data=data, headers=h, timeout=(min(timeout, 5), timeout), allow_redirects=False, stream=True)
        body = b""
        for piece in r.iter_content(8192):
            body += piece
            if len(body) > 512_000:
                break
        r.close()
    except requests.exceptions.RequestException as exc:
        raise IntelUnavailable(f"{type(exc).__name__}") from exc
    if r.status_code in (429, 509):
        raise IntelUnavailable("rate limited")
    if r.status_code in (401, 403):
        raise IntelUnavailable(f"access refused (HTTP {r.status_code}); check the API key")
    if r.status_code != 200:
        raise IntelUnavailable(f"HTTP {r.status_code}")
    try:
        return json.loads(body.decode("utf-8", "replace"))
    except ValueError as exc:
        raise IntelUnavailable("unparsable response") from exc


def fetch_urlhaus(settings, kind, value, timeout=10):
    """URLhaus lookup (kind: 'url' or 'host'). Raises IntelUnavailable on any failure."""
    return _cached_post(settings, f"urlhaus|{kind}|{value}", lambda: _post(
        settings, f"{URLHAUS_API}/{kind}/", {kind: value}, {"Auth-Key": settings.urlhaus_auth_key}, timeout))


def fetch_phishtank(settings, url, timeout=10):
    """PhishTank lookup. The app key is optional (anonymous requests are rate limited harder)."""
    data = {"url": url, "format": "json"}
    if settings.phishtank_app_key:
        data["app_key"] = settings.phishtank_app_key
    return _cached_post(settings, f"phishtank|url|{url}", lambda: _post(settings, PHISHTANK_API, data, {}, timeout))


def _truthy(v):
    return v is True or str(v).strip().lower() in ("y", "yes", "true", "1")


def _record(source, kind, value, result, detail="", record=None):
    return {"source": source, "query_type": kind, "queried": clean(value, 160), "result": result, "observed_at": now_iso(),
            "detail": detail, "record": record or {}}


def _parse_phishtank(url, data):
    res = (data or {}).get("results", {}) or {}
    if not _truthy(res.get("in_database")):
        return _record("phishtank", "url", url, "no_match", "Not listed. A missing listing is not proof the site is legitimate.")
    valid, verified = _truthy(res.get("valid")), _truthy(res.get("verified"))
    rec = {"phish_id": res.get("phish_id"), "verified": verified, "valid": valid, "verified_at": res.get("verified_at"), "detail_page": res.get("phish_detail_page")}
    if not valid:
        return _record("phishtank", "url", url, "no_match", "Listed but marked invalid by PhishTank.", rec)
    return _record("phishtank", "url", url, "match", "Listed as a valid phish" + (" (community verified)." if verified else " (not yet verified)."), rec)


def _parse_urlhaus(kind, value, data):
    status = (data or {}).get("query_status", "")
    if status == "no_results":
        return _record("urlhaus", kind, value, "no_match", "Not listed. A missing listing is not proof the site is safe.")
    if status == "ok":
        if kind == "url":
            rec = {k: data.get(k) for k in ("url_status", "threat", "date_added", "urlhaus_reference")}
            rec["tags"] = (data.get("tags") or [])[:10]
            return _record("urlhaus", kind, value, "match", f"Listed as malware distribution ({data.get('threat') or 'threat not stated'}; status {data.get('url_status')}).", rec)
        rec = {"url_count": data.get("url_count"), "urlhaus_reference": data.get("urlhaus_reference"), "blacklists": data.get("blacklists")}
        return _record("urlhaus", kind, value, "match", "Host has URLs listed in URLhaus. A listed host can be a compromised legitimate site.", rec)
    return _record("urlhaus", kind, value, "unavailable", f"Unexpected query status '{clean(status, 40)}'.")


def threat_intel(ctx, extra_hosts=()):
    """Records for the target URL/host and a few referenced hosts. Cached on the context so a full audit asks once."""
    s, t = ctx.settings, ctx.target
    store = ctx.__dict__.setdefault("_intel_records", {})

    def once(key, fn):
        if key not in store:
            store[key] = fn()
        return store[key]

    def guarded(source, kind, value, call, parse, need_key=False):
        if not s.threat_intel_enabled:
            return _record(source, kind, value, "skipped", "Disabled (HEXORA_THREAT_INTEL_ENABLED=false).")
        if need_key and not getattr(s, "urlhaus_auth_key", ""):
            return _record(source, kind, value, "not_configured", "URLHAUS_AUTH_KEY is not set in .env; lookup not performed.")
        try:
            return parse(call())
        except IntelUnavailable as exc:
            return _record(source, kind, value, "unavailable", f"Lookup failed: {exc}. This is not a clean result.")

    if not s.threat_intel_enabled:
        return [_record(src, "url", t.url, "skipped", "Disabled (HEXORA_THREAT_INTEL_ENABLED=false).") for src in ("phishtank", "urlhaus")]
    dns = dns_info(ctx, t.hostname)
    if dns["flags"] or not dns["addresses"]:
        why = "target resolves to a private or local address" if dns["flags"] else "target did not resolve"
        return [_record(src, "url", t.url, "skipped", f"Not sent to third-party services: {why}.") for src in ("phishtank", "urlhaus")]

    out = [
        once(("phishtank", "url", t.url), lambda: guarded("phishtank", "url", t.url, lambda: fetch_phishtank(s, t.url), lambda d: _parse_phishtank(t.url, d))),
        once(("urlhaus", "url", t.url), lambda: guarded("urlhaus", "url", t.url, lambda: fetch_urlhaus(s, "url", t.url), lambda d: _parse_urlhaus("url", t.url, d), True)),
        once(("urlhaus", "host", t.hostname), lambda: guarded("urlhaus", "host", t.hostname, lambda: fetch_urlhaus(s, "host", t.hostname), lambda d: _parse_urlhaus("host", t.hostname, d), True)),
    ]
    for host in list(dict.fromkeys(extra_hosts))[:MAX_INTEL_HOSTS]:
        d = dns_info(ctx, host)
        if d["flags"] or ctx.scope.host_in_scope(host):
            continue
        out.append(once(("urlhaus", "host", host), lambda h=host: guarded("urlhaus", "host", h, lambda: fetch_urlhaus(s, "host", h), lambda d: _parse_urlhaus("host", h, d), True)))
    return out


def intel_flags(records):
    matches = [r for r in records if r["result"] == "match"]
    return {
        "phish_verified": any(r["source"] == "phishtank" and r["record"].get("verified") for r in matches),
        "phish_listed": any(r["source"] == "phishtank" for r in matches),
        "malware_url_listed": any(r["source"] == "urlhaus" and r["query_type"] == "url" for r in matches),
        "malware_host_listed": any(r["source"] == "urlhaus" and r["query_type"] == "host" for r in matches),
        "unavailable": [r for r in records if r["result"] in ("unavailable", "not_configured", "skipped")],
    }


def intel_limitations(records):
    out = []
    for r in records:
        if r["result"] in ("unavailable", "not_configured", "skipped"):
            out.append(f"Threat intelligence ({r['source']} {r['query_type']} lookup) {r['result'].replace('_', ' ')}: {r['detail']} No verdict was inferred from the missing result.")
    return out


# ---------------------------------------------------------------------------------------------
# destinations and flow records


def destination_record(ctx, url, referenced_by, intel=()):
    parts = urlsplit(url)
    host = (parts.hostname or "").lower()
    scheme = parts.scheme.lower()
    port = parts.port or {"https": 443, "wss": 443, "http": 80, "ws": 80}.get(scheme)
    cls, op, note = classify_host(host, url)
    relation = origin_relation(ctx, host, scheme, port)
    if relation != "cross_origin" and cls == "unknown":
        cls = "first_party" if relation == "same_origin" else "first_party_other_origin"
    dns = dns_info(ctx, host)
    return {
        "hostname": host, "port": port, "protocol": scheme.upper(), "example_url": clean(url, 160), "path_sample": clean(parts.path or "/", 80),
        "destination_class": cls, "origin_relation": relation, "endpoint_operator": op, "operator_note": note,
        "dns_a": dns["a"], "dns_aaaa": dns["aaaa"], "dns_error": dns["error"], "address_flags": dns["flags"],
        "referenced_by": sorted(set(referenced_by))[:6], "observation": "referenced_in_source", "payload_inspected": False,
        "threat_intel": [r for r in intel if r["queried"] == clean(host, 160) or r["queried"] == clean(url, 160)],
        "tls_inspected": False,
    }


def flow_record(ctx, *, source, data_category, dest_url, method, observation_type, evidence, confidence, unresolved=(), page=None, trigger=None, extra=None):
    """One data-flow record. dest_url None means a dynamic destination that could not be resolved statically."""
    if dest_url:
        parts = urlsplit(dest_url)
        host = (parts.hostname or "").lower()
        scheme = parts.scheme.lower()
        port = parts.port or {"https": 443, "wss": 443, "http": 80, "ws": 80}.get(scheme)
        cls, op, note = classify_host(host, dest_url)
        relation = origin_relation(ctx, host, scheme, port)
        if relation != "cross_origin" and cls == "unknown":
            cls = "first_party" if relation == "same_origin" else "first_party_other_origin"
        dns = dns_info(ctx, host)
        ips = dns["addresses"]
    else:
        host = port = scheme = None
        cls, op, note, relation, ips = "unknown", None, "", "unresolved", []
    attribution = {
        "endpoint_class": cls, "endpoint_operator": op,
        "ultimate_recipient": "Unknown / not established from available evidence.",
        "basis": ("Destination host matches a publicly documented service: " + note) if op else "No public documentation links this host to a named operator in the bundled reference table.",
    }
    return {
        "source": source, "source_page": page, "data_category": data_category, "destination_url": clean(dest_url, 200) if dest_url else None,
        "destination_hostname": host, "destination_ip_addresses": ips, "destination_port": port, "protocol": scheme.upper() if scheme else None,
        "http_method": method, "observation_type": observation_type, "origin_relation": relation, "destination_class": cls,
        "trigger": trigger, "evidence": evidence if isinstance(evidence, list) else [evidence], "confidence": confidence,
        "recipient_attribution": attribution, "attribution_limitations": list(ENDPOINT_LIMITS),
        "unresolved_questions": list(unresolved) or ["Was the request actually sent by a browser?", "What did the request body contain?", "Who operates the receiving system?"],
        **(extra or {}),
    }


# ---------------------------------------------------------------------------------------------
# attribution


_REPO_PREFIX = re.compile(r"^(github\.com|gitlab\.com|bitbucket\.org)/")


def kit_fingerprints(corpus, settings, module):
    """Technique patterns plus any operator-supplied named signatures. No named family is claimed from memory."""
    texts = [(u.origin, u.text) for u in corpus.units] + [(d.url, d.text) for d in corpus.docs]
    found = []

    def add(name, kind, match, confidence, rx, applies, reference=None):
        for origin, text in texts:
            m = re.search(rx, text, re.I)
            if m:
                found.append({"name": name, "kind": kind, "match": match, "confidence": confidence, "applies_to": applies, "reference": reference,
                              "evidence": [{"resource": origin, "snippet": clean(text[max(0, m.start() - 20): m.start() + 90], 110)}]})
                return

    add("Telegram Bot API used as a data sink from page code", "technique_pattern", "approximate", "medium", r"api\.telegram\.org/bot", "both")
    add("Discord webhook used as a data sink from page code", "technique_pattern", "approximate", "medium", r"discord(?:app)?\.com/api/webhooks/", "both")
    add("Page code blocks context menu or developer-tools shortcuts", "technique_pattern", "approximate", "low",
        r"contextmenu['\"]?\s*,\s*(?:function|\w+\s*=>)[^;]{0,80}preventDefault|keyCode\s*(?:==|===)\s*123|oncontextmenu\s*=\s*['\"]\s*return\s+false", "phishing")
    add("Form field prefilled from URL fragment or query (victim-tailoring pattern)", "technique_pattern", "approximate", "low",
        r"location\s*\.\s*(?:hash|search)[^;]{0,160}(?:atob|decodeURIComponent)[^;]{0,160}\.value\s*=", "phishing")
    path = getattr(settings, "kit_signatures_path", "")
    if path:
        try:
            for sig in json.loads(Path(path).read_text(encoding="utf-8"))[:200]:
                if sig.get("applies_to", "both") in ("both", module):
                    add(str(sig["name"])[:80], "operator_signature", sig.get("match", "approximate"), "medium", sig["pattern"], sig.get("applies_to", "both"), sig.get("reference"))
        except (OSError, ValueError, KeyError, TypeError, re.error):
            found.append({"name": "Operator signature file could not be loaded", "kind": "error", "match": "none", "confidence": "low",
                          "applies_to": "both", "reference": None, "evidence": []})
    return found


UNKNOWN_DEVELOPER = "Developer identity: Unknown / not established from available evidence."


def developer_attribution(corpus, analysis):
    cands, signals = [], []
    for d in corpus.docs:
        for key in ("author", "generator", "application-name", "copyright"):
            if d.meta.get(key):
                role = "site_declared_author" if key in ("author", "copyright") else "site_software_declared"
                cands.append({"role": role, "value": clean(d.meta[key], 80), "source": f"meta[{key}] on {d.url}", "confidence": "low",
                              "note": "Self-declared by the page; not independently verified."})
        for credit in d.credits[:2]:
            cands.append({"role": "site_credit_text", "value": clean(credit, 60), "source": f"page text on {d.url}", "confidence": "low",
                          "note": "Self-declared credit text; not independently verified."})
    for b in analysis.banners:
        if b["repository"]:
            cands.append({"role": "repository_reference", "value": b["repository"], "source": b["resource"], "confidence": "low",
                          "note": "A repository reference in a script identifies where code came from, not who built this website."})
        if b["copyright"] or b["author"]:
            cands.append({"role": "script_publisher_or_library_author", "value": b["author"] or b["copyright"], "source": b["resource"], "confidence": "low",
                          "note": "Authors of a library are not assumed to be the developers of the website using it."})
    for m in corpus.sourcemaps:
        if m["packages"] or m["sources_sample"]:
            signals.append({"type": "source_map", "resource": m["map_url"], "packages": m["packages"][:15], "sources_sample": m["sources_sample"][:6],
                            "note": "Source-map paths describe project structure; they do not name a person or organization."})
    seen, uniq = set(), []
    for c in cands:
        k = (c["role"], c["value"])
        if k not in seen:
            seen.add(k)
            uniq.append(c)
    declared = next((c for c in uniq if c["role"] in ("site_credit_text", "site_declared_author")), None)
    statement = (f"Developer credit declared on the page: {declared['value']} (self-declared; not independently verified)." if declared else UNKNOWN_DEVELOPER)
    return {
        "identity_statement": statement, "candidates": uniq[:15], "signals": signals,
        "not_assessed": ["Domain registrant (WHOIS/RDAP) was not queried.", "Hosting-provider ownership was not determined; no offline ASN data is bundled.",
                         "A registrant, host, CDN, script publisher or website owner is not assumed to be the developer."],
    }
