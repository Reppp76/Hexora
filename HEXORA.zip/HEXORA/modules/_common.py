import re
from urllib.parse import urlsplit

from core.models import Finding

_SQL_ERRORS = re.compile(
    r"(you have an error in your sql syntax|warning: mysql|mysqli?_|unclosed quotation mark|"
    r"quoted string not properly terminated|pg_query\(\)|psql: error|sqlstate\[|sqlite3?::|"
    r"sqlite_error|ora-\d{5}|microsoft ole db|odbc sql server driver|syntax error at or near)",
    re.I,
)
_TRACE = re.compile(
    r"(traceback \(most recent call last\)|at [\w.$]+\([\w.]+\.java:\d+\)|stack trace:|"
    r"fatal error: .* in /|exception in thread|system\.\w+exception|werkzeug debugger|"
    r"django\.core\.exceptions|laravel.*whoops|<b>warning</b>:.*on line)",
    re.I,
)


def mk(title, category, severity, confidence, status, resource, description, impact="",
       evidence=None, remediation=None, references=None, method="passive_observation", verified=False):
    return Finding(
        title=title, category=category, severity=severity, confidence=confidence, status=status,
        affected_resource=resource, description=description, impact=impact,
        evidence=list(evidence or []), remediation=list(remediation or []), references=list(references or []),
        verification={"method": method, "verified": verified},
    )


def path_of(url):
    p = urlsplit(url)
    return p.path + (f"?{p.query}" if p.query else "") or "/"


def sql_error(text):
    m = _SQL_ERRORS.search(text or "")
    return m.group(0) if m else None


def stack_trace(text):
    m = _TRACE.search(text or "")
    return m.group(0)[:80] if m else None


def parse_cookie(raw):
    """Return (name, attrs) for a Set-Cookie line. The value is dropped on purpose."""
    parts = [p.strip() for p in raw.split(";")]
    name = parts[0].split("=", 1)[0]
    attrs = {}
    for p in parts[1:]:
        k, _, v = p.partition("=")
        attrs[k.strip().lower()] = v.strip()
    return name, attrs


def cookie_findings(resp, https, category="cookies"):
    """Shared by the headers and authentication modules so duplicates collapse in a full audit."""
    out = []
    resource = path_of(resp.url)
    for raw in resp.set_cookies:
        name, attrs = parse_cookie(raw)
        problems = []
        if https and "secure" not in attrs:
            problems.append(("Secure", "sent over HTTPS without the Secure attribute", "medium"))
        if "httponly" not in attrs:
            problems.append(("HttpOnly", "readable from JavaScript (no HttpOnly)", "low"))
        if "samesite" not in attrs:
            problems.append(("SameSite", "no SameSite attribute set", "low"))
        for attr, text, sev in problems:
            out.append(mk(
                f"Cookie '{name}' missing {attr} attribute", category, sev, "high", "confirmed", resource,
                f"The cookie '{name}' is {text}. Impact depends on whether this cookie carries session state.",
                "A cookie without these attributes is easier to steal or replay in some attack scenarios.",
                evidence=[f"Set-Cookie name={name}; attributes seen: {sorted(attrs) or 'none'} (value not recorded)"],
                remediation=[f"Set the {attr} attribute on '{name}'."],
                references=["https://owasp.org/www-community/controls/SecureCookieAttribute"],
                method="http_response_inspection", verified=True,
            ))
    return out
