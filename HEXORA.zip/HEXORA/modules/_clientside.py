"""Static, non-executing client-side analysis shared by the Phishing and Spyware modules.

Nothing here runs JavaScript. Pages and scripts are fetched through the scan's SafeClient, parsed
with BeautifulSoup and scanned with regular expressions. Out-of-scope scripts are listed, never fetched.
Evidence snippets are redacted before they leave this file; form values are never read.
"""
import hashlib
import json
import re
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup

from core.exceptions import BudgetExceeded
from core.redact import redact_text

MAX_PAGES = 6
MAX_UNITS = 60
MAX_EXTRA_SCRIPTS = 6
MAX_MAPS = 3
UNIT_CAP = 400_000


@dataclass
class Unit:
    kind: str      # inline | file | handler
    origin: str    # page URL (inline, handler) or script URL (file)
    base: str      # URL used to resolve relative destinations
    text: str
    attr: str = ""


@dataclass
class Doc:
    url: str
    status: int
    title: str = ""
    meta: dict = field(default_factory=dict)
    text: str = ""
    forms: list = field(default_factory=list)
    links: list = field(default_factory=list)
    iframes: list = field(default_factory=list)
    script_srcs: list = field(default_factory=list)
    images: list = field(default_factory=list)
    refresh: str = ""
    credits: list = field(default_factory=list)
    headings: list = field(default_factory=list)


@dataclass
class Corpus:
    docs: list = field(default_factory=list)
    units: list = field(default_factory=list)
    external_scripts: list = field(default_factory=list)
    sourcemaps: list = field(default_factory=list)
    errors: list = field(default_factory=list)


# ---------------------------------------------------------------------------------------------
# redaction


_SECRET_ASSIGN = re.compile(r"""(?i)((?:pass(?:word|wd)?|pwd|token|secret|api[_-]?key|auth|session|otp|cvv)\w*['"]?\s*[:=]\s*)(['"`])[^'"`]{1,200}\2""")
_LONG_TOKEN = re.compile(r"\b[A-Za-z0-9_\-+/=]{28,}\b")
_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")


def clean(text, width=140):
    """One-line, redacted evidence snippet. Never reproduces literal secrets or e-mail addresses."""
    text = " ".join(str(text).split())
    text = _SECRET_ASSIGN.sub(r"\1\2[REDACTED]\2", text)
    text = redact_text(text)
    text = _EMAIL.sub("[EMAIL]", text)
    text = _LONG_TOKEN.sub(lambda m: m.group(0) if "." in m.group(0) or m.group(0).isalpha() else "[REDACTED]", text)
    return text[:width] + ("..." if len(text) > width else "")


def snippet(text, pos, width=110):
    return clean(text[max(0, pos - 20): pos + width], width + 20)


def line_of(text, pos):
    return text.count("\n", 0, pos) + 1


# ---------------------------------------------------------------------------------------------
# HTML


_FIELD_WORDS = [
    ("payment_card_details", re.compile(r"card|cvv|cvc|ccnum|cc-|expir", re.I)),
    ("one_time_codes", re.compile(r"otp|\btac\b|2fa|one-time|verification|\bpin\b", re.I)),
    ("personal_identifiers", re.compile(r"mail|user|login|phone|mobile|\btel\b|nric|mykad|nokp|ssn|dob|birth|address|fullname|\bname\b|account", re.I)),
]


def field_categories(fields):
    """Data categories implied by input types/names. Values are never inspected."""
    out = set()
    for f in fields:
        t, name = f["type"], f"{f['name']} {f['autocomplete']}"
        if t == "password":
            out.add("credentials")
        elif t == "file":
            out.add("uploaded_files")
        elif t in ("hidden", "submit", "button", "checkbox", "radio", "image"):
            continue
        elif t in ("email", "tel"):
            out.add("personal_identifiers")
        for cat, rx in _FIELD_WORDS:
            if rx.search(name):
                out.add(cat)
    return sorted(out)


def _form_record(form, page_url, base):
    fields = []
    for el in form.find_all(["input", "textarea", "select"]):
        fields.append({"name": (el.get("name") or el.get("id") or "")[:40], "type": (el.get("type") or el.name).lower(),
                       "autocomplete": (el.get("autocomplete") or "").lower()})
    raw = (form.get("action") or "").strip()
    js_action = raw.lower().startswith("javascript:")
    action = page_url if not raw or raw.startswith("#") else (None if js_action else urljoin(base, raw))
    return {
        "page": page_url, "id": (form.get("id") or form.get("name") or "")[:40], "action": action,
        "action_declared": raw[:120], "javascript_action": js_action,
        "method": (form.get("method") or "get").lower(), "fields": fields,
        "categories": field_categories(fields), "has_password": any(f["type"] == "password" for f in fields),
        "onsubmit": bool(form.get("onsubmit")),
    }


_CREDIT = re.compile(r"(?:developed|designed|built|created|powered|made|website)\s+by\s+([^|•\n]{2,60})", re.I)
_DOMAIN_TEXT = re.compile(r"^(?:https?://)?(?:www\.)?([a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,})(?:/\S*)?$", re.I)


def _parse_doc(url, resp, corpus):
    soup = BeautifulSoup(resp.text, "html.parser")
    base_tag = soup.find("base", href=True)
    base = urljoin(url, base_tag["href"]) if base_tag else url
    doc = Doc(url=url, status=resp.status)
    doc.title = (soup.title.string or "").strip()[:200] if soup.title and soup.title.string else ""
    for m in soup.find_all("meta"):
        key = (m.get("name") or m.get("property") or "").lower()
        if key and m.get("content") and key in ("author", "generator", "application-name", "og:site_name", "og:title", "description", "copyright"):
            doc.meta[key] = m["content"][:200]
        if (m.get("http-equiv") or "").lower() == "refresh" and m.get("content"):
            doc.refresh = m["content"][:200]
    for form in soup.find_all("form"):
        doc.forms.append(_form_record(form, url, base))
    for a in soup.find_all("a", href=True):
        style = (a.get("style") or "").lower().replace(" ", "")
        hidden = any(s in style for s in ("display:none", "visibility:hidden", "opacity:0", "font-size:0", "width:0", "height:0")) or a.get("hidden") is not None
        href = a["href"].strip()
        if href.startswith(("javascript:", "mailto:", "tel:", "#", "data:")):
            continue
        doc.links.append({"text": a.get_text(" ", strip=True)[:120], "href": urljoin(base, href), "hidden": hidden})
    for f in soup.find_all("iframe"):
        style = (f.get("style") or "").lower().replace(" ", "")
        hidden = any(s in style for s in ("display:none", "visibility:hidden", "width:0", "height:0", "opacity:0")) or f.get("hidden") is not None \
            or f.get("width") in ("0", "1") or f.get("height") in ("0", "1")
        if f.get("src"):
            doc.iframes.append({"src": urljoin(base, f["src"].strip()), "hidden": hidden})
    for img in soup.find_all("img"):
        doc.images.append({"src": urljoin(base, img["src"].strip()) if img.get("src") else "", "alt": (img.get("alt") or "")[:80]})
    for tag in soup.find_all("link", href=True):
        rel = " ".join(tag.get("rel", []))
        if "icon" in rel:
            doc.images.append({"src": urljoin(base, tag["href"].strip()), "alt": "favicon"})
    for s in soup.find_all("script"):
        if s.get("src"):
            doc.script_srcs.append(urljoin(base, s["src"].strip()))
        elif s.string and "json" not in (s.get("type") or "").lower() and "template" not in (s.get("type") or "").lower():
            corpus.units.append(Unit("inline", url, base, s.string[:UNIT_CAP]))
    for tag in soup.find_all(True):
        for attr, val in tag.attrs.items():
            if attr.startswith("on") and isinstance(val, str) and val.strip():
                corpus.units.append(Unit("handler", url, base, val[:2000], attr))
    doc.headings = [h.get_text(" ", strip=True)[:100] for h in soup.find_all(["h1", "h2"])][:6]
    for s in soup(["script", "style", "noscript"]):
        s.decompose()
    doc.text = soup.get_text(" ", strip=True)[:8000]
    for m in _CREDIT.finditer(doc.text):
        doc.credits.append(" ".join(m.group(1).split())[:60])
    return doc


# ---------------------------------------------------------------------------------------------
# corpus


def build(ctx):
    """Fetch and parse the pages and scripts the two modules analyse. Cached on the scan context."""
    cached = ctx.__dict__.get("_clientside")
    if cached is not None:
        return cached
    corpus = Corpus()
    home = ctx.home()
    if not home.reached:
        corpus.errors.append(home.blocked or home.error or "target unreachable")
        ctx.__dict__["_clientside"] = corpus
        return corpus
    final = home.url
    if home.blocked:
        corpus.errors.append(f"redirect not followed: {home.blocked}")
    docs_urls = [final]
    if "html" in home.content_type or not home.content_type:
        corpus.docs.append(_parse_doc(final, home, corpus))
    try:
        crawl = ctx.crawl()
        ranked = sorted(crawl.pages.values(), key=lambda p: (not any(f["has_password"] for f in p.forms), not p.forms, p.depth))
        for page in ranked:
            if len(docs_urls) >= MAX_PAGES:
                break
            if page.url in docs_urls or not ctx.scope.host_in_scope(urlsplit(page.url).hostname):
                continue
            resp = ctx.client.get(page.url)
            if resp.reached and "html" in resp.content_type:
                docs_urls.append(page.url)
                corpus.docs.append(_parse_doc(page.url, resp, corpus))
        files = dict(crawl.js_files)
    except BudgetExceeded as exc:
        corpus.errors.append(f"request budget reached while collecting pages: {exc}")
        files = {}

    wanted = []
    for d in corpus.docs:
        for src in d.script_srcs:
            if src not in files and src not in wanted:
                wanted.append(src)
    for src in wanted:
        host = urlsplit(src).hostname
        if not ctx.scope.host_in_scope(host):
            continue
        if len(files) >= 10 + MAX_EXTRA_SCRIPTS:
            break
        try:
            resp = ctx.client.get(src, max_bytes=1_000_000)
        except BudgetExceeded:
            corpus.errors.append("request budget reached while collecting scripts")
            break
        if resp.ok:
            files[src] = resp.text
    for url, text in files.items():
        corpus.units.append(Unit("file", url, url, text[:UNIT_CAP]))

    seen_ext = set()
    for d in corpus.docs:
        for src in d.script_srcs:
            host = urlsplit(src).hostname or ""
            if not ctx.scope.host_in_scope(host) and src not in seen_ext:
                seen_ext.add(src)
                corpus.external_scripts.append({"url": src, "host": host, "page": d.url, "fetched": False,
                                                "reason": "outside the authorized scope; referenced but not retrieved"})
            elif ctx.scope.host_in_scope(host) and src not in files:
                corpus.errors.append(f"in-scope script not retrieved: {src}")

    deduped, seen = [], set()
    for u in corpus.units:
        key = hashlib.sha1(f"{u.kind}|{u.attr}|{u.text}".encode("utf-8", "ignore")).hexdigest()
        if key not in seen:
            seen.add(key)
            deduped.append(u)
    corpus.units = deduped[:MAX_UNITS]
    _collect_sourcemaps(ctx, corpus)
    ctx.__dict__["_clientside"] = corpus
    return corpus


_MAP_REF = re.compile(r"//[#@]\s*sourceMappingURL=([^\s'\"]+)")


def _collect_sourcemaps(ctx, corpus):
    """Read only the list of source paths from in-scope source maps (never sourcesContent)."""
    for u in corpus.units:
        if u.kind != "file" or len(corpus.sourcemaps) >= MAX_MAPS:
            continue
        m = _MAP_REF.search(u.text[-600:])
        if not m or m.group(1).startswith("data:"):
            continue
        map_url = urljoin(u.origin, m.group(1))
        entry = {"script": u.origin, "map_url": map_url, "fetched": False, "sources_sample": [], "packages": []}
        if ctx.scope.host_in_scope(urlsplit(map_url).hostname):
            try:
                resp = ctx.client.get(map_url, max_bytes=1_500_000)
                data = json.loads(resp.text) if resp.ok else {}
                sources = [str(s) for s in data.get("sources", [])][:400]
                entry["fetched"] = bool(sources)
                entry["sources_sample"] = [clean(s, 100) for s in sources[:12]]
                entry["packages"] = sorted({re.search(r"node_modules/((?:@[^/]+/)?[^/]+)", s).group(1) for s in sources if "node_modules/" in s})[:30]
            except (ValueError, BudgetExceeded):
                pass
        corpus.sourcemaps.append(entry)


# ---------------------------------------------------------------------------------------------
# JavaScript scanning helpers


def balanced(text, start, opener="(", closer=")", limit=6000):
    """Text between the delimiter at text[start] and its match, or None when unbalanced."""
    depth, quote, i = 0, None, start
    end = min(len(text), start + limit)
    while i < end:
        ch = text[i]
        if quote:
            if ch == "\\":
                i += 2
                continue
            if ch == quote:
                quote = None
        elif ch in "'\"`":
            quote = ch
        elif ch == opener:
            depth += 1
        elif ch == closer:
            depth -= 1
            if depth == 0:
                return text[start + 1:i]
        i += 1
    return None


def split_args(s):
    out, depth, quote, cur = [], 0, None, []
    i = 0
    while i < len(s):
        ch = s[i]
        if quote:
            cur.append(ch)
            if ch == "\\" and i + 1 < len(s):
                cur.append(s[i + 1])
                i += 1
            elif ch == quote:
                quote = None
        elif ch in "'\"`":
            quote = ch
            cur.append(ch)
        elif ch in "([{":
            depth += 1
            cur.append(ch)
        elif ch in ")]}":
            depth -= 1
            cur.append(ch)
        elif ch == "," and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
        i += 1
    if "".join(cur).strip():
        out.append("".join(cur).strip())
    return out


_CONST = re.compile(r"""(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(['"`])((?:(?!\2)[^\n\\]){1,300})\2""")
_LITERAL = re.compile(r"""^\s*(['"`])((?:(?!\1)[^\\\n]|\\.)*)(\1)?""")


def resolve_destination(expr, consts, base):
    """Best-effort destination for a request URL expression. Never executes anything."""
    if not expr:
        return {"url": None, "dynamic": True, "partial": False}
    expr = expr.strip()
    m = _LITERAL.match(expr)
    literal, partial = None, False
    if m:
        literal = m.group(2)
        rest = expr[m.end():].strip()
        partial = bool(rest) or "${" in literal
        if "${" in literal:
            literal = literal.split("${")[0]
    elif re.fullmatch(r"[A-Za-z_$][\w$]*", expr) and expr in consts:
        literal = consts[expr]
    if not literal:
        return {"url": None, "dynamic": True, "partial": False}
    if literal.startswith("//"):
        literal = "https:" + literal
    url = urljoin(base, literal) if not re.match(r"^(?:https?|wss?)://", literal, re.I) else literal
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https", "ws", "wss") or not parts.hostname:
        return {"url": None, "dynamic": True, "partial": False}
    return {"url": url, "dynamic": False, "partial": partial}


_USER_EVENT = re.compile(r"click|submit|change|keydown|keyup|keypress|input|tap|touch|press|button|btn|dblclick|pointer|mousedown", re.I)
_AUTO_EVENT = re.compile(r"DOMContentLoaded|\bload\b|onload|ready\s*\(|setTimeout|setInterval|requestAnimationFrame|visibilitychange|pageshow", re.I)


def trigger_of(unit, pos):
    """Heuristic: user_gesture_handler | automatic_on_load | unknown_trigger. Static guess only."""
    if unit.kind == "handler":
        return "user_gesture_handler" if _USER_EVENT.search(unit.attr) else "unknown_trigger"
    text, depth, i, heads = unit.text, 0, pos, []
    lo = max(0, pos - 6000)
    while i > lo and len(heads) < 4:
        i -= 1
        ch = text[i]
        if ch == "}":
            depth += 1
        elif ch == "{":
            if depth == 0:
                heads.append(text[max(0, i - 90):i])
            else:
                depth -= 1
    for h in heads:
        if _USER_EVENT.search(h):
            return "user_gesture_handler"
        if _AUTO_EVENT.search(h):
            return "automatic_on_load"
    return "automatic_on_load" if not heads else "unknown_trigger"


# ---------------------------------------------------------------------------------------------
# sinks (network-capable code)

_SINKS = [
    ("fetch", re.compile(r"(?<![\w.$])fetch\s*\(")),
    ("xhr", re.compile(r"\.open\s*\(")),
    ("beacon", re.compile(r"\bsendBeacon\s*\(")),
    ("websocket", re.compile(r"\bnew\s+WebSocket\s*\(")),
    ("ajax", re.compile(r"(?:\$|jQuery)\s*\.\s*(?:ajax|post|get|getJSON)\s*\(")),
    ("axios", re.compile(r"\baxios\s*(?:\.\s*(?:post|get|put|patch|request)\s*)?\(")),
]
_IMAGE_BEACON = re.compile(r"new\s+Image\s*\(\s*\)\s*\.\s*src\s*=")
_METHOD = re.compile(r"""(?:method|type)\s*:\s*['"`](\w+)['"`]""", re.I)


@dataclass
class Sink:
    kind: str
    method: str
    dest: dict
    args: str
    pos: int
    end: int
    unit: Unit
    trigger: str

    @property
    def line(self):
        return line_of(self.unit.text, self.pos)


def find_sinks(unit, consts):
    t, out = unit.text, []
    for kind, rx in _SINKS:
        for m in rx.finditer(t):
            args = balanced(t, m.end() - 1)
            if args is None:
                continue
            parts = split_args(args)
            if not parts:
                continue
            method, expr = "GET", parts[0]
            if kind == "xhr":
                mm = re.match(r"""\s*['"](GET|POST|PUT|PATCH|DELETE)['"]""", parts[0], re.I)
                if not mm or len(parts) < 2:
                    continue
                method, expr = mm.group(1).upper(), parts[1]
            elif kind == "beacon":
                method = "POST"
            elif kind == "websocket":
                method = "WS"
            elif kind in ("fetch", "axios", "ajax"):
                opts = " ".join(parts[1:]) if kind != "ajax" or not parts[0].startswith("{") else parts[0]
                mm = _METHOD.search(opts)
                if mm:
                    method = mm.group(1).upper()
                elif kind == "axios" and re.search(r"\.\s*(post|put|patch)\s*\($", t[m.start():m.end()]):
                    method = re.search(r"\.\s*(post|put|patch)", t[m.start():m.end()]).group(1).upper()
                elif kind == "ajax" and re.search(r"\.\s*post\s*\($", t[m.start():m.end()]):
                    method = "POST"
                elif kind in ("fetch",) and len(parts) > 1 and re.search(r"\bbody\s*:", parts[1]):
                    method = "POST"
                if kind == "ajax" and parts[0].startswith("{"):
                    um = re.search(r"\burl\s*:\s*([^,}]+)", parts[0])
                    expr = um.group(1) if um else ""
                if kind == "axios" and parts[0].startswith("{"):
                    um = re.search(r"\burl\s*:\s*([^,}]+)", parts[0])
                    expr = um.group(1) if um else ""
            out.append(Sink(kind, method, resolve_destination(expr, consts, unit.base), args, m.start(), m.end() + len(args) + 1, unit, trigger_of(unit, m.start())))
    for m in _IMAGE_BEACON.finditer(t):
        end = t.find(";", m.end())
        expr = t[m.end(): end if end > 0 else m.end() + 200]
        out.append(Sink("image_beacon", "GET", resolve_destination(expr, consts, unit.base), expr, m.start(), m.end() + len(expr), unit, trigger_of(unit, m.start())))
    return out


# ---------------------------------------------------------------------------------------------
# sensitive access points

# key: (category, label, ref regex, call regex or None, prompts for permission)
CAPABILITIES = {
    "camera_microphone": ("camera_microphone", "camera/microphone", r"\bmediaDevices\b|getUserMedia", r"getUserMedia\s*\(", True),
    "screen_capture": ("screen_capture", "screen capture", r"getDisplayMedia", r"getDisplayMedia\s*\(", True),
    "media_recording": ("camera_microphone", "MediaRecorder", r"new\s+MediaRecorder\b|\bMediaRecorder\b", r"new\s+MediaRecorder\s*\(", False),
    "geolocation": ("geolocation", "geolocation", r"navigator\s*\.\s*geolocation|getCurrentPosition|watchPosition", r"(?:getCurrentPosition|watchPosition)\s*\(", True),
    "clipboard_read": ("clipboard_content", "clipboard read", r"clipboard\s*\.\s*(?:readText|read)\b", r"clipboard\s*\.\s*(?:readText|read)\s*\(", True),
    "clipboard_events": ("clipboard_content", "clipboard events", r"addEventListener\s*\(\s*['\"](?:paste|copy|cut)['\"]|\bonpaste\b|\boncopy\b", None, False),
    "clipboard_write": ("clipboard_content", "clipboard write", r"clipboard\s*\.\s*(?:writeText|write)\b", r"clipboard\s*\.\s*(?:writeText|write)\s*\(", False),
    "notifications": ("notifications", "notifications/push", r"Notification\s*\.\s*requestPermission|pushManager\s*\.\s*subscribe", r"(?:Notification\s*\.\s*requestPermission|pushManager\s*\.\s*subscribe)\s*\(", True),
    "device_motion": ("device_motion", "device motion/orientation", r"devicemotion|deviceorientation|DeviceMotionEvent|DeviceOrientationEvent", None, False),
    "file_read": ("uploaded_files", "file reading", r"new\s+FileReader\s*\(|\.readAs(?:DataURL|Text|ArrayBuffer)\b|showOpenFilePicker|webkitdirectory", r"new\s+FileReader\s*\(|showOpenFilePicker\s*\(", False),
    "service_worker": ("persistence", "service worker", r"serviceWorker\s*\.\s*register", r"serviceWorker\s*\.\s*register\s*\(", False),
    "background_sync": ("persistence", "background/periodic sync", r"\.sync\s*\.\s*register|periodicSync", r"\.(?:sync|periodicSync)\s*\.\s*register\s*\(", False),
    "persistent_storage": ("browser_storage", "persistent storage", r"\b(?:local|session)Storage\b|indexedDB\s*\.\s*open", None, False),
    "cookie_read": ("session_values", "document.cookie", r"document\s*\.\s*cookie", None, False),
    "keystroke_listeners": ("keystrokes", "keyboard listeners", r"addEventListener\s*\(\s*['\"](?:keydown|keypress|keyup)['\"]|\bonkey(?:down|press|up)\b", None, False),
    "canvas_readback": ("browser_fingerprint", "canvas read-back", r"\.toDataURL\s*\(|\.getImageData\s*\(|\.toBlob\s*\(", r"\.(?:toDataURL|getImageData|toBlob)\s*\(", False),
}
PROMPTING = {k for k, v in CAPABILITIES.items() if v[4]}

FINGERPRINT = {  # key: (strong?, regex)
    "audio_context": (True, r"OfflineAudioContext|createOscillator|createDynamicsCompressor"),
    "webgl_renderer": (True, r"WEBGL_debug_renderer_info|UNMASKED_(?:RENDERER|VENDOR)_WEBGL"),
    "plugin_list": (True, r"navigator\s*\.\s*(?:plugins|mimeTypes)"),
    "webrtc_candidates": (True, r"RTCPeerConnection|webkitRTCPeerConnection"),
    "device_enumeration": (True, r"enumerateDevices\s*\("),
    "battery": (True, r"getBattery\s*\("),
    "font_probing": (True, r"document\s*\.\s*fonts\s*\.\s*check|measureText\s*\("),
    "hardware_concurrency": (False, r"hardwareConcurrency"),
    "device_memory": (False, r"deviceMemory"),
    "screen_metrics": (False, r"screen\s*\.\s*(?:width|height|colorDepth|availWidth)"),
    "timezone": (False, r"getTimezoneOffset|resolvedOptions\s*\(\s*\)\s*\.\s*timeZone"),
    "language_list": (False, r"navigator\s*\.\s*languages"),
}
_FP_COMPILED = {k: (s, re.compile(rx)) for k, (s, rx) in FINGERPRINT.items()}
_CAP_COMPILED = {k: (v[0], v[1], re.compile(v[2]), re.compile(v[3]) if v[3] else None, v[4]) for k, v in CAPABILITIES.items()}

_ELEMENT_VAR = re.compile(r"""(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:document\s*\.\s*)?(?:getElementById|querySelector|getElementsByName)\s*\(\s*(['"`])(.*?)\2\s*\)""")
_FIELD_READ = re.compile(r"""(?:getElementById|querySelector(?:All)?|getElementsByName|\$)\s*\(\s*(['"`])([^'"`]{1,80})\1\s*\)(?:\s*\[\d+\])?\s*\.\s*(?:value|val\s*\(\s*\))""")
_FORM_SERIALIZE = re.compile(r"new\s+FormData\s*\(|\.serialize(?:Array)?\s*\(|new\s+URLSearchParams\s*\(\s*(?:new\s+FormData|form|this)")
_STORAGE_GET = re.compile(r"""(?:local|session)Storage\s*\.\s*getItem\s*\(\s*(['"`])([^'"`]{1,60})\1""")
_SENSITIVE_KEY = re.compile(r"token|auth|session|jwt|passw|secret|credential|bearer", re.I)
_CALLBACK = re.compile(r"""(?:async\s*)?(?:function\s*\w*\s*\(\s*([\w$]+)|\(?\s*([\w$]+)\s*\)?\s*=>)""")
_ASSIGN_PREFIX = re.compile(r"""(?:const|let|var)?\s*([A-Za-z_$][\w$.]*)\s*=\s*(?:await\s+)?[^=;]*$""")


def classify_selector(sel):
    s = sel.lower()
    if re.search(r"pass|pwd|passwd", s):
        return "credentials"
    for cat, rx in _FIELD_WORDS:
        if rx.search(s):
            return cat
    return "form_fields"


@dataclass
class Access:
    key: str
    category: str
    label: str
    state: str        # capability_detected | permission_requested | data_collection_inferred
    unit: Unit
    pos: int
    end: int
    trigger: str
    taint: set
    detail: str = ""

    @property
    def line(self):
        return line_of(self.unit.text, self.pos)


def _assigned_name(text, start):
    prefix = text[max(0, text.rfind("\n", 0, start), text.rfind(";", 0, start), text.rfind("{", 0, start)) + 1:start]
    m = _ASSIGN_PREFIX.search(prefix)
    return m.group(1) if m else None


def _callback_names(text, end):
    """Parameter names of a callback passed to the call that starts right after `end`, or chained with .then()."""
    pos = text.find("(", end, end + 40)
    if pos < 0:
        return set()
    args = balanced(text, pos)
    if args is None:
        return set()
    names = set()
    first = _CALLBACK.match(args.strip())
    if first:
        names.add(next(g for g in first.groups() if g))
    chained = re.match(r"\s*\.then\s*\(\s*" + _CALLBACK.pattern, text[pos + len(args) + 2:pos + len(args) + 160])
    if chained:
        names.update(g for g in chained.groups() if g)
    return names


def _taint_names(text, start, end, callbacks=False, handlers=False):
    names = set()
    assigned = _assigned_name(text, start)
    if assigned:
        names.add(assigned)
    if callbacks:
        names |= _callback_names(text, end)
    if handlers:
        hm = re.search(r"\.on(?:load|dataavailable)\s*=\s*" + _CALLBACK.pattern, text[end:end + 700])
        if hm:
            names.update(g for g in hm.groups() if g)
    return {n for n in names if n and n not in ("this", "function", "async")}


def _listener_taints(text, end):
    """Variables that accumulate event data inside a key/paste listener (e.g. buf += e.key)."""
    brace = text.find("{", end, end + 250)
    body = balanced(text, brace, "{", "}", 2500) if brace >= 0 else None
    if not body or not re.search(r"\.(?:key|keyCode|which|code|data)\b|getData", body):
        return set()
    names = {m.group(1) for m in re.finditer(r"([A-Za-z_$][\w$.]*)\s*\+=", body)}
    names |= {m.group(1) for m in re.finditer(r"([A-Za-z_$][\w$.]*)\.push\s*\(", body)}
    names |= {m.group(1) for m in re.finditer(r"([A-Za-z_$][\w$]*)\s*=\s*[^;]*clipboardData\s*\.\s*getData\s*\(", body)}
    return names


def find_accesses(unit, doc_has_password):
    t, out = unit.text, []
    elem_vars = {m.group(1): m.group(3) for m in _ELEMENT_VAR.finditer(t)}
    has_video_frame = bool(re.search(r"getUserMedia|drawImage\s*\(\s*\w*video", t))
    for key, (cat, label, ref, call, prompts) in _CAP_COMPILED.items():
        found = []
        for m in ref.finditer(t):
            is_call = bool(call and call.match(t, m.start()))
            found.append((m, is_call))
        if any(c for _, c in found):
            found = [x for x in found if x[1]]
        for m, is_call in found[:3]:
            category, label_ = (("camera_microphone", "camera frame capture") if key == "canvas_readback" and has_video_frame else (cat, label))
            taint = set()
            if is_call or key in ("persistent_storage", "cookie_read"):
                taint = _taint_names(t, m.start(), m.end(), callbacks=True, handlers=key in ("file_read", "media_recording"))
            if key in ("keystroke_listeners", "clipboard_events"):
                taint = _listener_taints(t, m.end())
            state = "capability_detected"
            if is_call and prompts:
                state = "permission_requested"
            if (is_call and taint and key in ("file_read", "media_recording", "canvas_readback", "clipboard_read", "camera_microphone")) \
                    or (taint and key in ("keystroke_listeners", "clipboard_events")):
                state = "data_collection_inferred"
            out.append(Access(key, category, label_, state, unit, m.start(), m.end(), trigger_of(unit, m.start()), taint,
                              "call" if is_call else "reference"))
    for m in _STORAGE_GET.finditer(t):
        if _SENSITIVE_KEY.search(m.group(2)):
            out.append(Access("storage_secret_read", "authentication_tokens", "stored token/session read", "data_collection_inferred", unit,
                              m.start(), m.end(), trigger_of(unit, m.start()), _taint_names(t, m.start(), m.end()), "key name suggests a credential"))
    for m in _FIELD_READ.finditer(t):
        cat = classify_selector(m.group(2))
        out.append(Access("form_field_read", cat, "form field read", "data_collection_inferred", unit, m.start(), m.end(),
                          trigger_of(unit, m.start()), _taint_names(t, m.start(), m.end()), "selector: " + clean(m.group(2), 40)))
    for var, sel in elem_vars.items():
        for m in re.finditer(r"\b" + re.escape(var) + r"\s*\.\s*(?:value|val\s*\(\s*\))", t):
            out.append(Access("form_field_read", classify_selector(sel), "form field read", "data_collection_inferred", unit, m.start(), m.end(),
                              trigger_of(unit, m.start()), _taint_names(t, m.start(), m.end()), "selector: " + clean(sel, 40)))
    for m in _FORM_SERIALIZE.finditer(t):
        out.append(Access("form_serialize", "credentials" if doc_has_password else "form_fields", "form serialization", "data_collection_inferred", unit,
                          m.start(), m.end(), trigger_of(unit, m.start()), _taint_names(t, m.start(), m.end()), "FormData/serialize"))
    return out


def fingerprint_hits(unit):
    hits = {}
    t = unit.text
    for key, (strong, rx) in _FP_COMPILED.items():
        m = rx.search(t)
        if m:
            hits[key] = {"strong": strong, "resource": unit.origin, "line": line_of(t, m.start()), "evidence": snippet(t, m.start(), 80)}
    if re.search(r"fillText\s*\(", t) and re.search(r"toDataURL|getImageData", t):
        m = re.search(r"toDataURL|getImageData", t)
        hits["canvas_text_readback"] = {"strong": True, "resource": unit.origin, "line": line_of(t, m.start()), "evidence": snippet(t, m.start(), 80)}
    return hits


# ---------------------------------------------------------------------------------------------
# correlation


def _contains_name(args, names):
    return next((n for n in names if re.search(r"(?<![\w$.])" + re.escape(n.split(".")[0]) + r"(?![\w$])", args)), None)


def correlate(access, sinks):
    """Link an access to sinks only with syntactic evidence (contained in the call, or a tainted variable used in it).
    Sharing a script is NOT enough."""
    out = []
    for s in sinks:
        if s.unit is not access.unit:
            continue
        if s.pos <= access.pos < s.end:
            out.append((s, "direct_expression", ""))
            continue
        if access.pos < s.pos <= access.pos + 3000 and access.taint:
            name = _contains_name(s.args, access.taint)
            if name:
                out.append((s, "tainted_variable", name))
    return out


# ---------------------------------------------------------------------------------------------
# whole-corpus analysis


@dataclass
class Analysis:
    sinks: list = field(default_factory=list)
    accesses: list = field(default_factory=list)
    links: list = field(default_factory=list)          # (Access, Sink, link_type, name)
    fingerprints: dict = field(default_factory=dict)
    listeners: list = field(default_factory=list)      # submit / key listeners with evidence
    obfuscation: list = field(default_factory=list)
    dynamic_loads: list = field(default_factory=list)
    banners: list = field(default_factory=list)
    interceptions: list = field(default_factory=list)  # submit handler that calls preventDefault and also holds a sink


_OBFUSCATION = [
    ("eval_packer", re.compile(r"eval\s*\(\s*function\s*\(\s*p\s*,\s*a\s*,\s*c\s*,\s*k")),
    ("obfuscator_identifiers", re.compile(r"\b_0x[0-9a-f]{4,6}\b")),
    ("eval_of_decoded_string", re.compile(r"eval\s*\(\s*(?:atob|unescape|decodeURIComponent|String\.fromCharCode)")),
    ("function_constructor", re.compile(r"new\s+Function\s*\(\s*(?:atob|unescape|['\"])")),
    ("document_write_script", re.compile(r"document\s*\.\s*write\s*\(\s*(?:unescape|atob|decodeURIComponent)")),
]
_DYNAMIC = [
    ("dynamic_import", re.compile(r"(?<![\w$.])import\s*\(\s*([^)]{1,200})\)")),
    ("importScripts", re.compile(r"importScripts\s*\(\s*([^)]{1,200})\)")),
    ("script_element_src", re.compile(r"createElement\s*\(\s*['\"]script['\"]\s*\)")),
]
_BANNER = re.compile(r"/\*[!*]?(.{0,600}?)\*/", re.S)
_REPO = re.compile(r"(?:github\.com|gitlab\.com|bitbucket\.org)/[\w.-]+/[\w.-]+")
_COPYRIGHT = re.compile(r"(?:\(c\)|©|copyright)\s*(?:\d{4}(?:\s*[-,]\s*\d{4})?\s*)?([A-Z][\w .,&'-]{2,60})", re.I)
_AUTHOR = re.compile(r"@author\s+([^\n*]{2,60})")


def analyze(corpus):
    a = Analysis()
    doc_has_password = any(f["has_password"] for d in corpus.docs for f in d.forms)
    for unit in corpus.units:
        t = unit.text
        consts = {m.group(1): m.group(3) for m in _CONST.finditer(t)}
        sinks = find_sinks(unit, consts)
        accesses = find_accesses(unit, doc_has_password)
        a.sinks += sinks
        a.accesses += accesses
        for acc in accesses:
            for sink, kind, name in correlate(acc, sinks):
                a.links.append((acc, sink, kind, name))
        for key, hit in fingerprint_hits(unit).items():
            a.fingerprints.setdefault(key, hit)
        for m in re.finditer(r"addEventListener\s*\(\s*['\"]submit['\"]|\bonsubmit\s*=|\.submit\s*\(", t):
            a.listeners.append({"type": "submit", "resource": unit.origin, "line": line_of(t, m.start()), "evidence": snippet(t, m.start(), 90)})
            body = balanced(t, t.find("{", m.end()), "{", "}", 3000) if "{" in t[m.end():m.end() + 200] else None
            if body and "preventDefault" in body:
                inner = [s for s in sinks if s.pos > m.start() and s.pos < m.start() + len(body) + 250]
                if inner:
                    a.interceptions.append({"resource": unit.origin, "line": line_of(t, m.start()), "sink": inner[0], "evidence": snippet(t, m.start(), 90)})
        for name, rx in _OBFUSCATION:
            m = rx.search(t)
            if name == "obfuscator_identifiers":
                if len(rx.findall(t)) < 10:
                    continue
            if m:
                a.obfuscation.append({"technique": name, "resource": unit.origin, "line": line_of(t, m.start()), "evidence": snippet(t, m.start(), 70)})
        if len(re.findall(r"\\x[0-9a-fA-F]{2}", t)) > 60:
            a.obfuscation.append({"technique": "dense_hex_escapes", "resource": unit.origin, "line": 1, "evidence": "more than 60 \\x escapes"})
        for name, rx in _DYNAMIC:
            for m in list(rx.finditer(t))[:3]:
                arg = m.group(1) if m.groups() else ""
                dest = resolve_destination(arg, consts, unit.base) if arg else {"url": None, "dynamic": True, "partial": False}
                if name == "script_element_src":
                    sm = re.search(r"\.src\s*=\s*([^;\n]{1,200})", t[m.end():m.end() + 400])
                    dest = resolve_destination(sm.group(1), consts, unit.base) if sm else dest
                a.dynamic_loads.append({"technique": name, "resource": unit.origin, "line": line_of(t, m.start()), "destination": dest.get("url"),
                                        "dynamic": dest["dynamic"], "evidence": snippet(t, m.start(), 90)})
        if unit.kind == "file":
            for m in list(_BANNER.finditer(t[:3000]))[:2]:
                body = " ".join(m.group(1).split())
                cr, au, rp = _COPYRIGHT.search(body), _AUTHOR.search(m.group(1)), _REPO.search(body)
                if cr or au or rp:
                    a.banners.append({"resource": unit.origin, "copyright": clean(cr.group(1), 60) if cr else None,
                                      "author": clean(au.group(1), 60) if au else None, "repository": rp.group(0) if rp else None,
                                      "banner": clean(body, 110)})
            for m in list(_REPO.finditer(t))[:2]:
                if not any(b["repository"] == m.group(0) for b in a.banners):
                    a.banners.append({"resource": unit.origin, "copyright": None, "author": None, "repository": m.group(0), "banner": snippet(t, m.start(), 80)})
    return a


def get_analysis(ctx):
    corpus = build(ctx)
    cached = ctx.__dict__.get("_clientside_analysis")
    if cached is None:
        cached = analyze(corpus)
        ctx.__dict__["_clientside_analysis"] = cached
    return corpus, cached
