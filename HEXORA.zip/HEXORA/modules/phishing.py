import re
import unicodedata
from urllib.parse import urlsplit

from core.models import ModuleResult
from core.scope import ip_problem
from modules import _clientside as cs
from modules import _intel as intel
from modules._common import mk

KEY = "phishing"
TITLE = "Phishing Check"
DESCRIPTION = "Brand impersonation, credential-form data flows and public threat-intelligence evidence."

REF = ["https://www.cisa.gov/shields-up/protect-yourself-phishing", "https://owasp.org/www-community/attacks/Phishing"]

# Small bundled reference of organizations that are commonly impersonated. It is not exhaustive: a brand missing
# from this table is simply not recognised, and an official domain missing from it can cause a false match.
# name, tokens (lowercase), official domains, ambiguous (a common English word, so text alone is weak evidence)
BRANDS = [
    ("PayPal", ["paypal"], ["paypal.com", "paypalobjects.com"], False),
    ("Microsoft", ["microsoft", "office365", "outlook", "onedrive"], ["microsoft.com", "live.com", "office.com", "microsoftonline.com", "outlook.com", "office365.com", "sharepoint.com", "onedrive.com"], False),
    ("Google", ["google", "gmail"], ["google.com", "gmail.com", "youtube.com"], False),
    ("Apple", ["apple", "icloud", "appleid"], ["apple.com", "icloud.com"], True),
    ("Amazon", ["amazon"], ["amazon.com", "amazon.co.uk", "amazon.de", "amazon.in", "amazon.com.au", "amazon.sg", "amazon.co.jp", "amazon.ca", "amazon.fr"], True),
    ("Facebook / Meta", ["facebook"], ["facebook.com", "fb.com", "meta.com", "messenger.com"], False),
    ("Instagram", ["instagram"], ["instagram.com"], False),
    ("WhatsApp", ["whatsapp"], ["whatsapp.com", "whatsapp.net"], False),
    ("Netflix", ["netflix"], ["netflix.com"], False),
    ("LinkedIn", ["linkedin"], ["linkedin.com"], False),
    ("DHL", ["dhl"], ["dhl.com"], False),
    ("FedEx", ["fedex"], ["fedex.com"], False),
    ("Binance", ["binance"], ["binance.com"], False),
    ("Coinbase", ["coinbase"], ["coinbase.com"], False),
    ("Telegram", ["telegram"], ["telegram.org", "t.me"], False),
    ("Dropbox", ["dropbox"], ["dropbox.com"], False),
    ("DocuSign", ["docusign"], ["docusign.com", "docusign.net"], False),
    ("Adobe", ["adobe"], ["adobe.com"], False),
    ("Steam", ["steampowered", "steamcommunity"], ["steampowered.com", "steamcommunity.com"], True),
    ("GitHub", ["github"], ["github.com"], False),
    ("Chase", ["chase"], ["chase.com"], True),
    ("Wells Fargo", ["wellsfargo"], ["wellsfargo.com"], False),
    ("Bank of America", ["bankofamerica"], ["bankofamerica.com"], False),
    ("HSBC", ["hsbc"], ["hsbc.com", "hsbc.com.my"], False),
    ("Maybank", ["maybank", "maybank2u"], ["maybank2u.com.my", "maybank.com", "maybank.com.my"], False),
    ("CIMB", ["cimb", "cimbclicks"], ["cimb.com.my", "cimbclicks.com.my", "cimb.com", "cimbbank.com.my"], False),
    ("Public Bank", ["pbebank"], ["pbebank.com"], False),
    ("RHB", ["rhbgroup", "rhbbank"], ["rhbgroup.com", "rhbbank.com.my"], False),
    ("Bank Islam", ["bankislam"], ["bankislam.com", "bankislam.com.my"], False),
    ("Bank Rakyat", ["bankrakyat"], ["bankrakyat.com.my"], False),
    ("AmBank", ["ambank"], ["ambankgroup.com", "ambank.com.my"], False),
    ("Hong Leong Bank", ["hongleong"], ["hlb.com.my", "hongleongconnect.my"], False),
    ("Touch 'n Go", ["touchngo", "tngdigital"], ["touchngo.com.my", "tngdigital.com.my"], False),
    ("Shopee", ["shopee"], ["shopee.com", "shopee.com.my", "shopee.sg"], False),
    ("Lazada", ["lazada"], ["lazada.com", "lazada.com.my", "lazada.sg"], False),
    ("Grab", ["grab"], ["grab.com"], True),
    ("Pos Malaysia", ["posmalaysia"], ["pos.com.my"], False),
    ("J&T Express", ["jtexpress"], ["jtexpress.my"], False),
    ("LHDN", ["lhdn", "hasil"], ["hasil.gov.my"], True),
    ("Tenaga Nasional", ["mytnb"], ["tnb.com.my", "mytnb.com.my"], False),
    ("Maxis", ["maxis"], ["maxis.com.my"], False),
    ("CelcomDigi", ["celcomdigi"], ["celcomdigi.com"], False),
]

_TLD_WEAK = {"tk", "ml", "ga", "cf", "gq", "top", "xyz", "click", "zip", "mov", "icu", "cyou", "buzz", "rest", "work", "support"}
_HOST_WORDS = re.compile(r"login|signin|secure|verify|update|account|wallet|banking|webmail", re.I)
_CONFUSABLE = str.maketrans({
    "0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b", "$": "s", "а": "a", "е": "e", "о": "o", "р": "p", "с": "c",
    "х": "x", "у": "y", "і": "i", "ј": "j", "ѕ": "s", "ο": "o", "ν": "v", "ɑ": "a", "ı": "i", "ӏ": "l",
})

VERDICT_LABEL = {
    "phishing_confirmed": "Phishing confirmed", "phishing_probable": "Phishing probable", "phishing_suspected": "Phishing suspected",
    "no_phishing_indicators_detected": "No phishing indicators detected", "inconclusive": "Inconclusive",
}
_RISK = {"phishing_confirmed": "critical", "phishing_probable": "high", "phishing_suspected": "medium", "inconclusive": "low", "no_phishing_indicators_detected": "none"}
_SEV = {"phishing_confirmed": "critical", "phishing_probable": "high", "phishing_suspected": "medium", "inconclusive": "informational"}
_STATUS = {"phishing_confirmed": "confirmed", "phishing_probable": "probable", "phishing_suspected": "potential", "inconclusive": "inconclusive"}


# ---------------------------------------------------------------------------------------------
# domain analysis


def skeleton(label):
    s = unicodedata.normalize("NFKC", label).lower().translate(_CONFUSABLE)
    return s.replace("rn", "m").replace("vv", "w").replace("-", "")


def distance(a, b):
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def is_official(host, domains):
    return any(host == d or host.endswith("." + d) for d in domains)


def decode_idn(host):
    try:
        return host.encode("ascii").decode("idna")
    except UnicodeError:
        return host


def domain_signals(host):
    """Lookalike observations for a hostname: [{brand, technique, weight, detail}]. Official domains never match."""
    host = host.lower().rstrip(".")
    reg = intel.registrable(host)
    reg_labels = reg.split(".")
    sld = decode_idn(reg_labels[0])
    sub = [decode_idn(x) for x in host[: -len(reg)].rstrip(".").split(".") if x] if host != reg else []
    out = []
    for name, tokens, domains, ambiguous in BRANDS:
        if is_official(host, domains):
            continue
        toks = set(tokens) | {d.split(".")[0] for d in domains}
        best = None
        for tok in toks:
            parts = [p for p in re.split(r"[-_]", sld) if p]
            if any(tok in re.split(r"[-_]", s) for s in sub):
                cand = ("brand_in_subdomain", 3.0, f"'{tok}' appears as a subdomain label of the unrelated domain {reg}")
            elif sld == tok:
                cand = ("same_name_different_suffix", 2.5, f"'{sld}' matches the brand name but {reg} is not an official domain")
            elif tok in parts:
                cand = ("brand_token_in_domain", 2.5, f"'{tok}' is a word inside {reg}")
            elif not ambiguous and len(tok) >= 6 and tok in sld:
                cand = ("brand_token_in_domain", 2.0, f"'{tok}' is embedded in {reg}")
            elif any(skeleton(p) == skeleton(tok) and p != tok for p in [sld, *parts]):
                cand = ("homograph_or_digit_substitution", 3.0, f"a word in '{sld}' reduces to '{tok}' after normalising look-alike characters")
            elif len(tok) >= 5 and any(0 < distance(p, tok) <= (1 if len(tok) < 8 else 2) for p in [sld, *parts]):
                near = min([sld, *parts], key=lambda p: distance(p, tok))
                cand = ("edit_distance", 2.5, f"'{near}' is within edit distance {distance(near, tok)} of '{tok}'")
            else:
                continue
            if best is None or cand[1] > best[1]:
                best = cand
        if best:
            out.append({"brand": name, "official_domains": domains, "technique": best[0], "weight": best[1], "detail": best[2]})
    return out


def structure_signals(host, cred):
    out = []
    reg = intel.registrable(host)
    if re.fullmatch(r"[\d.]+", host) or ":" in host:
        if not ip_problem(host):
            out.append(("ip_literal_host", 1.0, "The site is addressed by a public IP literal instead of a domain name"))
        return out
    if "xn--" in host:
        out.append(("punycode_label", 0.5, f"Internationalized label in {host} (decodes to {decode_idn(host)[:60]})"))
    if len(host[: -len(reg)].rstrip(".").split(".")) >= 4:
        out.append(("many_subdomains", 0.5, "Four or more subdomain labels"))
    if cred and host.rsplit(".", 1)[-1] in _TLD_WEAK:
        out.append(("weak_reputation_tld", 0.5, f"TLD .{host.rsplit('.', 1)[-1]} is frequently abused; legitimate sites use it too"))
    if cred and _HOST_WORDS.search(host):
        out.append(("credential_words_in_host", 0.5, "Hostname contains words such as login/secure/verify"))
    return out


# ---------------------------------------------------------------------------------------------
# page impersonation


def brand_text_signals(corpus, brand):
    name, tokens, domains, ambiguous = brand
    rx = re.compile(r"\b(?:" + "|".join(re.escape(t) for t in tokens) + r")\b", re.I)
    found = {}
    for d in corpus.docs:
        if rx.search(d.title):
            found.setdefault("title", f"<title> mentions {name}")
        for key in ("og:site_name", "application-name", "og:title"):
            if rx.search(d.meta.get(key, "")):
                found.setdefault("site_name_meta", f"{key} metadata mentions {name}")
        if any(rx.search(h) for h in d.headings):
            found.setdefault("heading", f"A page heading mentions {name}")
        for img in d.images:
            blob = f"{img['alt']} {urlsplit(img['src']).path.rsplit('/', 1)[-1]}"
            if rx.search(blob) and re.search(r"logo|brand|icon", blob, re.I):
                found.setdefault("logo_image", f"Logo image references {name}")
        if re.search(r"(?:©|copyright)[^.]{0,40}\b(?:" + "|".join(re.escape(t) for t in tokens) + r")\b", d.text, re.I):
            found.setdefault("copyright_notice", f"Copyright notice names {name}")
        if re.search(r"(?:sign|log)\s*in\s+to\s+(?:your\s+)?(?:" + "|".join(re.escape(t) for t in tokens) + r")\b", d.text, re.I):
            found.setdefault("signin_phrase", f"Sign-in wording names {name}")
    return found


def brand_asset_hotlinks(corpus, brand):
    domains = brand[2]
    hits = set()
    for d in corpus.docs:
        for src in [i["src"] for i in d.images] + d.script_srcs:
            host = (urlsplit(src).hostname or "").lower()
            if host and is_official(host, domains):
                hits.add(host)
    return sorted(hits)


def _anchor_mismatches(corpus):
    out = []
    for d in corpus.docs:
        for a in d.links:
            m = cs._DOMAIN_TEXT.match(a["text"].strip())
            href_host = (urlsplit(a["href"]).hostname or "").lower()
            if m and href_host and intel.registrable(m.group(1).lower()) != intel.registrable(href_host):
                out.append({"page": d.url, "text": cs.clean(a["text"], 60), "href_host": href_host})
    return out


# ---------------------------------------------------------------------------------------------
# scoring

CAPS = {"impersonation": 4.5, "domain": 4.5, "exfiltration": 6.0, "page_deception": 3.0, "kit_technique": 3.0, "infrastructure": 1.5, "threat_intelligence": 10.0}
NEUTRAL_CLASSES = {"identity_provider", "payment_provider", "analytics", "advertising", "session_replay", "cdn_library", "first_party", "first_party_other_origin"}


def _dest_weight(cls, categories):
    """Weight for credential-bearing data leaving for an unrelated destination. Neutral services score zero."""
    cred = "credentials" in categories
    card = bool({"payment_card_details", "one_time_codes"} & set(categories))
    if cls in NEUTRAL_CLASSES:
        return 0.0, "neutral"
    if cls in ("messaging_webhook_api", "request_capture_or_tunnel"):
        return (5.0 if cred or card else 2.0), "drop_like_service"
    if cls == "form_processing_service":
        return (2.5 if cred else 1.0 if card else 0.3), "form_service"
    if cls == "shared_hosting_platform":
        return (2.5 if cred else 1.0 if card else 0.3), "shared_platform"
    return (3.0 if cred else 1.5 if card else 0.5), "unrelated_destination"


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    corpus, analysis = cs.get_analysis(ctx)
    if not corpus.docs:
        r.status = "failed"
        r.error = corpus.errors[0] if corpus.errors else "no HTML page could be retrieved"
        r.not_performed("Phishing assessment: no page content was available.")
        return r
    net = intel.network_context(ctx)
    t = ctx.target
    indicators, flows, uncertainty = [], [], []

    def add(ind, category, weight, detail, resource="", **extra):
        indicators.append({"indicator": ind, "category": category, "weight": weight, "detail": detail, "resource": resource, **extra})

    # --- forms and credential context
    cred_forms = [f for d in corpus.docs for f in d.forms if f["has_password"] or {"payment_card_details", "one_time_codes"} & set(f["categories"])]
    credential_script_reads = [a for a in analysis.accesses if a.key == "form_field_read" and a.category in ("credentials", "payment_card_details", "one_time_codes")]
    cred = bool(cred_forms or credential_script_reads)
    r.performed(f"Parsed {len(corpus.docs)} page(s), {sum(len(d.forms) for d in corpus.docs)} form(s) and {len(corpus.units)} script unit(s) without executing any code.")

    # --- domain analysis
    lookalikes = domain_signals(t.hostname)
    for s in structure_signals(t.hostname, cred):
        add(s[0], "domain", s[1], s[2], t.hostname)
    r.performed("Compared the hostname with a bundled list of commonly impersonated brands (token, edit-distance and look-alike-character checks).")

    # --- brand impersonation
    brand_hits = []
    for brand in BRANDS:
        if is_official(t.hostname, brand[2]):
            continue
        text = brand_text_signals(corpus, brand)
        look = [x for x in lookalikes if x["brand"] == brand[0]]
        hot = brand_asset_hotlinks(corpus, brand)
        n = len(text)
        if brand[3] and n < 2 and not look:
            continue
        if n or look:
            brand_hits.append({"brand": brand, "text": text, "look": look, "hot": hot})
    brand_hits.sort(key=lambda h: (len(h["text"]) + (3 if h["look"] else 0), len(h["hot"])), reverse=True)
    primary = brand_hits[0] if brand_hits else None
    if primary:
        n = len(primary["text"])
        name = primary["brand"][0]
        if n >= 1:
            w = 4.0 if n >= 3 else 3.0 if n == 2 else 1.0
            add("brand_text_impersonation", "impersonation", w, f"{n} independent page signal(s) reference {name}: " + "; ".join(primary["text"].values()), t.url)
        if primary["hot"]:
            add("brand_asset_hotlinking", "impersonation", 1.0, f"Page loads resources from official {name} hosts ({', '.join(primary['hot'][:3])}); partners do this too", t.url)
        for x in primary["look"]:
            add("lookalike_domain", "domain", x["weight"], x["detail"], t.hostname, technique=x["technique"])

    # --- anchors, frames, redirects
    for m in _anchor_mismatches(corpus)[:3]:
        add("misleading_link_text", "page_deception", 1.5, f"Link text '{m['text']}' points to {m['href_host']}", m["page"])
    for d in corpus.docs:
        for a in d.links:
            if a["hidden"] and intel.registrable(urlsplit(a["href"]).hostname or "") != intel.registrable(t.hostname):
                add("hidden_cross_origin_link", "page_deception", 1.0, f"Hidden link to {urlsplit(a['href']).hostname}", d.url)
        for f in d.iframes:
            if f["hidden"] and not ctx.scope.host_in_scope(urlsplit(f["src"]).hostname):
                add("hidden_cross_origin_iframe", "page_deception", 1.5, f"Hidden iframe loading {urlsplit(f['src']).hostname}", d.url)
        if d.refresh and re.search(r"url\s*=\s*https?://", d.refresh, re.I):
            host = (urlsplit(re.search(r"url\s*=\s*([^\s;]+)", d.refresh, re.I).group(1)).hostname or "")
            if host and not ctx.scope.host_in_scope(host):
                add("meta_refresh_cross_origin", "page_deception", 1.0, f"Meta refresh to {host}", d.url)
    if net["redirect_refused"]:
        rh = (urlsplit(net["redirect_refused"]).hostname or "")
        if rh and intel.registrable(rh) != intel.registrable(t.hostname):
            add("cross_domain_redirect", "page_deception", 0.5, f"The start page redirects to {rh} (outside scope, not followed); common for legitimate sites too", t.url)

    # --- form data flows (markup)
    for f in cred_forms + [f for d in corpus.docs for f in d.forms if f not in cred_forms and f["categories"]]:
        if not f["action"]:
            continue
        categories = [c for c in f["categories"] if c != "personal_identifiers"] + (["personal_identifiers"] if "personal_identifiers" in f["categories"] else [])
        rec = intel.flow_record(
            ctx, source=f"form on {f['page']} (id: {f['id'] or 'none'}, fields: {', '.join(x['type'] for x in f['fields'])[:80]})",
            data_category=", ".join(categories) or "form_fields", dest_url=f["action"], method=f["method"].upper(), observation_type="source_reference",
            evidence=[f"<form action=\"{cs.clean(f['action_declared'] or '(empty)', 100)}\" method=\"{f['method']}\">"], confidence="high" if f["has_password"] else "medium",
            page=f["page"], unresolved=["Was the form submitted by users?", "Does a script change the destination at submit time?"])
        flows.append(rec)
        if cred and (f in cred_forms) and rec["origin_relation"] != "same_origin":
            w, kind = _dest_weight(rec["destination_class"], f["categories"])
            if w:
                add("credential_form_to_unrelated_destination", "exfiltration", w, f"Form with {', '.join(f['categories'])} fields targets {rec['destination_hostname']} ({kind.replace('_', ' ')})",
                    f["page"], destination=rec["destination_hostname"], destination_class=rec["destination_class"])

    # --- script data flows
    seen = set()
    for acc, sink, how, name in analysis.links:
        if acc.category not in ("credentials", "payment_card_details", "one_time_codes", "personal_identifiers", "form_fields"):
            continue
        key = (acc.category, sink.dest.get("url"), sink.kind, sink.unit.origin)
        if key in seen:
            continue
        seen.add(key)
        conf = "medium" if sink.dest.get("url") and not sink.dest.get("partial") else "low"
        rec = intel.flow_record(
            ctx, source=f"script {sink.unit.origin}:{sink.line} ({sink.kind})", data_category=acc.category, dest_url=sink.dest.get("url"), method=sink.method,
            observation_type="statically_inferred" if not sink.dest["dynamic"] else "unresolved_dynamic",
            evidence=[f"{acc.label} (line {acc.line}) -> {sink.kind}() via {how.replace('_', ' ')}" + (f" '{name}'" if name else ""), cs.snippet(sink.unit.text, sink.pos, 90)],
            confidence=conf, page=sink.unit.origin, trigger=sink.trigger)
        flows.append(rec)
        if rec["origin_relation"] != "same_origin" and rec["destination_url"]:
            w, kind = _dest_weight(rec["destination_class"], [acc.category])
            if w:
                add("script_forwards_form_data", "exfiltration", w, f"Script sends {acc.category} to {rec['destination_hostname']} ({kind.replace('_', ' ')})", sink.unit.origin,
                    destination=rec["destination_hostname"], destination_class=rec["destination_class"])
        elif not rec["destination_url"]:
            uncertainty.append(f"A script forwards {acc.category} to a destination that could not be resolved statically ({sink.unit.origin}:{sink.line}).")
    for ic in analysis.interceptions:
        s = ic["sink"]
        if cred and not any(fl["source"].startswith(f"script {s.unit.origin}:{s.line}") for fl in flows):
            rec = intel.flow_record(ctx, source=f"script {s.unit.origin}:{s.line} (submit handler)", data_category="credentials", dest_url=s.dest.get("url"), method=s.method,
                                    observation_type="statically_inferred" if s.dest.get("url") else "unresolved_dynamic",
                                    evidence=["submit handler calls preventDefault() and sends a request itself", ic["evidence"]], confidence="low", page=s.unit.origin)
            flows.append(rec)
            if rec["origin_relation"] not in ("same_origin", "unresolved"):
                w, _ = _dest_weight(rec["destination_class"], ["credentials"])
                if w:
                    add("submit_intercepted_and_resent", "exfiltration", w, f"Submit handler replaces normal submission and calls {rec['destination_hostname']}", s.unit.origin,
                        destination=rec["destination_hostname"], destination_class=rec["destination_class"])
            elif rec["origin_relation"] == "unresolved":
                uncertainty.append("A submit handler intercepts the form and sends it to a destination that could not be resolved statically.")

    # --- kit techniques and obfuscation
    kits = intel.kit_fingerprints(corpus, ctx.settings, "phishing")
    for k in kits:
        if k["kind"] == "technique_pattern":
            add("kit_technique", "kit_technique", 2.0 if "Bot API" in k["name"] or "webhook" in k["name"] else 1.0, k["name"], k["evidence"][0]["resource"] if k["evidence"] else "")
        elif k["kind"] == "operator_signature":
            add("operator_signature_match", "kit_technique", 2.5 if k["match"] == "exact" else 1.5, k["name"], k["evidence"][0]["resource"] if k["evidence"] else "")
    if analysis.obfuscation and cred:
        o = analysis.obfuscation[0]
        add("obfuscated_script_on_credential_page", "kit_technique", 1.0, f"{o['technique'].replace('_', ' ')} in {o['resource']}", o["resource"])
        uncertainty.append("Obfuscated script code on a credential page could not be fully analysed statically.")

    # --- infrastructure context
    tls = net["tls"] or {}
    if cred and tls.get("verified") is False:
        add("tls_validation_failed_on_credential_page", "infrastructure", 1.0, f"Certificate validation failed: {tls['error']}", t.url)
    if cred and tls.get("age_days") is not None and tls["age_days"] < 14:
        add("very_new_certificate", "infrastructure", 0.5, f"Certificate issued {tls['age_days']} day(s) ago (common for new legitimate sites as well)", t.url)

    # --- threat intelligence
    ext_hosts = [fl["destination_hostname"] for fl in flows if fl["destination_hostname"] and fl["origin_relation"] != "same_origin" and fl["destination_class"] not in NEUTRAL_CLASSES]
    records = intel.threat_intel(ctx, ext_hosts)
    flags = intel.intel_flags(records)
    for rec in records:
        if rec["result"] == "match":
            if rec["source"] == "phishtank":
                add("threat_intel_phishtank", "threat_intelligence", 10.0 if rec["record"].get("verified") else 5.0, rec["detail"], t.url, source="phishtank")
            elif rec["query_type"] == "url":
                add("threat_intel_urlhaus_url", "threat_intelligence", 4.0, rec["detail"], t.url, source="urlhaus")
            elif rec["queried"] == t.hostname:
                add("threat_intel_urlhaus_host", "threat_intelligence", 2.0, rec["detail"], t.hostname, source="urlhaus")
            else:
                add("threat_intel_urlhaus_destination_host", "threat_intelligence", 2.0, f"Referenced destination {rec['queried']}: {rec['detail']}", t.url, source="urlhaus")
    r.performed("Queried public threat-intelligence sources where configured and permitted (see threat_intelligence in the report).")

    # --- uncertainty from unretrieved scripts
    unknown_ext = [e for e in corpus.external_scripts if intel.classify_host(e["host"])[0] not in intel.BENIGN_SCRIPT_CLASSES]
    if unknown_ext and cred:
        uncertainty.append(f"{len(unknown_ext)} third-party script(s) on a credential page could not be retrieved (outside scope); they might read or forward form data.")
    if corpus.errors:
        r.limit("Some resources could not be collected: " + "; ".join(corpus.errors[:3]))

    # --- verdict
    per_cat = {}
    for i in indicators:
        per_cat[i["category"]] = per_cat.get(i["category"], 0.0) + i["weight"]
    capped = {c: min(v, CAPS.get(c, 3.0)) for c, v in per_cat.items() if v > 0}
    score = round(sum(capped.values()), 2)
    cats = set(capped)
    imp = capped.get("impersonation", 0.0)
    if flags["phish_verified"]:
        verdict = "phishing_confirmed"
    elif score >= 11 and len(cats) >= 4 and cred and imp >= 2 and capped.get("exfiltration", 0) >= 3:
        verdict = "phishing_confirmed"
    elif score >= 7 and len(cats) >= 3 and (cred or imp >= 2):
        verdict = "phishing_probable"
    elif score >= 3 and len(cats) >= 2:
        verdict = "phishing_suspected"
    elif score >= 1.5 or (score > 0 and uncertainty):
        verdict = "inconclusive"
    else:
        verdict = "no_phishing_indicators_detected"
    confirmed_by = "threat_intelligence" if flags["phish_verified"] else ("corroborating_evidence" if verdict == "phishing_confirmed" else None)
    confidence = {"phishing_confirmed": "high" if flags["phish_verified"] else "medium", "phishing_probable": "medium"}.get(verdict, "low")

    # --- impersonated brand record
    brand_rec = None
    if primary and (len(primary["text"]) >= 1 or primary["look"]):
        name, _, domains, _ = primary["brand"]
        strong = len(primary["text"]) >= 2 and bool(primary["look"])
        brand_rec = {
            "brand": name, "official_reference_domains": domains, "confidence": "high" if strong and len(primary["text"]) >= 3 else "medium" if strong or len(primary["text"]) >= 2 else "low",
            "textual_evidence": list(primary["text"].values()), "domain_similarity": [{"technique": x["technique"], "detail": x["detail"]} for x in primary["look"]],
            "brand_asset_hosts": primary["hot"][:5], "operator_note": f"{name} is the brand being imitated, not the operator of {t.hostname}.",
            "alternative_explanations": [
                "A fan, reseller, partner, review or news site that legitimately references the brand.",
                f"An official {name} domain that is missing from the bundled reference list.",
                "A legitimate federated sign-in button or integration that names the brand."],
        }

    # --- findings
    if verdict != "no_phishing_indicators_detected":
        why = [i["detail"] for i in sorted(indicators, key=lambda x: -x["weight"]) if i["weight"] > 0][:5]
        r.add(mk(f"Phishing assessment: {VERDICT_LABEL[verdict].lower()}", "phishing", _SEV[verdict], confidence, _STATUS[verdict], t.url,
                 f"Evidence-weighted assessment of this site gave '{verdict}' (score {score}, {len(cats)} independent indicator categories)."
                 + (" Confirmation rests on a threat-intelligence listing." if confirmed_by == "threat_intelligence" else ""),
                 "Visitors may be tricked into disclosing credentials or personal data." if verdict != "inconclusive" else "",
                 evidence=why or ["Indicators were weak or incomplete."] + uncertainty[:2],
                 remediation=_recommendations(verdict)[:3], references=REF, method="static_page_analysis", verified=verdict == "phishing_confirmed"))
    if brand_rec and (brand_rec["confidence"] != "low" or verdict != "no_phishing_indicators_detected"):
        r.add(mk(f"Possible impersonation of {brand_rec['brand']}", "phishing", "medium" if brand_rec["confidence"] != "low" else "low", brand_rec["confidence"],
                 "probable" if brand_rec["confidence"] == "high" else "potential", t.url,
                 f"The page references {brand_rec['brand']} but the host {t.hostname} is not one of its known official domains. This is an observation of imitation, not proof of who operates the site.",
                 evidence=brand_rec["textual_evidence"] + [x["detail"] for x in brand_rec["domain_similarity"]], remediation=["Verify the site through the brand's official channel before entering any data."],
                 references=REF, method="static_page_analysis"))
    done = set()
    for i in indicators:
        if i["category"] == "exfiltration" and i.get("destination") and i["destination"] not in done:
            done.add(i["destination"])
            r.add(mk(f"Credential-type form data directed to {i['destination']}", "phishing", "high" if i["weight"] >= 5 else "medium", "medium" if i["weight"] >= 3 else "low", "potential",
                     t.url, f"{i['detail']}. Derived from page source; no request was sent or observed, and the destination's operator is not established.",
                     "If this is not an intended integration, credentials may be delivered to an unrelated party.",
                     evidence=[i["detail"]], remediation=["Confirm the destination is an intended, contractually covered processor.", "Block the destination if it is not."],
                     references=REF, method="static_page_analysis"))
    for rec in records:
        if rec["result"] == "match":
            r.add(mk(f"Threat-intelligence listing ({rec['source']}, {rec['query_type']})", "phishing", "critical" if rec["source"] == "phishtank" else "high", "high" if rec["record"].get("verified") or rec["source"] == "urlhaus" else "medium",
                     "confirmed" if rec["source"] == "phishtank" and rec["record"].get("verified") else "probable", rec["queried"], rec["detail"],
                     "The target appears in a public threat feed.", evidence=[f"{rec['source']} at {rec['observed_at']}: {rec['detail']}"],
                     remediation=_recommendations(verdict)[:2], references=REF, method="threat_intelligence_lookup", verified=True))

    # --- destinations
    refs = {}
    for fl in flows:
        if fl["destination_url"]:
            refs.setdefault(fl["destination_url"], []).append(fl["source"][:60])
    for e in corpus.external_scripts:
        refs.setdefault(e["url"], []).append(f"script tag on {e['page']}")
    destinations, seen_host = [], set()
    for url, by in refs.items():
        host = urlsplit(url).hostname
        if host in seen_host:
            continue
        seen_host.add(host)
        destinations.append(intel.destination_record(ctx, url, by, records))
    for d in destinations:
        for e in corpus.external_scripts:
            if e["host"] == d["hostname"]:
                d["observation"] = "referenced_in_source (script not retrieved)"
    categories = sorted({c for fl in flows for c in fl["data_category"].split(", ") if c} | {c for f in cred_forms for c in f["categories"]})

    tests_not = [
        "Runtime browser observation: no page was rendered, so no request, permission prompt or DOM change was observed.",
        "Request payload inspection: no data was submitted to any destination (no credentials are ever submitted).",
        "Domain registration age and registrant (WHOIS/RDAP) lookup.",
        "Visual (screenshot) similarity comparison with the real brand's pages.",
        "TLS and HTTP inspection of external destinations (outside the authorized scope; only DNS was resolved).",
        "Analysis of out-of-scope third-party scripts (listed, not retrieved).",
    ]
    limits = [
        "Static, non-executing analysis: dynamically built destinations and obfuscated code can hide data flows.",
        "Every data flow is 'referenced in source' or 'statically inferred'; none was observed in a running browser.",
        "The brand list is a small bundled reference, not a complete registry of organizations or domains.",
        "Registrable domains are derived without a public-suffix list; unusual suffixes may be mis-split.",
        "A missing threat-intelligence match is not evidence that the site is legitimate.",
        *intel.intel_limitations(records),
    ]
    if unknown_ext:
        limits.append(f"{len(unknown_ext)} third-party script(s) were referenced but not retrieved.")
    for x in tests_not:
        r.not_performed(x)
    for x in limits:
        r.limit(x)

    dev = intel.developer_attribution(corpus, analysis)
    r.data.update({
        "verdict": verdict, "verdict_label": VERDICT_LABEL[verdict], "confidence": confidence, "risk_level": _RISK[verdict],
        "confirmed_by": confirmed_by, "threat_category": "phishing / credential harvesting" if verdict != "no_phishing_indicators_detected" else None,
        "score": score, "indicator_categories": sorted(cats), "credential_collection_present": cred,
        "impersonated_brand": brand_rec, "developer_attribution": dev, "kit_fingerprints": kits, "data_flows": flows,
        "potential_data_categories": categories, "destinations": destinations,
        "network_observations": net, "threat_intelligence": records,
        "evidence": [{k: v for k, v in i.items()} for i in sorted(indicators, key=lambda x: -x["weight"])],
        "tests_performed": list(r.tests_performed), "tests_not_performed": tests_not, "limitations": limits,
        "recommendations": _recommendations(verdict), "uncertainty": uncertainty[:8],
        "observation_types": {"source_reference": "destination appears literally in HTML/JS", "statically_inferred": "a data dependency was inferred from code; nothing was sent or observed",
                              "unresolved_dynamic": "the destination is built at runtime and was not resolved", "dynamically_observed": "not used: no runtime observation is performed"},
    })
    return r


def _recommendations(verdict):
    base = ["Do not enter credentials or payment details on this site until its operator is verified through an independent channel."]
    if verdict in ("phishing_confirmed", "phishing_probable", "phishing_suspected"):
        return base + [
            "If you own this site and did not deploy this behavior, take it offline, review the web server for compromise and rotate every credential it could reach.",
            "Report the site to the impersonated organization, the hosting provider and the registrar, and to public phishing-report services.",
            "Check whether the destination hosts receiving form data are intended processors; block them if not.",
            "Any user who already entered credentials should change them and enable multi-factor authentication.",
        ]
    if verdict == "inconclusive":
        return base[:0] + ["Review the unresolved items (third-party scripts, dynamic destinations) manually or in an isolated browser.",
                           "Repeat the check with threat-intelligence keys configured (URLHAUS_AUTH_KEY, PHISHTANK_APP_KEY)."]
    return ["No phishing indicators were found by the tests that ran; this is not proof the site is legitimate."]
