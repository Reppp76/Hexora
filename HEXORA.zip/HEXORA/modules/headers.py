from urllib.parse import urlsplit

from core.models import ModuleResult
from modules._common import cookie_findings, mk, path_of

KEY = "headers"
TITLE = "Security Headers & HTTP Configuration"
DESCRIPTION = "CSP, HSTS, framing, referrer policy, cookies and HTTPS redirect behavior."

REF = ["https://owasp.org/www-project-secure-headers/"]


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    home = ctx.home()
    if not home.reached:
        r.status = "failed"
        r.error = home.blocked or home.error or "target unreachable"
        r.not_performed("All header checks: the target did not respond.")
        return r
    h, res = home.headers, path_of(home.url)
    https = home.url.startswith("https://")
    r.performed(f"Inspected response headers of {res} (HTTP {home.status}).")
    note = "Missing headers are hardening gaps, not proof of an exploitable flaw; impact depends on the application."

    csp = h.get("content-security-policy", "")
    if not csp:
        r.add(mk("Content-Security-Policy header not set", "http_headers", "low", "high", "confirmed", res,
                 "No Content-Security-Policy header was returned. " + note,
                 "Without CSP, an XSS flaw elsewhere is easier to exploit.",
                 ["Header absent in response"], ["Define a restrictive CSP (start with default-src 'self')."], REF,
                 "http_response_inspection", True))
    else:
        weak = [d for d in ("'unsafe-inline'", "'unsafe-eval'") if d in csp]
        if weak:
            r.add(mk("Content-Security-Policy allows unsafe directives", "http_headers", "low", "high", "confirmed", res,
                     f"The CSP contains {', '.join(weak)}, which weakens script injection protection.",
                     "Inline or eval-based script execution is still permitted.", [f"CSP contains {', '.join(weak)}"],
                     ["Remove unsafe-inline/unsafe-eval; use nonces or hashes."], REF, "http_response_inspection", True))
    if https:
        hsts = h.get("strict-transport-security", "")
        if not hsts:
            r.add(mk("Strict-Transport-Security header not set", "http_headers", "medium", "high", "confirmed", res,
                     "The HTTPS site does not send HSTS. " + note,
                     "Browsers may be downgraded to HTTP on first or later visits by a network attacker.",
                     ["Header absent in HTTPS response"], ["Send Strict-Transport-Security with max-age of at least 15552000."],
                     REF, "http_response_inspection", True))
        else:
            age = [p for p in hsts.replace(" ", "").split(";") if p.lower().startswith("max-age=")]
            try:
                seconds = int(age[0].split("=")[1]) if age else 0
            except ValueError:
                seconds = 0
            if seconds < 15552000:
                r.add(mk("HSTS max-age is short", "http_headers", "low", "high", "confirmed", res,
                         f"HSTS max-age is {seconds} seconds (recommended: at least 15552000).", "",
                         [f"Strict-Transport-Security: {hsts}"], ["Increase max-age."], REF, "http_response_inspection", True))
    if h.get("x-content-type-options", "").lower() != "nosniff":
        r.add(mk("X-Content-Type-Options not set to nosniff", "http_headers", "low", "high", "confirmed", res,
                 "MIME sniffing protection is not enabled. " + note, "", ["Header absent or not 'nosniff'"],
                 ["Send X-Content-Type-Options: nosniff."], REF, "http_response_inspection", True))
    if not h.get("referrer-policy"):
        r.add(mk("Referrer-Policy header not set", "http_headers", "informational", "high", "confirmed", res,
                 "No Referrer-Policy was returned. Browsers apply their own default. " + note, "",
                 ["Header absent"], ["Send Referrer-Policy: strict-origin-when-cross-origin (or stricter)."], REF,
                 "http_response_inspection", True))
    if not h.get("x-frame-options") and "frame-ancestors" not in csp:
        r.add(mk("No clickjacking protection", "http_headers", "low", "high", "confirmed", res,
                 "Neither X-Frame-Options nor a CSP frame-ancestors directive was found. " + note,
                 "The page may be embeddable in a hostile frame.", ["X-Frame-Options and frame-ancestors both absent"],
                 ["Add CSP frame-ancestors 'self' or X-Frame-Options: SAMEORIGIN."], REF, "http_response_inspection", True))

    for f in cookie_findings(home, https):
        r.add(f)
    r.performed(f"Checked {len(home.set_cookies)} Set-Cookie header(s) for Secure/HttpOnly/SameSite.")

    cc = h.get("cache-control", "").lower()
    if home.set_cookies and not any(x in cc for x in ("no-store", "private", "no-cache")):
        r.add(mk("Response that sets a cookie is cacheable", "http_headers", "low", "medium", "potential", res,
                 "A response that sets a cookie has no no-store/private/no-cache directive. Shared caches might store it.",
                 "", [f"Cache-Control: {h.get('cache-control', '(absent)')}"], ["Add Cache-Control: no-store to sensitive responses."],
                 REF, "http_response_inspection", False))
    r.performed("Checked Cache-Control on the cookie-setting response.")

    parts = urlsplit(ctx.target.url)
    default_port = 443 if https else 80
    if https and parts.port in (None, 443) and ctx.target.port == default_port:
        plain = ctx.client.get(f"http://{ctx.target.hostname}/", follow=False)
        if not plain.reached:
            r.not_performed("HTTP to HTTPS redirect check: plain HTTP port did not answer or was blocked.")
        elif plain.status in (301, 302, 307, 308) and plain.headers.get("location", "").startswith("https://"):
            r.performed("Confirmed plain HTTP redirects to HTTPS.")
        else:
            r.performed("Requested plain HTTP root without following redirects.")
            r.add(mk("Plain HTTP is not redirected to HTTPS", "http_headers", "medium", "high", "confirmed", "http://" + ctx.target.hostname + "/",
                     f"The HTTP site answered with status {plain.status} instead of redirecting to HTTPS.",
                     "Users who start on HTTP stay unencrypted.", [f"HTTP status {plain.status}, Location: {plain.headers.get('location', 'none')}"],
                     ["Redirect all HTTP traffic to HTTPS."], REF, "http_response_inspection", True))
    elif not https:
        r.add(mk("Target is served over plain HTTP", "http_headers", "medium", "high", "confirmed", "/",
                 "The target URL uses http://. Traffic is not encrypted.", "Credentials and sessions can be observed or altered in transit.",
                 [f"Scheme of target: {parts.scheme}"], ["Serve the site over HTTPS."], REF, "http_response_inspection", True))
        r.performed("Noted plain HTTP target (HSTS and redirect checks do not apply).")
    return r
