from core.models import ModuleResult
from modules._common import mk

KEY = "availability"
TITLE = "DoS Resilience & Rate-Limit Assessment"
DESCRIPTION = "Bounded low-impact checks for throttling indicators. Not a load test."

BURST = 12
REF = ["https://owasp.org/API-Security/editions/2023/en/0xa4-unrestricted-resource-consumption/"]


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    home = ctx.home()
    if not home.reached:
        r.status = "failed"
        r.error = home.blocked or home.error or "target unreachable"
        return r
    h = home.headers
    advertised = [k for k in ("ratelimit-limit", "x-ratelimit-limit", "retry-after", "x-rate-limit-limit") if k in h]
    r.performed("Looked for rate-limit response headers on the start page.")

    statuses, slow = [], []
    for _ in range(BURST):
        resp = ctx.client.get(ctx.target.url, max_bytes=50_000)
        if not resp.reached:
            break
        statuses.append(resp.status)
        slow.append(resp.elapsed)
        if resp.status in (429, 503):
            break
    r.performed(f"Sent a sequential burst of {len(statuses)} requests (client rate limit {ctx.settings.rate_limit_per_sec}/s). Deliberately small; this is not a load test.")
    r.data.update({"burst_statuses": statuses, "burst_avg_ms": round(sum(slow) / len(slow) * 1000, 1) if slow else None})

    throttled = any(s in (429, 503) for s in statuses)
    if throttled:
        r.performed("The server throttled the burst (HTTP 429/503), which indicates some rate control exists.")
    elif advertised:
        r.performed(f"Rate-limit headers advertised: {', '.join(advertised)}.")
    elif len(statuses) == BURST:
        r.add(mk("No rate-limiting indicators observed", "availability", "low", "low", "inconclusive", "/",
                 f"{BURST} quick requests produced no 429 response and no rate-limit headers. The burst was far below real abuse volumes, "
                 "and limits may exist at a CDN, per-account or on other routes. This does not show the site is vulnerable to DDoS.",
                 "Missing throttling can make brute force and scraping easier.", [f"Statuses: {sorted(set(statuses))}"],
                 ["Apply rate limits on authentication and expensive endpoints."], REF, "bounded_burst", False))

    enc = h.get("content-encoding", "")
    if not enc and home.content_type.startswith("text/") and len(home.body) > 10_000:
        r.add(mk("Large text response is not compressed", "availability", "informational", "medium", "confirmed", "/",
                 "A response over 10 KB was sent without content encoding.", "Raises bandwidth use per request.",
                 [f"{len(home.body)} bytes, no Content-Encoding"], ["Enable gzip or brotli."], REF, "http_response_inspection", True))
    r.not_performed("Request-size limit probing, slow-request (Slowloris-style) tests and any sustained load.")
    r.not_performed("Server configuration review (needs supplied config files).")
    r.limit("A lightweight remote check cannot establish whether the site can withstand a real DDoS. Load testing needs a staging environment, a traffic budget and stop conditions.")
    return r
