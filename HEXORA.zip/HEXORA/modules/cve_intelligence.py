import hashlib
import json
import time
from pathlib import Path

import requests

from core.models import ModuleResult
from modules._common import mk
from modules.fingerprint import detect

KEY = "cve_intelligence"
TITLE = "CVE & Known Vulnerability Intelligence"
DESCRIPTION = "Correlate detected technology versions with public NVD records."

NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
CACHE_TTL = 24 * 3600

# technology name -> (vendor, product) pairs used to build CPE match strings
CPE_MAP = {
    "Apache HTTP Server": [("apache", "http_server")],
    "nginx": [("f5", "nginx"), ("nginx", "nginx")],
    "PHP": [("php", "php")],
    "Microsoft IIS": [("microsoft", "internet_information_services")],
    "WordPress": [("wordpress", "wordpress")],
    "Drupal": [("drupal", "drupal")],
    "Joomla": [("joomla", "joomla")],
    "Jetty (Java)": [("eclipse", "jetty")],
    "Next.js": [("vercel", "next.js")],
    "jQuery": [("jquery", "jquery")],
}
_SEV = {"CRITICAL": "critical", "HIGH": "high", "MEDIUM": "medium", "LOW": "low"}


def fetch_nvd(settings, cpe, timeout=20):
    """Query NVD for CVEs matching a CPE string. Returns parsed JSON; raises on failure."""
    cache = Path(settings.cache_dir)
    cache.mkdir(parents=True, exist_ok=True)
    path = cache / (hashlib.sha256(cpe.encode()).hexdigest()[:24] + ".json")
    if path.exists() and time.time() - path.stat().st_mtime < CACHE_TTL:
        return json.loads(path.read_text())
    headers = {"User-Agent": settings.user_agent}
    if settings.nvd_api_key:
        headers["apiKey"] = settings.nvd_api_key
    r = requests.get(NVD_URL, params={"virtualMatchString": cpe, "resultsPerPage": 40}, headers=headers, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    path.write_text(json.dumps(data))
    return data


def _score(cve):
    best = (0.0, "")
    for k in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV40", "cvssMetricV2"):
        for m in cve.get("metrics", {}).get(k, []):
            d = m.get("cvssData", {})
            s = d.get("baseScore", 0) or 0
            if s > best[0]:
                best = (s, (d.get("baseSeverity") or m.get("baseSeverity") or "").upper())
    return best


def parse(data):
    out = []
    for item in data.get("vulnerabilities", []):
        c = item.get("cve", {})
        if not c.get("id"):
            continue
        score, sev = _score(c)
        desc = next((d["value"] for d in c.get("descriptions", []) if d.get("lang") == "en"), "")
        out.append({"id": c["id"], "score": score, "severity": sev, "published": c.get("published", ""), "summary": desc[:200]})
    out.sort(key=lambda x: -x["score"])
    return out


def collect_targets(ctx):
    techs = [t for t in detect(ctx) if t["version"]]
    return techs


def run(ctx, extra_techs=None):
    r = ModuleResult(KEY, TITLE)
    if not ctx.settings.nvd_enabled:
        r.status = "skipped"
        r.not_performed("CVE correlation disabled (HEXORA_NVD_ENABLED=false).")
        return r
    if not ctx.home().reached:
        r.status = "failed"
        r.error = ctx.home().blocked or ctx.home().error or "target unreachable"
        return r
    techs = collect_targets(ctx) + list(extra_techs or [])
    if not techs:
        r.performed("Looked for technologies with a disclosed version to correlate.")
        r.limit("No technology exposed a version string, so there was nothing to match against NVD. "
                "This is not evidence that the site has no known vulnerabilities.")
        return r
    failed_techs = 0
    for t in techs:
        pairs = CPE_MAP.get(t["technology"])
        if not pairs:
            r.not_performed(f"No CPE mapping for {t['technology']} {t['version']}; not correlated.")
            continue
        cves, ok_lookups = {}, 0
        for vendor, product in pairs:
            cpe = f"cpe:2.3:a:{vendor}:{product}:{t['version']}"
            try:
                data = fetch_nvd(ctx.settings, cpe)
            except Exception as exc:  # network, rate limit, bad JSON
                r.limit(f"NVD lookup failed for {t['technology']} {t['version']}: {type(exc).__name__}.")
                continue
            ok_lookups += 1
            r.performed(f"Queried NVD for {t['technology']} {t['version']} ({vendor}:{product}).")
            for c in parse(data):
                cves[c["id"]] = c
        if ok_lookups == 0:
            failed_techs += 1
        if not cves:
            continue
        ranked = sorted(cves.values(), key=lambda x: -x["score"])
        top = ranked[0]
        sev = _SEV.get(top["severity"], "medium")
        # a banner version is a claim; cap severity because exploitability is not established
        sev = {"critical": "high"}.get(sev, sev)
        r.add(mk(
            f"Public CVEs match {t['technology']} {t['version']}", "known_vulnerabilities", sev,
            "low" if t["confidence"] != "high" else "medium", "potential", "/",
            f"NVD lists {len(ranked)} CVE record(s) whose affected configurations include {t['technology']} {t['version']}. "
            "This is a version-based match from a server banner. Distributions often backport fixes without changing the version, "
            "and a match is not proof the issue is exploitable here.",
            "If the version is accurate and unpatched, known weaknesses may apply.",
            [f"{c['id']} (CVSS {c['score']}, {c['severity'] or 'n/a'})" for c in ranked[:10]] + [f"Version source: {', '.join(t['evidence'])}"],
            ["Confirm the real installed version and patch level.", "Upgrade or apply vendor security updates."],
            [f"https://nvd.nist.gov/vuln/detail/{c['id']}" for c in ranked[:5]],
            "nvd_version_correlation", False,
        ))
    if failed_techs:
        r.status = "partial"
    r.limit("Matches are version-based correlations against NVD, not exploit verification.")
    return r
