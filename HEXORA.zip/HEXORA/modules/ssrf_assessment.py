import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from core.models import ModuleResult
from modules._common import mk, path_of

KEY = "ssrf_assessment"
TITLE = "SSRF & Request-Boundary Risk Assessment"
DESCRIPTION = "Find URL-fetching input surfaces; verify only with an operator-supplied callback."

URLISH = re.compile(r"^(url|uri|link|src|source|dest|destination|redirect|redirect_uri|return|next|callback|webhook|feed|image|img|fetch|proxy|target|domain|host|site|path)$", re.I)
REF = ["https://owasp.org/Top10/A10_2021-Server-Side_Request_Forgery_%28SSRF%29/"]


def surfaces(ctx):
    crawl = ctx.crawl()
    found = {}
    for url in crawl.discovered | set(crawl.pages):
        p = urlsplit(url)
        for k, v in parse_qsl(p.query, keep_blank_values=True):
            if URLISH.match(k):
                found.setdefault((p.path, k), url)
    for page in crawl.pages.values():
        for f in page.forms:
            if f["method"] != "get":
                continue
            for i in f["inputs"]:
                if URLISH.match(i["name"]) and i["type"] in ("text", "url", "input", "hidden"):
                    p = urlsplit(f["action"])
                    found.setdefault((p.path, i["name"]), urlunsplit((p.scheme, p.netloc, p.path, urlencode([(i["name"], "")]), "")))
    return found


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    if not ctx.home().reached:
        r.status = "failed"
        r.error = ctx.home().blocked or ctx.home().error or "target unreachable"
        return r
    found = surfaces(ctx)
    r.data["input_surfaces"] = [f"{p}?{k}" for (p, k) in found]
    r.performed(f"Looked for URL-like parameters in {len(ctx.crawl().pages)} crawled page(s) and forms; found {len(found)}.")
    callback = ctx.settings.ssrf_callback_url
    for (path, name), url in sorted(found.items()):
        res = f"{path}?{name}="
        if callback:
            p = urlsplit(url)
            q = [(k, callback if k == name else v) for k, v in parse_qsl(p.query, keep_blank_values=True)] or [(name, callback)]
            test = urlunsplit((p.scheme, p.netloc, p.path, urlencode(q), ""))
            resp = ctx.client.get(test)
            r.performed(f"Sent the operator-supplied callback URL in '{name}' (HTTP {resp.status or 'no response'}).")
            r.add(mk(f"URL-accepting parameter '{name}' tested with callback", "ssrf", "medium", "low", "potential", res,
                     "A callback URL controlled by the operator was submitted. HEXORA cannot see incoming callback traffic; "
                     "check your callback listener for a request from the target's server. Without that, this stays potential.",
                     "If the server fetched the URL, SSRF is possible.", [f"HTTP {resp.status} from target"],
                     ["Allow-list destinations; block private and metadata ranges at the network layer."], REF,
                     "operator_callback", False))
        else:
            r.add(mk(f"Parameter '{name}' looks like a URL input", "ssrf", "low", "low", "potential", res,
                     "The parameter name suggests the server may fetch or redirect to a user-supplied URL. "
                     "No request was sent with a custom destination, so SSRF is unverified.",
                     "If the server fetches arbitrary URLs it could be steered to internal services.",
                     [f"Parameter name: {name}"], ["Validate and allow-list URLs server-side.", "Block metadata and private ranges at the network layer."],
                     REF, "name_heuristic", False))
    if not callback:
        r.not_performed("Active SSRF verification: set HEXORA_SSRF_CALLBACK_URL to an endpoint you control to enable it.")
    r.not_performed("Probing internal hosts, private ranges or cloud metadata services (never done by HEXORA).")
    r.limit("Only GET parameters found by the bounded crawl were considered. A confirmed SSRF requires seeing the server-side request.")
    return r
