import secrets
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from core.models import ModuleResult
from modules._common import mk, path_of, sql_error

KEY = "injection"
TITLE = "Injection Security Assessment"
DESCRIPTION = "Reflected XSS, SQL error, template injection and command-injection indicators (non-destructive)."

MAX_PARAMS = 12
CMD_NAMES = {"cmd", "command", "exec", "execute", "shell", "ping", "run", "system"}
REF_XSS = ["https://owasp.org/www-community/attacks/xss/"]
REF_SQL = ["https://owasp.org/www-community/attacks/SQL_Injection"]
REF_SSTI = ["https://portswigger.net/web-security/server-side-template-injection"]


def _with_param(url, name, value):
    p = urlsplit(url)
    q = [(k, value if k == name else v) for k, v in parse_qsl(p.query, keep_blank_values=True)]
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(q), ""))


def candidates(ctx):
    crawl = ctx.crawl()
    found = {}
    for url in crawl.discovered:
        p = urlsplit(url)
        for k, _ in parse_qsl(p.query, keep_blank_values=True):
            found.setdefault((p.path, k), url)
    for page in crawl.pages.values():
        for form in page.forms:
            if form["method"] != "get":
                continue
            names = [i["name"] for i in form["inputs"] if i["type"] not in ("password", "submit", "hidden", "checkbox", "radio", "file")]
            base = urlsplit(form["action"])
            for n in names:
                url = urlunsplit((base.scheme, base.netloc, base.path, urlencode([(i, "test") for i in names]), ""))
                found.setdefault((base.path, n), url)
    return list(found.items())[:MAX_PARAMS]


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    if not ctx.home().reached:
        r.status = "failed"
        r.error = ctx.home().blocked or ctx.home().error or "target unreachable"
        r.not_performed("Injection tests: the target did not respond.")
        return r
    params = candidates(ctx)
    r.data["parameters_tested"] = [f"{p} ? {n}" for (p, n), _ in params]
    if not params:
        r.limit("No GET parameters or GET form fields were discovered within the crawl limits, so nothing was tested. "
                "This does not mean the application is free of injection flaws.")
        r.not_performed("Parameter-based injection tests (no parameters found).")
        return r
    tag = secrets.token_hex(3)
    xss_marker = f"hx{tag}\"'<>"
    ssti_probe, ssti_hit = f"hx{tag}{{{{7*7}}}}hx", f"hx{tag}49hx"
    for (path, name), url in params:
        res = f"{path}?{name}="
        base = ctx.client.get(url)
        if not base.reached:
            r.limit(f"{res}: baseline request failed ({base.blocked or base.error}).")
            continue
        r.performed(f"Baseline request for parameter '{name}' on {path}.")

        resp = ctx.client.get(_with_param(url, name, xss_marker))
        if resp.reached and "html" in resp.content_type and xss_marker in resp.text and xss_marker not in base.text:
            r.add(mk("Reflected input is not HTML-encoded (possible XSS)", "injection", "medium", "high", "probable", res,
                     f"The parameter '{name}' is reflected into an HTML response with angle brackets and quotes intact. "
                     "Script execution was not attempted, so exploitation is not confirmed.",
                     "If reachable by a victim, attacker-supplied script could run in the site's origin.",
                     [f"Marker containing <> and quotes returned verbatim in {resp.content_type} body"],
                     ["Encode output for its HTML context.", "Add a restrictive Content-Security-Policy."], REF_XSS,
                     "benign_marker_reflection", False))
        r.performed(f"XSS reflection marker sent to '{name}'.")

        orig = dict(parse_qsl(urlsplit(url).query, keep_blank_values=True)).get(name, "")
        resp = ctx.client.get(_with_param(url, name, orig + "'"))
        if resp.reached:
            err = sql_error(resp.text)
            if err and not sql_error(base.text):
                r.add(mk("Database error message triggered by a single quote (possible SQL injection)", "injection", "high", "medium", "probable", res,
                         f"Appending one quote to '{name}' produced a database error signature that the baseline did not show. "
                         "No data was extracted and no injection payload was run.",
                         "Unsafe query construction can lead to data disclosure or modification.",
                         [f"Error signature: {err}", f"Baseline HTTP {base.status}, test HTTP {resp.status}"],
                         ["Use parameterised queries.", "Disable detailed database errors in responses."], REF_SQL,
                         "error_based_comparison", False))
        r.performed(f"Single-quote SQL error comparison sent to '{name}'.")

        resp = ctx.client.get(_with_param(url, name, ssti_probe))
        if resp.reached and ssti_hit in resp.text and ssti_probe not in resp.text:
            r.add(mk("Template expression was evaluated (possible SSTI)", "injection", "high", "medium", "probable", res,
                     f"A harmless arithmetic expression sent in '{name}' came back evaluated.",
                     "Server-side template injection frequently leads to code execution.",
                     ["Expression {{7*7}} returned as 49 inside a unique marker"],
                     ["Never render user input as a template.", "Use a sandboxed template engine."], REF_SSTI,
                     "arithmetic_expression", False))
        r.performed(f"Arithmetic template-expression probe sent to '{name}'.")
        if name.lower() in CMD_NAMES:
            r.add(mk(f"Parameter '{name}' has a command-like name", "injection", "informational", "low", "potential", res,
                     "The parameter name suggests it may reach an operating-system command. No command payloads were sent.",
                     "", [f"Parameter name: {name}"], ["Review how this value is used server-side."], [], "name_heuristic", False))

    r.not_performed("Active OS command injection testing (no commands are executed against targets).")
    r.not_performed("POST form and JSON body injection testing (avoids changing server state).")
    r.not_performed("Blind and time-based injection techniques; stored XSS.")
    r.limit("Only GET parameters found by the bounded crawl were tested; a clean result means 'no issue detected by these tests'.")
    return r
