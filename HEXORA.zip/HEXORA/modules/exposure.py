import re

from core.models import ModuleResult
from core.redact import mask_secret
from core.scheduler import run_parallel
from modules._common import mk, path_of, stack_trace

KEY = "exposure"
TITLE = "File Exposure & Information Disclosure"
DESCRIPTION = "Config files, VCS metadata, source maps, directory listings and secrets in client assets."

REF = ["https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/02-Configuration_and_Deployment_Management_Testing/"]

# (path, label, severity, content check). Content checks avoid flagging soft-404 pages.
PROBES = [
    ("/.env", "Environment file", "high", re.compile(r"^\s*[A-Z][A-Z0-9_]{2,}\s*=", re.M)),
    ("/.git/HEAD", "Git repository metadata", "high", re.compile(r"^ref:\s*refs/", re.M)),
    ("/.git/config", "Git configuration", "high", re.compile(r"\[core\]", re.I)),
    ("/.svn/entries", "Subversion metadata", "medium", re.compile(r"\S")),
    ("/.DS_Store", "macOS directory metadata", "low", re.compile(r"Bud1")),
    ("/config.json", "Configuration file", "medium", re.compile(r"\{")),
    ("/wp-config.php.bak", "WordPress config backup", "high", re.compile(r"DB_PASSWORD|DB_NAME")),
    ("/phpinfo.php", "phpinfo() page", "medium", re.compile(r"PHP Version", re.I)),
    ("/server-status", "Apache server-status", "medium", re.compile(r"Apache Server Status", re.I)),
    ("/actuator/env", "Spring Boot actuator", "high", re.compile(r"propertySources|activeProfiles")),
    ("/actuator/health", "Spring Boot actuator", "low", re.compile(r'"status"')),
    ("/debug", "Debug endpoint", "medium", re.compile(r"debug|traceback", re.I)),
    ("/composer.json", "Composer manifest", "low", re.compile(r'"require"')),
    ("/package.json", "Node package manifest", "low", re.compile(r'"(dependencies|name)"')),
    ("/.well-known/security.txt", "security.txt", "informational", re.compile(r"Contact:", re.I)),
]
ARCHIVES = ["/backup.zip", "/backup.tar.gz", "/db.sql", "/site.zip", "/www.zip"]

SECRET_PATTERNS = [
    ("AWS access key ID", re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "high"),
    ("Private key block", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"), "critical"),
    ("Slack token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}"), "high"),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}\b"), "high"),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"), "low"),
    ("JSON Web Token", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b"), "medium"),
    ("Hard-coded credential assignment", re.compile(r"""(?i)\b(?:api[_-]?key|secret|passwd|password|client_secret)\b\s*[:=]\s*["']([A-Za-z0-9/+_\-]{16,})["']"""), "medium"),
]


def _probe(ctx, item):
    path = item[0]
    return path, ctx.client.get(ctx.url(path), follow=False, max_bytes=200_000)


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    if not ctx.home().reached:
        r.status = "failed"
        r.error = ctx.home().blocked or ctx.home().error or "target unreachable"
        return r
    results = run_parallel(lambda it: _probe(ctx, it), PROBES, ctx.settings.max_concurrency)
    home_body = ctx.home().body
    for item, res in zip(PROBES, results):
        if isinstance(res, Exception):
            r.limit(f"Probe of {item[0]} failed: {type(res).__name__}")
            continue
        path, resp = res
        _, label, sev, check = item
        if resp.status != 200 or resp.body == home_body or not check.search(resp.text[:50_000]):
            continue
        if sev == "informational":
            r.add(mk(f"{label} present", "information_disclosure", "informational", "high", "confirmed", path,
                     f"{path} is available. This is good practice.", "", [f"HTTP 200"], [], [], "http_response_inspection", True))
            continue
        r.add(mk(f"{label} publicly accessible", "information_disclosure", sev, "high", "confirmed", path,
                 f"{path} returned content that matches the signature for: {label.lower()}. Contents were not stored in this report.",
                 "Exposed configuration and metadata can reveal credentials, structure and source code.",
                 [f"HTTP 200, {len(resp.body)} bytes, content signature matched"],
                 [f"Remove {path} from the web root or deny access to it."], REF, "http_response_inspection", True))
    r.performed(f"Requested {len(PROBES)} well-known sensitive paths and validated content signatures to avoid soft-404 false positives.")

    for p in ARCHIVES:
        resp = ctx.client.request("HEAD", ctx.url(p), follow=False)
        ctype = resp.headers.get("content-type", "")
        if resp.status == 200 and not ctype.startswith("text/html"):
            r.add(mk(f"Possible backup archive at {p}", "information_disclosure", "high", "medium", "probable", p,
                     "A HEAD request succeeded with a non-HTML content type. The file was not downloaded.",
                     "Backups often contain source code and credentials.", [f"HEAD HTTP 200, content-type {ctype or 'unknown'}"],
                     ["Remove backup files from the web root."], REF, "head_request", False))
    r.performed(f"Sent HEAD requests for {len(ARCHIVES)} common archive names (nothing downloaded).")

    crawl = ctx.crawl()
    map_checked = 0
    for url, text in crawl.js_files.items():
        for label, rx, sev in SECRET_PATTERNS:
            for m in list(rx.finditer(text))[:3]:
                shown = m.group(1) if m.lastindex else m.group(0)
                r.add(mk(f"{label} found in client-side script", "information_disclosure", sev, "medium", "potential",
                         path_of(url),
                         f"A string matching the {label} pattern appears in a publicly served script. The value is masked here. "
                         "Some keys (for example browser-restricted API keys) are meant to be public.",
                         "A real secret in client code is exposed to every visitor.", [f"Pattern: {label}; value: {mask_secret(shown)}"],
                         ["Rotate the credential if it is real.", "Keep secrets on the server."], REF, "pattern_match", False))
        if re.search(r"//[#@]\s*sourceMappingURL=(\S+)", text):
            mp = re.search(r"//[#@]\s*sourceMappingURL=(\S+)", text).group(1)
            if not mp.startswith("data:"):
                map_url = re.sub(r"/[^/]*$", "/", url) + mp
                resp = ctx.client.get(map_url, max_bytes=100_000)
                map_checked += 1
                if resp.ok and '"sources"' in resp.text[:100_000]:
                    r.add(mk("JavaScript source map is publicly accessible", "information_disclosure", "low", "high", "confirmed",
                             path_of(map_url),
                             "The script references a source map that is downloadable and lists original source files.",
                             "Source maps expose unminified client source and file structure.", ["Source map returned valid map JSON"],
                             ["Do not deploy source maps to production, or restrict access."], REF, "http_response_inspection", True))
    r.performed(f"Scanned {len(crawl.js_files)} client-side script(s) for secret patterns and source maps ({map_checked} map(s) fetched).")

    for page in list(crawl.pages.values())[:15]:
        if page.status >= 400:
            resp = ctx.client.get(page.url, max_bytes=100_000)
            tr = stack_trace(resp.text) if resp.reached else None
            if tr:
                r.add(mk("Error page discloses implementation details", "information_disclosure", "medium", "medium", "confirmed", path_of(page.url),
                         "An error response contains stack trace or framework markers.", "Internal paths and versions help attackers.",
                         [f"Marker: {tr}"], ["Disable debug output and return generic error pages."], REF, "http_response_inspection", True))
    for url in sorted(crawl.discovered)[:60]:
        if url.endswith("/") and url != ctx.url("/"):
            resp = ctx.client.get(url, max_bytes=50_000)
            if resp.ok and re.search(r"<title>\s*Index of /", resp.text, re.I):
                r.add(mk("Directory listing enabled", "information_disclosure", "medium", "high", "confirmed", path_of(url),
                         "The directory returns an auto-generated file index.", "Reveals files that were never meant to be linked.",
                         ["Response title begins with 'Index of /'"], ["Disable directory indexing."], REF, "http_response_inspection", True))
    r.limit("Only unauthenticated requests to a fixed list of paths were made; absence of a finding does not prove nothing is exposed.")
    return r
