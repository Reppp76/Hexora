import re

from core.models import ModuleResult
from modules._common import mk, stack_trace

KEY = "server_config"
TITLE = "Server Misconfiguration Assessment"
DESCRIPTION = "HTTP methods, debug output, default pages and HTTPS consistency."

REF = ["https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/02-Configuration_and_Deployment_Management_Testing/"]
RISKY_METHODS = ("PUT", "DELETE", "TRACE", "CONNECT", "PATCH")
DEFAULT_PAGES = [
    (re.compile(r"Apache2 (Ubuntu|Debian) Default Page|It works!", re.I), "Apache default page"),
    (re.compile(r"Welcome to nginx!", re.I), "nginx default page"),
    (re.compile(r"IIS Windows Server|Internet Information Services", re.I), "IIS default page"),
    (re.compile(r"Apache Tomcat/\d", re.I), "Tomcat default page"),
]


def run(ctx):
    r = ModuleResult(KEY, TITLE)
    home = ctx.home()
    if not home.reached:
        r.status = "failed"
        r.error = home.blocked or home.error or "target unreachable"
        return r

    opt = ctx.client.request("OPTIONS", ctx.target.url, follow=False)
    allow = opt.headers.get("allow", "") if opt.reached else ""
    methods = [m.strip().upper() for m in allow.split(",") if m.strip()]
    r.performed("Sent an OPTIONS request to read advertised HTTP methods.")
    risky = [m for m in methods if m in RISKY_METHODS]
    if risky:
        r.add(mk("Server advertises risky HTTP methods", "server_configuration", "low", "medium", "potential", "/",
                 f"The Allow header lists {', '.join(risky)}. Advertising a method does not prove it works without authorization.",
                 "Write-capable methods on a public route can allow unwanted changes if not protected.",
                 [f"Allow: {allow}"], ["Disable methods the application does not need."], REF, "options_request", False))
    if not methods:
        r.limit("The server did not advertise methods via OPTIONS, so supported methods were not enumerated.")

    trace = ctx.client.request("TRACE", ctx.target.url, follow=False, headers={"X-Hexora-Probe": "trace-check"})
    r.performed("Sent a TRACE request (reads only; no body).")
    if trace.status == 200 and "x-hexora-probe" in trace.text.lower():
        r.add(mk("HTTP TRACE is enabled", "server_configuration", "low", "high", "confirmed", "/",
                 "The server reflected a custom request header back in a TRACE response.",
                 "TRACE can aid cross-site tracing attacks and exposes request details.",
                 ["Custom header echoed in TRACE response body"], ["Disable TRACE."], REF, "trace_request", True))

    bad = ctx.client.get(ctx.url("/hexora-nonexistent-" + "7f3a9c"), follow=False, max_bytes=100_000)
    r.performed("Requested a random non-existent path to inspect the error page.")
    if bad.reached:
        tr = stack_trace(bad.text)
        if tr:
            r.add(mk("Debug or stack trace output on error page", "server_configuration", "medium", "medium", "confirmed", "/hexora-nonexistent-*",
                     "A request for a missing page returned stack trace or framework debug markers.",
                     "Debug output reveals file paths, versions and code.", [f"Marker: {tr}"],
                     ["Turn off debug mode in production."], REF, "http_response_inspection", True))
        if bad.status == 200 and bad.body == home.body:
            r.limit("Unknown paths return the home page with HTTP 200 (catch-all routing). Some path-based checks may be unreliable.")

    for rx, label in DEFAULT_PAGES:
        if rx.search(home.text[:20_000]):
            r.add(mk(f"{label} is being served", "server_configuration", "low", "medium", "potential", "/",
                     "The start page looks like a default installation page.", "Suggests an unfinished or unhardened deployment.",
                     [label], ["Replace default content and review the server configuration."], REF, "content_signature", False))

    if ctx.target.scheme == "https" and ctx.target.port == 443:
        plain = ctx.client.get(f"http://{ctx.target.hostname}/", follow=False, max_bytes=50_000)
        if plain.ok:
            r.add(mk("Site is served over both HTTP and HTTPS without redirecting", "server_configuration", "medium", "high", "confirmed", "http:///",
                     "Plain HTTP returned content with status 200 instead of redirecting to HTTPS.", "Inconsistent HTTPS enforcement.",
                     [f"http://{ctx.target.hostname}/ -> HTTP {plain.status}"], ["Redirect HTTP to HTTPS and enable HSTS."], REF,
                     "http_response_inspection", True))
        r.performed("Compared plain HTTP and HTTPS behavior.")

    r.not_performed("Filesystem permission, service version hardening and OS-level checks (not observable remotely).")
    r.limit("Remote observation shows only what the server answers. Findings describe responses, not the full server configuration.")
    return r
