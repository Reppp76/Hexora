from core.models import ModuleInfo


def _load():
    from modules import (attack_surface, api_security, authentication, authorization, availability,
                         cve_intelligence, dependencies, exposure, fingerprint, headers, injection,
                         phishing, server_config, spyware, ssrf_assessment, tls)
    mods = [injection, fingerprint, cve_intelligence, headers, tls, api_security, authentication,
            authorization, exposure, server_config, dependencies, ssrf_assessment, availability, attack_surface]
    # 02-15 keep their numbers; 16 is Get Source Code (not a security module); 17-18 are the intel checks
    mods = list(zip(range(2, 16), mods)) + [(17, phishing), (18, spyware)]
    return [ModuleInfo(option=n, key=m.KEY, title=m.TITLE, description=m.DESCRIPTION, run=m.run) for n, m in mods]


_CACHE = []


def security_modules():
    """Options 02-15 and 17-18 in menu order."""
    if not _CACHE:
        _CACHE.extend(_load())
    return list(_CACHE)


def by_option(option):
    for m in security_modules():
        if m.option == option:
            return m
    return None
