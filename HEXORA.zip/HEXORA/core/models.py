from dataclasses import dataclass, field, asdict
from typing import Callable

SEVERITIES = ("critical", "high", "medium", "low", "informational")
STATUSES = ("confirmed", "probable", "potential", "informational", "inconclusive")
CONFIDENCES = ("high", "medium", "low")


@dataclass
class Finding:
    title: str
    category: str
    severity: str
    confidence: str
    status: str
    affected_resource: str
    description: str
    impact: str = ""
    evidence: list = field(default_factory=list)
    remediation: list = field(default_factory=list)
    references: list = field(default_factory=list)
    verification: dict = field(default_factory=lambda: {"method": "passive_observation", "verified": False})
    module: str = ""
    id: str = ""

    def __post_init__(self):
        if self.severity not in SEVERITIES:
            raise ValueError(f"bad severity: {self.severity}")
        if self.status not in STATUSES:
            raise ValueError(f"bad status: {self.status}")
        if self.confidence not in CONFIDENCES:
            raise ValueError(f"bad confidence: {self.confidence}")

    def key(self):
        return (self.category, self.title, self.affected_resource)

    def to_dict(self):
        return asdict(self)


@dataclass
class ModuleResult:
    key: str
    title: str
    status: str = "completed"  # completed | partial | failed | skipped
    findings: list = field(default_factory=list)
    limitations: list = field(default_factory=list)
    tests_performed: list = field(default_factory=list)
    tests_not_performed: list = field(default_factory=list)
    data: dict = field(default_factory=dict)
    error: str = ""
    duration: float = 0.0

    def add(self, finding):
        finding.module = self.key
        self.findings.append(finding)
        return finding

    def performed(self, text):
        self.tests_performed.append(text)

    def not_performed(self, text):
        self.tests_not_performed.append(text)

    def limit(self, text):
        self.limitations.append(text)


@dataclass
class ModuleInfo:
    option: int
    key: str
    title: str
    description: str
    run: Callable
