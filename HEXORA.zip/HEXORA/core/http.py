import threading
import time
from dataclasses import dataclass, field
from urllib.parse import urljoin

import requests
from requests.structures import CaseInsensitiveDict

from core.exceptions import BudgetExceeded, ScopeError
from core.redact import redact_text

REDIRECTS = (301, 302, 303, 307, 308)
MAX_HOPS = 5


@dataclass
class Resp:
    url: str
    status: int = 0
    headers: CaseInsensitiveDict = field(default_factory=CaseInsensitiveDict)
    body: bytes = b""
    truncated: bool = False
    elapsed: float = 0.0
    chain: list = field(default_factory=list)
    set_cookies: list = field(default_factory=list)
    error: str = ""
    blocked: str = ""

    @property
    def ok(self):
        return 200 <= self.status < 300

    @property
    def reached(self):
        return self.status > 0

    @property
    def content_type(self):
        return self.headers.get("content-type", "").split(";")[0].strip().lower()

    @property
    def text(self):
        enc = "utf-8"
        ct = self.headers.get("content-type", "")
        if "charset=" in ct:
            enc = ct.split("charset=")[-1].split(";")[0].strip() or "utf-8"
        try:
            return self.body.decode(enc, errors="replace")
        except LookupError:
            return self.body.decode("utf-8", errors="replace")


class SafeClient:
    """requests wrapper that enforces scope on every hop, a request budget and a rate limit."""

    def __init__(self, settings, scope, session=None):
        self.settings = settings
        self.scope = scope
        self.session = session or requests.Session()
        self.session.trust_env = settings.trust_env
        self.session.headers["User-Agent"] = settings.user_agent
        self._lock = threading.Lock()
        self._last = 0.0
        self.requests_made = 0

    def _tick(self):
        with self._lock:
            if self.requests_made >= self.settings.max_requests:
                raise BudgetExceeded(f"request budget of {self.settings.max_requests} reached")
            self.requests_made += 1
            gap = 1.0 / self.settings.rate_limit_per_sec if self.settings.rate_limit_per_sec > 0 else 0
            wait = self._last + gap - time.monotonic()
            if wait > 0:
                time.sleep(wait)
            self._last = time.monotonic()

    def get(self, url, **kw):
        return self.request("GET", url, **kw)

    def request(self, method, url, headers=None, data=None, follow=True, max_bytes=None, timeout=None):
        max_bytes = max_bytes or self.settings.max_response_bytes
        timeout = timeout or self.settings.request_timeout
        chain = []
        method = method.upper()
        hops = 0
        while True:
            try:
                self.scope.check_url(url)
            except ScopeError as exc:
                return Resp(url=url, chain=chain, blocked=str(exc), error=f"blocked: {exc}")
            self._tick()
            started = time.monotonic()
            try:
                r = self.session.request(
                    method, url, headers=headers, data=data, allow_redirects=False,
                    stream=True, timeout=(min(timeout, 10), timeout), verify=self.settings.verify_tls,
                )
            except requests.exceptions.SSLError as exc:
                return Resp(url=url, chain=chain, error=redact_text(f"tls error: {exc}"))
            except requests.exceptions.RequestException as exc:
                return Resp(url=url, chain=chain, error=redact_text(f"{type(exc).__name__}: {exc}"))
            body, truncated = b"", False
            try:
                for piece in r.iter_content(8192):
                    body += piece
                    if len(body) > max_bytes:
                        body, truncated = body[:max_bytes], True
                        break
            except requests.exceptions.RequestException:
                truncated = True
            finally:
                r.close()
            try:
                cookies = list(r.raw.headers.getlist("Set-Cookie"))
            except Exception:
                cookies = [v for k, v in r.headers.items() if k.lower() == "set-cookie"]
            resp = Resp(
                url=url, status=r.status_code, headers=CaseInsensitiveDict(r.headers), body=body,
                truncated=truncated, elapsed=time.monotonic() - started, chain=list(chain), set_cookies=cookies,
            )
            chain.append((url, r.status_code))
            if follow and r.status_code in REDIRECTS and r.headers.get("Location"):
                nxt = urljoin(url, r.headers["Location"])
                hops += 1
                if hops > MAX_HOPS:
                    resp.error = "too many redirects"
                    resp.chain = chain
                    return resp
                try:
                    self.scope.check_url(nxt)
                except ScopeError as exc:
                    resp.blocked = f"redirect to {nxt} refused: {exc}"
                    resp.chain = chain
                    return resp
                if r.status_code == 303 or (r.status_code in (301, 302) and method == "POST"):
                    method, data = "GET", None
                url = nxt
                continue
            resp.chain = chain
            return resp
