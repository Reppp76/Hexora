import ipaddress
import re
import socket
from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit

from core.exceptions import ScopeError

METADATA_HOSTS = {
    "metadata.google.internal",
    "metadata",
    "instance-data",
    "instance-data.ec2.internal",
}
METADATA_IPS = {
    ipaddress.ip_address("169.254.169.254"),
    ipaddress.ip_address("169.254.170.2"),
    ipaddress.ip_address("100.100.100.200"),
    ipaddress.ip_address("fd00:ec2::254"),
}
_SHARED = ipaddress.ip_network("100.64.0.0/10")
_HOST_RE = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$")


@dataclass(frozen=True)
class Target:
    url: str
    hostname: str
    scheme: str
    port: int

    @property
    def origin(self):
        default = 443 if self.scheme == "https" else 80
        host = f"[{self.hostname}]" if ":" in self.hostname else self.hostname
        return f"{self.scheme}://{host}" + ("" if self.port == default else f":{self.port}")


def ip_problem(ip):
    """Return a reason string when the address is not an acceptable destination."""
    if isinstance(ip, str):
        ip = ipaddress.ip_address(ip)
    if getattr(ip, "ipv4_mapped", None):
        ip = ip.ipv4_mapped
    if ip in METADATA_IPS:
        return "cloud metadata endpoint"
    if ip.is_loopback:
        return "loopback address"
    if ip.is_link_local:
        return "link-local address"
    if ip.is_private:
        return "private network address"
    if ip.version == 4 and ip in _SHARED:
        return "shared (CGNAT) address space"
    if ip.is_multicast or ip.is_reserved or ip.is_unspecified:
        return "reserved or non-routable address"
    return None


def parse_target(raw):
    """Normalise user input into a Target. Raises ScopeError with a readable reason."""
    raw = (raw or "").strip().strip("\"'«»")
    if not raw:
        raise ScopeError("No URL was entered.")
    if "://" not in raw:
        raise ScopeError("The URL must start with http:// or https://.")
    try:
        parts = urlsplit(raw)
        port = parts.port
    except ValueError:
        raise ScopeError("The URL is malformed.")
    if parts.scheme.lower() not in ("http", "https"):
        raise ScopeError(f"Unsupported scheme '{parts.scheme}'. Only http and https are allowed.")
    if parts.username or parts.password:
        raise ScopeError("URLs containing credentials are not accepted.")
    host = (parts.hostname or "").strip(".").lower()
    if not host:
        raise ScopeError("The URL has no hostname.")
    try:
        ipaddress.ip_address(host)
        is_ip = True
    except ValueError:
        is_ip = False
    if not is_ip:
        try:
            host = host.encode("idna").decode("ascii")
        except UnicodeError:
            raise ScopeError("The hostname is not valid.")
        if not _HOST_RE.match(host):
            raise ScopeError("The hostname contains invalid characters.")
    if host in METADATA_HOSTS or host == "localhost" or host.endswith((".localhost", ".internal", ".local")):
        pass  # reported by check_destination so allow_private can decide
    scheme = parts.scheme.lower()
    port = port or (443 if scheme == "https" else 80)
    path = parts.path or "/"
    default = 443 if scheme == "https" else 80
    netloc = (f"[{host}]" if ":" in host else host) + ("" if port == default else f":{port}")
    return Target(urlunsplit((scheme, netloc, path, parts.query, "")), host, scheme, port)


def resolve(host):
    try:
        infos = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise ScopeError(f"Hostname '{host}' could not be resolved ({exc.strerror or exc}).")
    return sorted({ipaddress.ip_address(i[4][0].split("%")[0]) for i in infos}, key=str)


def check_destination(host, allow_private=False):
    """Resolve host and verify every address. Used for the target and again on each request."""
    if host in METADATA_HOSTS:
        raise ScopeError(f"'{host}' is a cloud metadata endpoint and is never allowed.")
    try:
        ips = [ipaddress.ip_address(host)]
    except ValueError:
        ips = resolve(host)
    for ip in ips:
        reason = ip_problem(ip)
        if reason == "cloud metadata endpoint":
            raise ScopeError(f"{host} resolves to a cloud metadata endpoint, which is never allowed.")
        if reason and not allow_private:
            raise ScopeError(
                f"{host} resolves to {ip} ({reason}). Private and local targets are blocked "
                "unless HEXORA_ALLOW_PRIVATE_TARGETS=true is set for a lab you own."
            )
    return ips


class Scope:
    def __init__(self, target, extra_hosts=(), allow_subdomains=False, allow_private=False):
        self.base = target.hostname
        self.allow_subdomains = allow_subdomains
        self.allow_private = allow_private
        hosts = {self.base, *[h.lower() for h in extra_hosts]}
        # example.com and www.example.com are treated as the same site
        if self.base.startswith("www."):
            hosts.add(self.base[4:])
        elif self.base.count(".") == 1:
            hosts.add("www." + self.base)
        self.hosts = hosts

    def host_in_scope(self, host):
        host = (host or "").lower().rstrip(".")
        if host in self.hosts:
            return True
        return self.allow_subdomains and any(host.endswith("." + h) for h in self.hosts)

    def check_url(self, url):
        """Raise ScopeError unless the URL may be requested."""
        parts = urlsplit(url)
        if parts.scheme not in ("http", "https"):
            raise ScopeError(f"scheme '{parts.scheme}' is not allowed")
        if parts.username or parts.password:
            raise ScopeError("URL contains credentials")
        host = (parts.hostname or "").lower()
        if not self.host_in_scope(host):
            raise ScopeError(f"host '{host}' is outside the authorized scope")
        check_destination(host, self.allow_private)
        return True


def site_name(hostname):
    """Filename-safe website name derived from the hostname."""
    name = re.sub(r"[^A-Za-z0-9._-]", "_", hostname or "site")
    name = re.sub(r"\.{2,}", ".", name).strip("._") or "site"
    return name[:80]
