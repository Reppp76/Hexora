import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone

from core.exceptions import BudgetExceeded, CollectionError
from core.models import ModuleResult
from core.redact import redact_text
from modules import by_option, security_modules
from modules import source_collector
from integrations.telegram import Delivery
from reporting.json_report import build_report, new_scan_id, report_filename, write_report

log = logging.getLogger("hexora.engine")


@dataclass
class Outcome:
    option: int
    mode: str
    report: dict = None
    source_manifest: dict = None
    files: list = field(default_factory=list)
    deliveries: list = field(default_factory=list)
    error: str = ""
    cancelled: bool = False


def _now():
    return datetime.now(timezone.utc)


class Engine:
    def __init__(self, ctx, telegram, progress=None):
        self.ctx = ctx
        self.telegram = telegram
        self.progress = progress or (lambda *a, **k: None)

    def run_module(self, info):
        """Run one module. A crash becomes a failed result instead of aborting the scan."""
        started = time.monotonic()
        try:
            result = info.run(self.ctx)
        except BudgetExceeded as exc:
            result = ModuleResult(info.key, info.title, status="partial")
            result.limit(f"Stopped early: {exc}")
        except KeyboardInterrupt:
            raise
        except Exception as exc:  # noqa: BLE001 - one broken module must not end the audit
            log.exception("module %s crashed", info.key)
            result = ModuleResult(info.key, info.title, status="failed", error=redact_text(f"{type(exc).__name__}: {exc}"))
            result.not_performed(f"{info.title}: the module crashed before finishing.")
        result.duration = time.monotonic() - started
        return result

    def run_option(self, option):
        if option == 1:
            return self._full_audit()
        if option == 16:
            return self._source_only()
        info = by_option(option)
        if info is None:
            return Outcome(option, "invalid", error=f"Option {option} does not exist.")
        return self._single(info)

    def _single(self, info):
        out = Outcome(info.option, info.key)
        started, scan_id = _now(), new_scan_id()
        self.progress(1, 1, info, None)
        result = self.run_module(info)
        self.progress(1, 1, info, result)
        report = build_report(self.ctx, info.key, [result], started, _now(), scan_id)
        path = write_report(self.ctx.settings, report_filename(self.ctx, info.key, info.key), report)
        out.report, out.files = report, [path]
        out.deliveries = [self.telegram.send_document(path, f"HEXORA {info.title} - {self.ctx.target.hostname}")]
        return out

    def _source_only(self):
        out = Outcome(16, "source")
        self.progress(1, 1, source_collector, None)
        try:
            path, manifest = source_collector.collect(self.ctx)
        except CollectionError as exc:
            out.error = redact_text(str(exc))
            return out
        except KeyboardInterrupt:
            out.cancelled, out.error = True, "Cancelled."
            return out
        out.source_manifest, out.files = manifest, [path]
        out.deliveries = [self.telegram.send_document(path, f"HEXORA source export - {self.ctx.target.hostname}")]
        return out

    def _full_audit(self):
        out = Outcome(1, "full_audit")
        started, scan_id = _now(), new_scan_id()
        infos = security_modules()
        results, cancelled = [], False
        try:
            for i, info in enumerate(infos, 1):
                self.progress(i, len(infos), info, None)
                res = self.run_module(info)
                results.append(res)
                self.progress(i, len(infos), info, res)
        except KeyboardInterrupt:
            cancelled = True

        html_path, export = None, {"status": "not_run"}
        if not cancelled:
            try:
                html_path, manifest = source_collector.collect(self.ctx)
                out.source_manifest = manifest
                export = {"status": "completed", "file": html_path.name, "embedded": len(manifest["embedded"]),
                          "not_embedded": len(manifest["not_embedded"]), "external_dependencies": len(manifest["external_dependencies"])}
            except CollectionError as exc:
                export = {"status": "failed", "error": redact_text(str(exc))}
            except KeyboardInterrupt:
                cancelled = True

        report = build_report(self.ctx, "full_audit", results, started, _now(), scan_id, export, cancelled)
        json_path = write_report(self.ctx.settings, report_filename(self.ctx, "full_audit"), report)
        out.report, out.files, out.cancelled = report, [json_path], cancelled
        if cancelled:
            out.error = "Scan cancelled. A partial report was saved locally and nothing was sent to Telegram."
            return out
        if html_path:
            out.files.append(html_path)

        json_delivery = self.telegram.send_document(json_path, f"HEXORA full audit report - {self.ctx.target.hostname}")
        out.deliveries.append(json_delivery)
        if html_path:
            if json_delivery.delivered:
                out.deliveries.append(self.telegram.send_document(html_path, f"HEXORA source export - {self.ctx.target.hostname}"))
            elif json_delivery.status in ("disabled", "not_configured"):
                out.deliveries.append(Delivery(html_path.name, json_delivery.status, json_delivery.detail))
            else:
                out.deliveries.append(Delivery(html_path.name, "skipped", "not sent because the JSON upload did not succeed; file kept locally"))
        else:
            out.deliveries.append(Delivery(f"{self.ctx.target.hostname}.html", "skipped", "no HTML export was generated: " + export.get("error", "unknown reason")))
        return out
