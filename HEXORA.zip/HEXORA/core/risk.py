from core.models import SEVERITIES

_ORDER = {s: i for i, s in enumerate(SEVERITIES)}
_CONF = {"high": 0, "medium": 1, "low": 2}


def dedupe(findings):
    """Collapse equivalent findings. The strongest copy wins; evidence from duplicates is merged."""
    kept = {}
    for f in findings:
        k = f.key()
        if k not in kept:
            kept[k] = f
            continue
        cur = kept[k]
        for ev in f.evidence:
            if ev not in cur.evidence:
                cur.evidence.append(ev)
        if (_ORDER[f.severity], _CONF[f.confidence]) < (_ORDER[cur.severity], _CONF[cur.confidence]):
            f.evidence = cur.evidence
            f.module = f.module or cur.module
            kept[k] = f
    return sorted(kept.values(), key=lambda f: (_ORDER[f.severity], f.category, f.title))


def summarize(findings):
    out = {s: 0 for s in SEVERITIES}
    out.update({"confirmed": 0, "probable": 0, "potential": 0, "inconclusive": 0})
    for f in findings:
        out[f.severity] += 1
        if f.status in ("confirmed", "probable", "potential", "inconclusive"):
            out[f.status] += 1
    return out


def scan_status(results, findings):
    """completed | completed_with_findings | partial | failed"""
    if not results:
        return "failed"
    failed = [r for r in results if r.status == "failed"]
    if len(failed) == len(results):
        return "failed"
    if failed or any(r.status == "partial" for r in results):
        return "partial"
    if any(f.severity != "informational" for f in findings):
        return "completed_with_findings"
    return "completed"
