from concurrent.futures import ThreadPoolExecutor


def run_parallel(fn, items, workers):
    """Map fn over items with a bounded pool. Results keep input order; exceptions are returned, not raised."""
    items = list(items)
    if not items:
        return []
    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(items)))) as pool:
        futures = [pool.submit(fn, item) for item in items]
        out = []
        for f in futures:
            try:
                out.append(f.result())
            except Exception as exc:  # noqa: BLE001 - callers decide what a failed probe means
                out.append(exc)
        return out
