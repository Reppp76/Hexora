import re

_PATTERNS = [
    (re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{30,}\b"), "[REDACTED_TELEGRAM_TOKEN]"),
    (re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]{8,}"), r"\1[REDACTED]"),
    (re.compile(r"(?i)((?:set-)?cookie\s*:\s*[^=;\s]+=)[^;\r\n]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(authorization\s*:\s*)\S+(\s+\S+)?"), r"\1[REDACTED]"),
    (re.compile(r"/bot\d+:[A-Za-z0-9_-]+/"), "/bot[REDACTED]/"),
]


def redact_text(text):
    if not isinstance(text, str):
        return text
    for pattern, repl in _PATTERNS:
        text = pattern.sub(repl, text)
    return text


def mask_secret(value):
    """Describe a secret without reproducing it."""
    value = str(value)
    if len(value) <= 6:
        return "*" * len(value)
    return f"{value[:3]}***({len(value)} chars)"


def sanitize(obj, extra_secrets=()):
    """Walk a JSON-like structure and scrub known secret shapes."""
    secrets = [s for s in extra_secrets if s]
    if isinstance(obj, str):
        out = redact_text(obj)
        for s in secrets:
            out = out.replace(s, "[REDACTED]")
        return out
    if isinstance(obj, dict):
        return {k: sanitize(v, secrets) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [sanitize(v, secrets) for v in obj]
    return obj
