class HexoraError(Exception):
    pass


class ScopeError(HexoraError):
    """Target or destination is invalid, out of scope, or prohibited."""


class BudgetExceeded(HexoraError):
    """The per-scan request budget was used up."""


class CollectionError(HexoraError):
    """The source collector could not produce an export."""


class DeliveryError(HexoraError):
    pass
