from core.crawler import crawl
from core.http import SafeClient
from core.scope import Scope


class ScanContext:
    """Shared state for one scan: client, scope and cached responses reused across modules."""

    def __init__(self, settings, target, session=None):
        self.settings = settings
        self.target = target
        self.scope = Scope(target, settings.extra_hosts, settings.allow_subdomains, settings.allow_private)
        self.client = SafeClient(settings, self.scope, session=session)
        self._home = None
        self._crawl = None

    def home(self):
        if self._home is None:
            self._home = self.client.get(self.target.url)
        return self._home

    def crawl(self):
        if self._crawl is None:
            self._crawl = crawl(self)
        return self._crawl

    def url(self, path):
        return self.target.origin + (path if path.startswith("/") else "/" + path)
