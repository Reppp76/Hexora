import re
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit, urlunsplit
from urllib.robotparser import RobotFileParser

from bs4 import BeautifulSoup
from defusedxml import ElementTree as SafeET

from core.exceptions import BudgetExceeded

SKIP_EXT = (
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".webp", ".css", ".js", ".woff", ".woff2", ".ttf",
    ".eot", ".pdf", ".zip", ".gz", ".mp4", ".mp3", ".webm", ".map", ".xml", ".json", ".txt",
)
_ENDPOINT_RE = re.compile(r"""["'`](/(?:api|rest|graphql|v\d+|_next/data|wp-json|ajax)[A-Za-z0-9_\-./{}:?=&%]*)["'`]""")


@dataclass
class Page:
    url: str
    status: int
    content_type: str
    headers: dict
    title: str = ""
    links: list = field(default_factory=list)
    forms: list = field(default_factory=list)
    scripts: list = field(default_factory=list)
    styles: list = field(default_factory=list)
    images: list = field(default_factory=list)
    depth: int = 0


@dataclass
class CrawlResult:
    pages: dict = field(default_factory=dict)
    discovered: set = field(default_factory=set)
    external: set = field(default_factory=set)
    js_files: dict = field(default_factory=dict)
    js_endpoints: set = field(default_factory=set)
    robots_found: bool = False
    robots_disallow: list = field(default_factory=list)
    sitemaps: list = field(default_factory=list)
    sitemap_urls: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    truncated: bool = False


def normalize(url):
    p = urlsplit(url)
    return urlunsplit((p.scheme, p.netloc, p.path or "/", p.query, ""))


def parse_page(url, resp, depth=0):
    soup = BeautifulSoup(resp.text, "html.parser")
    base = soup.find("base", href=True)
    base_url = urljoin(url, base["href"]) if base else url
    page = Page(url=url, status=resp.status, content_type=resp.content_type, headers=dict(resp.headers), depth=depth)
    page.title = (soup.title.string or "").strip() if soup.title and soup.title.string else ""

    def absolute(value):
        if not value or value.startswith(("javascript:", "mailto:", "tel:", "data:", "#")):
            return None
        return normalize(urljoin(base_url, value.strip()))

    for a in soup.find_all("a", href=True):
        u = absolute(a["href"])
        if u:
            page.links.append(u)
    for tag in soup.find_all("script", src=True):
        u = absolute(tag["src"])
        if u:
            page.scripts.append(u)
    for tag in soup.find_all("link", href=True):
        rel = " ".join(tag.get("rel", []))
        u = absolute(tag["href"])
        if u and "stylesheet" in rel:
            page.styles.append(u)
    for tag in soup.find_all("img", src=True):
        u = absolute(tag["src"])
        if u:
            page.images.append(u)
    for form in soup.find_all("form"):
        inputs = []
        for el in form.find_all(["input", "textarea", "select"]):
            name = el.get("name")
            if name:
                inputs.append({"name": name, "type": (el.get("type") or el.name).lower()})
        action = absolute(form.get("action") or "") or normalize(url)
        page.forms.append({
            "action": action,
            "method": (form.get("method") or "get").lower(),
            "inputs": inputs,
            "has_password": any(i["type"] == "password" for i in inputs),
        })
    return page


def _fetch_robots(ctx, result):
    resp = ctx.client.get(ctx.target.origin + "/robots.txt", max_bytes=200_000)
    if not resp.ok or "html" in resp.content_type:
        return None
    result.robots_found = True
    lines = resp.text.splitlines()
    for line in lines:
        key, _, value = line.partition(":")
        key, value = key.strip().lower(), value.strip()
        if key == "disallow" and value:
            result.robots_disallow.append(value)
        elif key == "sitemap" and value:
            result.sitemaps.append(value)
    rp = RobotFileParser()
    rp.parse(lines)
    return rp


def _fetch_sitemaps(ctx, result):
    candidates = list(dict.fromkeys(result.sitemaps + [ctx.target.origin + "/sitemap.xml"]))[:5]
    for sm in candidates:
        resp = ctx.client.get(sm, max_bytes=1_000_000)
        if not resp.ok:
            continue
        try:
            root = SafeET.fromstring(resp.body)
        except Exception as exc:  # defusedxml raises on entity tricks; plain parse errors too
            result.errors.append(f"sitemap {sm}: unparsable ({type(exc).__name__})")
            continue
        for el in root.iter():
            if el.tag.endswith("loc") and el.text:
                loc = el.text.strip()
                try:
                    if ctx.scope.host_in_scope(urlsplit(loc).hostname):
                        result.sitemap_urls.append(normalize(loc))
                except ValueError:
                    continue
        result.sitemap_urls = list(dict.fromkeys(result.sitemap_urls))[:200]


def crawl(ctx):
    s = ctx.settings
    result = CrawlResult()
    try:
        robots = _fetch_robots(ctx, result)
        _fetch_sitemaps(ctx, result)
        start = normalize(ctx.target.url)
        queue = [(start, 0)]
        seen = {start}
        while queue and len(result.pages) < s.crawl_max_pages:
            url, depth = queue.pop(0)
            if depth > 0 and robots and not robots.can_fetch("*", url):
                continue
            resp = ctx.client.get(url)
            if not resp.reached:
                result.errors.append(f"{url}: {resp.blocked or resp.error}")
                continue
            if "html" not in resp.content_type:
                continue
            page = parse_page(resp.url if resp.status < 300 else url, resp, depth)
            page.status = resp.status
            result.pages[url] = page
            for u in page.links + [f["action"] for f in page.forms]:
                host = urlsplit(u).hostname
                if not ctx.scope.host_in_scope(host):
                    result.external.add(u)
                    continue
                result.discovered.add(u)
                if depth < s.crawl_depth and u not in seen and not urlsplit(u).path.lower().endswith(SKIP_EXT):
                    seen.add(u)
                    queue.append((u, depth + 1))
            for u in page.scripts + page.styles + page.images:
                if ctx.scope.host_in_scope(urlsplit(u).hostname):
                    result.discovered.add(u)
                else:
                    result.external.add(u)
        if queue:
            result.truncated = True
        for url in sorted({u for p in result.pages.values() for u in p.scripts})[:10]:
            if not ctx.scope.host_in_scope(urlsplit(url).hostname):
                continue
            resp = ctx.client.get(url, max_bytes=1_000_000)
            if resp.ok:
                result.js_files[url] = resp.text
                for m in _ENDPOINT_RE.findall(resp.text):
                    result.js_endpoints.add(m.split("?")[0])
    except BudgetExceeded as exc:
        result.errors.append(str(exc))
        result.truncated = True
    return result
