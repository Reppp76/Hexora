import json
from html import escape


def _json_for_script(data):
    # keep the JSON from ever closing the script element or opening a comment
    return json.dumps(data, indent=2, ensure_ascii=True).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")


def wrap_page(soup, extra_pages, manifest):
    """Serialise the processed main page and append the manifest and any extra pages."""
    header = (
        "<!--\n  Exported by HEXORA (client-side collection only)\n"
        f"  Source: {escape(manifest['source'], quote=False).replace('--', '- -')}\n"
        f"  Collected: {manifest['collected_at']}\n"
        f"  Embedded: {len(manifest['embedded'])}   Not embedded: {len(manifest['not_embedded'])}   External: {len(manifest['external_dependencies'])}\n"
        "  See the hexora-manifest block at the end of this file for details.\n-->\n"
    )
    tail = soup.new_tag("div")
    tail["hidden"] = ""
    tail["id"] = "hexora-export"
    manifest_tag = soup.new_tag("script", type="application/json", id="hexora-manifest")
    manifest_tag.string = _json_for_script(manifest)
    tail.append(manifest_tag)
    for url, page_html in extra_pages:
        tpl = soup.new_tag("template")
        tpl["data-hexora-page"] = url
        tpl.append(soup.new_string(page_html))  # stored as escaped text, so it stays inert
        tail.append(tpl)
    (soup.body or soup).append(tail)
    return header + str(soup)
