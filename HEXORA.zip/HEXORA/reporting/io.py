import os
import tempfile
from pathlib import Path

from core.scope import site_name


def safe_filename(*parts, ext):
    """Join parts into a filename that cannot contain path separators or traversal."""
    name = "_".join(site_name(p) for p in parts if p)
    return f"{name}.{ext}"


def write_atomic(directory, filename, data):
    """Write bytes or str next to the final path, then rename. Result stays inside `directory`."""
    directory = Path(directory).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    final = (directory / filename).resolve()
    if final.parent != directory:
        raise ValueError("refusing to write outside the output directory")
    payload = data.encode("utf-8") if isinstance(data, str) else data
    fd, tmp = tempfile.mkstemp(dir=directory, prefix=".hexora-", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(payload)
        os.chmod(tmp, 0o600)
        os.replace(tmp, final)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return final
