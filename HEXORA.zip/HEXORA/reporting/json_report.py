import json
import uuid
from datetime import datetime, timezone

from core.redact import sanitize
from core.risk import dedupe, scan_status, summarize
from reporting.io import safe_filename, write_atomic
from core.scope import site_name

REPORT_VERSION = "1.0"


def new_scan_id():
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]


def build_report(ctx, mode, results, started, completed, scan_id, source_export=None, cancelled=False):
    findings = dedupe([f for r in results for f in r.findings])
    for i, f in enumerate(findings, 1):
        f.id = f"HEX-{i:04d}"
    status = "cancelled" if cancelled else scan_status(results, findings)
    limitations = []
    for r in results:
        limitations += [f"[{r.key}] {t}" for t in r.limitations]
    report = {
        "product": "HEXORA",
        "report_version": REPORT_VERSION,
        "scan_id": scan_id,
        "target": {"url": ctx.target.url, "hostname": ctx.target.hostname},
        "scan": {
            "mode": mode,
            "started_at": started.isoformat(timespec="seconds"),
            "completed_at": completed.isoformat(timespec="seconds"),
            "duration_seconds": round((completed - started).total_seconds(), 2),
            "status": status,
            "requests_made": ctx.client.requests_made,
            "modules_executed": [r.key for r in results if r.status in ("completed", "partial")],
            "modules_failed": [{"module": r.key, "error": r.error} for r in results if r.status == "failed"],
            "modules_skipped": [r.key for r in results if r.status == "skipped"],
        },
        "summary": summarize(findings),
        "modules": [
            {
                "module": r.key, "title": r.title, "status": r.status, "duration_seconds": round(r.duration, 2),
                "tests_performed": r.tests_performed, "tests_not_performed": r.tests_not_performed,
                "limitations": r.limitations, "data": r.data, "error": r.error,
            }
            for r in results
        ],
        "findings": [f.to_dict() for f in findings],
        "limitations": limitations,
        "recommendations": sorted({step for f in findings if f.severity != "informational" for step in f.remediation})[:40],
    }
    if source_export is not None:
        report["source_export"] = source_export
    secrets = [ctx.settings.telegram_token, ctx.settings.telegram_chat_id, ctx.settings.nvd_api_key,
               ctx.settings.urlhaus_auth_key, ctx.settings.phishtank_app_key]
    return sanitize(report, secrets)


def report_filename(ctx, mode, module_key=None):
    if mode == "full_audit":
        return safe_filename(site_name(ctx.target.hostname), ext="json")
    return safe_filename(site_name(ctx.target.hostname), module_key, ext="json")


def write_report(settings, filename, report):
    text = json.dumps(report, indent=2, ensure_ascii=False)
    json.loads(text)  # make sure what we wrote parses
    return write_atomic(settings.report_dir, filename, text)
