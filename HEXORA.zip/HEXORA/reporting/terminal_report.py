from ui.theme import CRIMSON, CYAN, GRAY, GREEN, SILVER, WHITE, AMBER, SEVERITY_TAG, wrap

ORDER = ("critical", "high", "medium", "low", "informational")


def _section(theme, title):
    return ["", theme.c(title.upper(), CRIMSON, bold=True), theme.rule()]


def _kv(theme, key, value):
    return f" {theme.c(key.ljust(14), GRAY)} {value}"


INTEL_KEYS = ("phishing", "spyware")


def _intel_modules(report):
    return {m["module"]: m["data"] for m in report["modules"] if m["module"] in INTEL_KEYS and m["data"].get("verdict")}


def threat_banner(theme, report):
    """Warning lines that match the evidence level; confirmed wording is only used for confirmed verdicts."""
    mods = _intel_modules(report)
    p = mods.get("phishing", {}).get("verdict")
    s = mods.get("spyware", {}).get("verdict")
    lines = []
    if p == "phishing_confirmed" and s == "spyware_confirmed":
        lines.append("[CRITICAL WARNING] PHISHING AND SPYWARE INDICATORS CONFIRMED")
    else:
        if p == "phishing_confirmed":
            lines.append("[CRITICAL WARNING] PHISHING ACTIVITY CONFIRMED")
        elif p == "phishing_probable":
            lines.append("[WARNING] PHISHING INDICATORS PROBABLE (not confirmed)")
        elif p == "phishing_suspected":
            lines.append("[WARNING] PHISHING INDICATORS SUSPECTED (not confirmed)")
        if s == "spyware_confirmed":
            lines.append("[CRITICAL WARNING] WEBSITE SPYWARE BEHAVIOR CONFIRMED")
        elif s == "spyware_probable":
            lines.append("[WARNING] SPYWARE-LIKE BEHAVIOR PROBABLE (not confirmed)")
        elif s == "spyware_suspected":
            lines.append("[WARNING] SPYWARE-LIKE BEHAVIOR SUSPECTED (not confirmed)")
    return [theme.c(x, CRIMSON if "CRITICAL" in x else AMBER, bold=True) for x in lines]


def _bullets(theme, items, limit, width, prefix=" - "):
    room = width - len(prefix)
    out = [prefix + (x if len(x) <= room else x[:room - 3] + "...") for x in items[:limit]]
    if len(items) > limit:
        out.append(f" {theme.c(f'... {len(items) - limit} more in the JSON report', GRAY)}")
    return out or [f" {theme.c('none', GRAY)}"]


def intel_sections(theme, report):
    out, width = [], theme.cols - 4

    def kv(key, value):
        return _kv(theme, key, str(value)[:theme.cols - 17])

    for key, d in _intel_modules(report).items():
        title = "Phishing check" if key == "phishing" else "Spyware check"
        net = d.get("network_observations") or {}
        out += _section(theme, f"{title} - details")
        out += [
            _kv(theme, "Verdict", theme.c(d["verdict"], CRIMSON if d["verdict"].endswith("confirmed") else GREEN if d["verdict"].startswith("no_") else AMBER, bold=True)),
            kv("Risk", f"{d['risk_level']}   confidence: {d['confidence']}"),
            kv("Category", d.get("threat_category") or "none identified"),
        ]
        brand = d.get("impersonated_brand")
        if key == "phishing":
            out.append(kv("Brand", f"{brand['brand']} ({brand['confidence']} confidence); imitated, not the operator" if brand else "none identified"))
        out.append(kv("Developer", d["developer_attribution"]["identity_statement"].replace("Developer identity: ", "")[:width - 15]))
        kits = [k["name"] for k in d.get("kit_fingerprints", []) if k["kind"] != "error"]
        out.append(kv("Kit/family", ("; ".join(kits))[:width - 15] if kits else "none matched"))
        out.append(kv("Data types", ", ".join(d["potential_data_categories"])[:width - 15] or "none identified"))
        out.append(kv("Observed", net.get("observed_at", "n/a")))
        out.append(kv("Target", f"{net.get('hostname')}  {net.get('scheme')}  port {net.get('effective_port')}" + (f" (explicit {net['explicit_port']})" if net.get("explicit_port") else "")))
        out.append(kv("Target IPs", ", ".join(net.get("resolved_ip_addresses", [])[:4]) or (net.get("dns_error") or "none")[:width - 15]))
        if net.get("tls"):
            tl = net["tls"]
            out.append(kv("TLS", ("verified, issuer " + str(tl.get("issuer"))) if tl.get("verified") else f"not verified: {tl.get('error')}"[:width - 15]))
        out += [theme.c(" Evidence", SILVER, bold=True)]
        out += _bullets(theme, [f"[{e['weight']}] {e['detail']}" for e in d["evidence"] if e["weight"] > 0], 5, width)
        out += [theme.c(" Data destinations (from source; none observed receiving data)", SILVER, bold=True)]
        dest = [f"{x['hostname']}:{x['port']} {x['protocol']} {x['destination_class']} ip={','.join((x['dns_a'] + x['dns_aaaa'])[:2]) or 'n/a'}" for x in d["destinations"]]
        out += _bullets(theme, dest, 6, width)
        out.append(kv("Recipient", "unknown (an endpoint operator is not the recipient)"))
        for label, field, n in (("Tests performed", "tests_performed", 4), ("Tests not performed", "tests_not_performed", 4), ("Limitations", "limitations", 4), ("Recommended actions", "recommendations", 4)):
            out += [theme.c(f" {label}", SILVER, bold=True)] + _bullets(theme, d[field], n, width)
    return out


def render_report(theme, report, deliveries=(), files=()):
    scan, summ = report["scan"], report["summary"]
    out = [theme.c("HEXORA :: ASSESSMENT REPORT", CRIMSON, bold=True), theme.rule()]
    out += [
        _kv(theme, "Target", report["target"]["url"]),
        _kv(theme, "Scan ID", report["scan_id"]),
        _kv(theme, "Mode", scan["mode"]),
        _kv(theme, "Started", scan["started_at"]),
        _kv(theme, "Completed", scan["completed_at"]),
        _kv(theme, "Duration", f"{scan['duration_seconds']} s   ({scan['requests_made']} requests)"),
        _kv(theme, "Status", theme.c(scan["status"], GREEN if scan["status"].startswith("completed") else AMBER, bold=True)),
    ]
    if scan["status"] == "completed":
        out.append(f" {theme.c('No findings were detected by the tests that ran. This is not proof of security; see tests not performed.', GRAY)}")

    banner = threat_banner(theme, report)
    if banner:
        out += ["", *banner]

    out += _section(theme, "Findings by severity")
    for sev in ORDER:
        out.append(f" {theme.sev(sev)} {str(summ[sev]).rjust(3)}")
    out.append(_kv(theme, "Confirmed", str(summ["confirmed"])))
    out.append(_kv(theme, "Probable", str(summ["probable"])))
    out.append(_kv(theme, "Potential", str(summ["potential"])))
    out.append(_kv(theme, "Inconclusive", str(summ["inconclusive"])))

    out += _section(theme, "Modules")
    for m in report["modules"]:
        mark = {"completed": "+", "partial": "~", "failed": "!", "skipped": "-"}[m["status"]]
        color = {"completed": GREEN, "partial": AMBER, "failed": CRIMSON, "skipped": GRAY}[m["status"]]
        line = f" {theme.c(mark, color, bold=True)} {m['module'].ljust(18)} {m['status'].ljust(10)} {m['duration_seconds']:>6.1f}s"
        out.append(line + (f"  {theme.c(m['error'][:60], CRIMSON)}" if m["error"] else ""))

    out += intel_sections(theme, report)

    findings = report["findings"]
    out += _section(theme, f"Findings ({len(findings)})")
    if not findings:
        out.append(f" {theme.c('none', GRAY)}")
    width = theme.cols - 8
    for f in findings[:40]:
        out.append(f" {theme.sev(f['severity'])} {theme.c(f['id'], CYAN)}  {theme.c(f['title'], WHITE, bold=True)}")
        out.append(f"        {theme.c(f['status'] + ' / ' + f['confidence'] + ' confidence', GRAY)}   {theme.c(f['affected_resource'][:40], SILVER)}")
        for line in wrap(f["description"], width)[:3]:
            out.append(f"        {line}")
        if f["remediation"]:
            out.append(f"        {theme.c('Fix:', CYAN)} {f['remediation'][0][:width - 5]}")
    if len(findings) > 40:
        out.append(f" {theme.c(f'... {len(findings) - 40} more in the JSON report', GRAY)}")

    failed = report["scan"]["modules_failed"]
    if failed:
        out += _section(theme, "Failed modules")
        out += [f" ! {x['module']}: {x['error']}" for x in failed]
    out += _section(theme, "Tests not performed")
    items = [(m["module"], t) for m in report["modules"] for t in m["tests_not_performed"]]
    out += [f" - [{mod}] {t[:theme.cols - 8 - len(mod)]}" for mod, t in items[:12]] or [f" {theme.c('none recorded', GRAY)}"]
    if len(items) > 12:
        out.append(f" {theme.c(f'... {len(items) - 12} more in the JSON report', GRAY)}")

    if report["recommendations"]:
        out += _section(theme, "Recommended remediation")
        out += [f" > {r[:theme.cols - 4]}" for r in report["recommendations"][:8]]

    out += _section(theme, "Telegram delivery")
    out += [f" {d.artifact.ljust(32)} {theme.c(d.status, GREEN if d.delivered else AMBER, bold=True)}  {theme.c(d.detail, GRAY)}" for d in deliveries] \
        or [f" {theme.c('nothing to send', GRAY)}"]
    out += _section(theme, "Output files")
    out += [f" {p}" for p in files] or [f" {theme.c('none', GRAY)}"]
    return "\n".join(out)


def render_source_summary(theme, manifest, deliveries=(), error=None):
    out = [theme.c("HEXORA :: SOURCE COLLECTION", CRIMSON, bold=True), theme.rule()]
    if error:
        out.append(f" {theme.c('! Collection failed:', CRIMSON, bold=True)} {error}")
    else:
        out += [
            _kv(theme, "Source", manifest["source"]),
            _kv(theme, "Embedded", f"{len(manifest['embedded'])} resource(s)"),
            _kv(theme, "Not embedded", f"{len(manifest['not_embedded'])} resource(s)"),
            _kv(theme, "External", f"{len(manifest['external_dependencies'])} reference(s) left as-is"),
            _kv(theme, "Extra pages", str(len(manifest["extra_pages"]))),
            _kv(theme, "File", manifest["file"]),
            _kv(theme, "Size", f"{manifest['size_bytes'] / 1024:.1f} KB"),
        ]
        for item in (manifest["not_embedded"] + manifest["external_dependencies"])[:8]:
            out.append(f" - {item['type']}: {item['url'][:50]}  ({item['reason'][:40]})")
        out.append(f" {theme.c('Client-side files only. Backend code is never retrieved; the copy may differ from the live site.', GRAY)}")
    out += _section(theme, "Telegram delivery")
    out += [f" {d.artifact.ljust(32)} {theme.c(d.status, GREEN if d.delivered else AMBER, bold=True)}  {theme.c(d.detail, GRAY)}" for d in deliveries] \
        or [f" {theme.c('nothing to send', GRAY)}"]
    return "\n".join(out)
