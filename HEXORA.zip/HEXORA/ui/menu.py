# -*- coding: utf-8 -*-
# CodeShield Encrypted Python — Powered by Repp76
import base64, sys, os

_cs_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in dir() else os.getcwd()
for _cs_p in (_cs_dir, os.getcwd()):
    if _cs_p not in sys.path:
        sys.path.insert(0, _cs_p)

_cs_parts = [
    "ZnJvbSBtb2R1bGVzIGltcG9ydCBzZWN1cml0eV9tb2R1bGVzCmZyb20gdWkudGhlbWUgaW1wb3J0",
    "IENSSU1TT04sIENZQU4sIEdSQVksIFNJTFZFUiwgV0hJVEUKCkZVTExfQVVESVQgPSAoMSwgIkZ1",
    "bGwgU2VjdXJpdHkgQXVkaXQiLCAiUnVuIGV2ZXJ5IHNlY3VyaXR5IG1vZHVsZSAoMDItMTUsIDE3",
    "LTE4KSIpClNPVVJDRSA9ICgxNiwgIkdldCBTb3VyY2UgQ29kZSIsICJDb2xsZWN0IHB1YmxpYyBj",
    "bGllbnQtc2lkZSBmaWxlcyBpbnRvIG9uZSBIVE1MIGZpbGUiKQoKCmRlZiBtZW51X2VudHJpZXMo",
    "KToKICAgICIiIkFsbCAxOCBvcHRpb25zIGluIGRpc3BsYXkgb3JkZXIgYXMgKG51bWJlciwgdGl0",
    "bGUsIGRlc2NyaXB0aW9uKS4iIiIKICAgIGVudHJpZXMgPSBbRlVMTF9BVURJVCwgU09VUkNFXQog",
    "ICAgZW50cmllcyArPSBbKG0ub3B0aW9uLCBtLnRpdGxlLCBtLmRlc2NyaXB0aW9uKSBmb3IgbSBp",
    "biBzZWN1cml0eV9tb2R1bGVzKCldCiAgICByZXR1cm4gc29ydGVkKGVudHJpZXMpCgoKZGVmIHJl",
    "bmRlcl9tZW51KHRoZW1lKToKICAgIGxpbmVzID0gW3RoZW1lLmMoIkhFWE9SQSA6OiBNT0RVTEUg",
    "U0VMRUNUSU9OIiwgQ1JJTVNPTiwgYm9sZD1UcnVlKSwgdGhlbWUucnVsZSgpXQogICAgZm9yIG51",
    "bSwgdGl0bGUsIGRlc2MgaW4gbWVudV9lbnRyaWVzKCk6CiAgICAgICAgbnVtYmVyID0gdGhlbWUu",
    "YyhmIntudW06MDJkfSIsIENZQU4sIGJvbGQ9VHJ1ZSkKICAgICAgICBsaW5lcy5hcHBlbmQoZiIg",
    "e251bWJlcn0gIHt0aGVtZS5jKHRpdGxlLCBXSElURSwgYm9sZD1UcnVlKX0iKQogICAgICAgIGxp",
    "bmVzLmFwcGVuZChmIiAgICAge3RoZW1lLmMoZGVzY1s6dGhlbWUuY29scyAtIDddLCBHUkFZKX0i",
    "KQogICAgbGluZXMgKz0gW3RoZW1lLnJ1bGUoKSwgdGhlbWUuYygiIHQgIGNoYW5nZSB0YXJnZXQg",
    "ICAgIHEgIHF1aXQiLCBTSUxWRVIpXQogICAgcmV0dXJuICJcbiIuam9pbihsaW5lcykK"
]
_cs_code = base64.b64decode("".join(_cs_parts)).decode("utf-8")
_cs_file = __file__ if "__file__" in dir() else "<codeshield>"
_cs_compiled = compile(_cs_code, _cs_file, "exec")

# Bersihkan helper vars supaya globals() yang exec() terima
# hampir sama dengan modul tulen — __name__/__package__/__spec__
# dikekalkan sebab ia sudah wujud betul dalam globals() ini,
# disediakan oleh Python sendiri sebelum baris ini jalan.
for _cs_name in ("base64", "_cs_dir", "_cs_p", "_cs_name"):
    globals().pop(_cs_name, None)

exec(_cs_compiled, globals())
