# -*- coding: utf-8 -*-
# CodeShield Encrypted Python — Powered by Repp76
import base64, sys, os

_cs_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in dir() else os.getcwd()
for _cs_p in (_cs_dir, os.getcwd()):
    if _cs_p not in sys.path:
        sys.path.insert(0, _cs_p)

_cs_parts = [
    "ZnJvbSB1aS50aGVtZSBpbXBvcnQgQ1JJTVNPTiwgREFSS19HUkFZLCBHUkFZLCBSRURfREVFUCwg",
    "UkVEX0RJTSwgU0lMVkVSLCBXSElURSwgd3JhcAoKREVTQ1JJUFRJT04gPSAoCiAgICAiQWR2YW5j",
    "ZWQgV2Vic2l0ZSBTZWN1cml0eSBBc3Nlc3NtZW50ICYgU291cmNlIEludGVsbGlnZW5jZS4gSWRl",
    "bnRpZnkgc2VjdXJpdHkgd2Vha25lc3NlcywgIgogICAgImZpbmdlcnByaW50IGV4cG9zZWQgdGVj",
    "aG5vbG9naWVzLCBhc3Nlc3MgcmlzaywgYW5kIGNvbGxlY3QgYWNjZXNzaWJsZSBjbGllbnQtc2lk",
    "ZSB3ZWJzaXRlIGFzc2V0cy4iCikKCkdMWVBIUyA9IHsKICAgICJIIjogWyLilojiloggIOKWiOKW",
    "iCIsICLilojiloggIOKWiOKWiCIsICLilojilojilojilojilojilogiLCAi4paI4paIICDiloji",
    "logiLCAi4paI4paIICDilojilogiXSwKICAgICJFIjogWyLilojilojilojilojilojilogiLCAi",
    "4paI4paIICAgICIsICLilojilojilojiloggICIsICLilojiloggICAgIiwgIuKWiOKWiOKWiOKW",
    "iOKWiOKWiCJdLAogICAgIlgiOiBbIuKWiOKWiCAg4paI4paIIiwgIiDilojilojilojiloggIiwg",
    "IiAg4paI4paIICAiLCAiIOKWiOKWiOKWiOKWiCAiLCAi4paI4paIICDilojilogiXSwKICAgICJP",
    "IjogWyIg4paI4paI4paI4paIICIsICLilojiloggIOKWiOKWiCIsICLilojiloggIOKWiOKWiCIs",
    "ICLilojiloggIOKWiOKWiCIsICIg4paI4paI4paI4paIICJdLAogICAgIlIiOiBbIuKWiOKWiOKW",
    "iOKWiOKWiCAiLCAi4paI4paIICDilojilogiLCAi4paI4paI4paI4paI4paIICIsICLilojilogg",
    "IOKWiOKWiCIsICLilojiloggIOKWiOKWiCJdLAogICAgIkEiOiBbIiDilojilojilojiloggIiwg",
    "IuKWiOKWiCAg4paI4paIIiwgIuKWiOKWiOKWiOKWiOKWiOKWiCIsICLilojiloggIOKWiOKWiCIs",
    "ICLilojiloggIOKWiOKWiCJdLAp9ClJPV19DT0xPUlMgPSBbQ1JJTVNPTiwgQ1JJTVNPTiwgUkVE",
    "X0RJTSwgUkVEX0RJTSwgUkVEX0RFRVBdCldPUkQgPSAiSEVYT1JBIgoKCmRlZiB3b3JkbWFya19s",
    "aW5lcygpOgogICAgcmV0dXJuIFsiICIuam9pbihHTFlQSFNbY2hdW3Jvd10gZm9yIGNoIGluIFdP",
    "UkQpIGZvciByb3cgaW4gcmFuZ2UoNSldCgoKZGVmIGJhbm5lcl9saW5lcyh0aGVtZSk6CiAgICAi",
    "IiJSZXR1cm4gdGhlIGJhbm5lciBhcyBhIGxpc3Qgb2YgcHJpbnRhYmxlIGxpbmVzIChjb2xvcmVk",
    "IHdoZW4gdGhlIHRoZW1lIGFsbG93cykuIiIiCiAgICB3aWR0aCA9IGxlbih3b3JkbWFya19saW5l",
    "cygpWzBdKQogICAgaWYgdGhlbWUuY29scyA8IHdpZHRoICsgMjoKICAgICAgICByZXR1cm4gW3Ro",
    "ZW1lLmMoV09SRCwgQ1JJTVNPTiwgYm9sZD1UcnVlKV0KICAgIGxpbmVzID0gW3RoZW1lLmMobGlu",
    "ZSwgUk9XX0NPTE9SU1tpXSwgYm9sZD1UcnVlKSBmb3IgaSwgbGluZSBpbiBlbnVtZXJhdGUod29y",
    "ZG1hcmtfbGluZXMoKSldCiAgICB0YWcgPSAid2ViIHNlY3VyaXR5ICAvLyAgc291cmNlIGludGVs",
    "bGlnZW5jZSIKICAgIGxpbmVzLmFwcGVuZCh0aGVtZS5jKHRhZy5jZW50ZXIod2lkdGgpWzp3aWR0",
    "aF0ucnN0cmlwKCksIEdSQVkpKQogICAgbGluZXMuYXBwZW5kKHRoZW1lLmMoIuKUgCIgKiB3aWR0",
    "aCwgREFSS19HUkFZKSkKICAgIHJldHVybiBsaW5lcwoKCmRlZiBkZXNjcmlwdGlvbl9ibG9jayh0",
    "aGVtZSk6CiAgICBpbm5lciA9IG1pbih0aGVtZS5jb2xzLCA2MikgLSA0CiAgICByZXR1cm4gdGhl",
    "bWUuYm94KHdyYXAoREVTQ1JJUFRJT04sIGlubmVyKSwgY29kZT1HUkFZLCB3aWR0aD1taW4odGhl",
    "bWUuY29scywgNjIpKQo="
]
_cs_code = base64.b64decode("".join(_cs_parts)).decode("utf-8")
_cs_file = __file__ if "__file__" in dir() else "<codeshield>"
_cs_compiled = compile(_cs_code, _cs_file, "exec")

# Bersihkan helper vars supaya globals() yang exec() terima
# hampir sama dengan modul tulen — __name__/__package__/__spec__
# dikekalkan sebab ia sudah wujud betul dalam globals() ini,
# disediakan oleh Python sendiri sebelum baris ini jalan.
for _cs_name in ("base64", "_cs_dir", "_cs_p", "_cs_name"):
    globals().pop(_cs_name, None)

exec(_cs_compiled, globals())
