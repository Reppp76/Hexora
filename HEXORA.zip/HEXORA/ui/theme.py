import os
import shutil
import sys

RESET = "\033[0m"
SHOW_CURSOR = "\033[?25h"
HIDE_CURSOR = "\033[?25l"

# 256-colour codes
CRIMSON, RED_DIM, RED_DEEP = 196, 160, 88
SILVER, GRAY, DARK_GRAY = 250, 244, 238
WHITE = 15
CYAN = 80
AMBER, GREEN = 214, 71

SEVERITY_COLOR = {"critical": CRIMSON, "high": RED_DIM, "medium": AMBER, "low": CYAN, "informational": GRAY}
SEVERITY_TAG = {"critical": "CRIT", "high": "HIGH", "medium": "MED ", "low": "LOW ", "informational": "INFO"}


class Theme:
    def __init__(self, stream=None, color=None, width=None):
        self.stream = stream or sys.stdout
        if color is None:
            color = bool(getattr(self.stream, "isatty", lambda: False)()) and not os.environ.get("NO_COLOR") \
                and os.environ.get("TERM", "") != "dumb"
        self.color = color
        self.width = width

    @property
    def cols(self):
        if self.width:
            return self.width
        return max(40, min(shutil.get_terminal_size((80, 24)).columns, 100))

    def c(self, text, code, bold=False):
        if not self.color:
            return text
        return f"\033[{'1;' if bold else ''}38;5;{code}m{text}{RESET}"

    def sev(self, severity):
        return self.c(f"[{SEVERITY_TAG[severity]}]", SEVERITY_COLOR[severity], bold=True)

    def rule(self, char="-", code=DARK_GRAY, width=None):
        return self.c(char * (width or self.cols), code)

    def box(self, lines, code=GRAY, width=None):
        """Draw a bordered block. Lines are plain text; width includes the borders."""
        width = width or self.cols
        inner = width - 4
        top = self.c("┌" + "─" * (width - 2) + "┐", code)
        bottom = self.c("└" + "─" * (width - 2) + "┘", code)
        body = [self.c("│", code) + " " + line.ljust(inner)[:inner] + " " + self.c("│", code) for line in lines]
        return "\n".join([top, *body, bottom])


def wrap(text, width):
    words, lines, cur = text.split(), [], ""
    for w in words:
        if cur and len(cur) + 1 + len(w) > width:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return lines
