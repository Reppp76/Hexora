# -*- coding: utf-8 -*-
# CodeShield Encrypted Python — Powered by Repp76
import base64, sys, os

_cs_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in dir() else os.getcwd()
for _cs_p in (_cs_dir, os.getcwd()):
    if _cs_p not in sys.path:
        sys.path.insert(0, _cs_p)

_cs_parts = [
    "aW1wb3J0IHN5cwppbXBvcnQgdGhyZWFkaW5nCmltcG9ydCB0aW1lCgpmcm9tIHVpLnRoZW1lIGlt",
    "cG9ydCBDWUFOLCBHUkFZLCBISURFX0NVUlNPUiwgUkVTRVQsIFNIT1dfQ1VSU09SCgoKY2xhc3Mg",
    "QW5pbWF0b3I6CiAgICAiIiJBbmltYXRpb24gb25seSBydW5zIG9uIGFuIGludGVyYWN0aXZlIHRl",
    "cm1pbmFsIHdpdGggYW5pbWF0aW9uIGVuYWJsZWQ7IG90aGVyd2lzZSBldmVyeXRoaW5nIGlzIHBs",
    "YWluIG91dHB1dC4iIiIKCiAgICBkZWYgX19pbml0X18oc2VsZiwgdGhlbWUsIGVuYWJsZWQ9VHJ1",
    "ZSwgc3BlZWQ9MS4wKToKICAgICAgICBzZWxmLnRoZW1lID0gdGhlbWUKICAgICAgICBzZWxmLmxp",
    "dmUgPSBib29sKGVuYWJsZWQgYW5kIHRoZW1lLmNvbG9yIGFuZCBnZXRhdHRyKHRoZW1lLnN0cmVh",
    "bSwgImlzYXR0eSIsIGxhbWJkYTogRmFsc2UpKCkpCiAgICAgICAgc2VsZi5zcGVlZCA9IG1heCgw",
    "LjEsIHNwZWVkKQoKICAgIGRlZiBwYXVzZShzZWxmLCBzZWNvbmRzKToKICAgICAgICBpZiBzZWxm",
    "LmxpdmU6CiAgICAgICAgICAgIHRpbWUuc2xlZXAoc2Vjb25kcyAvIHNlbGYuc3BlZWQpCgogICAg",
    "ZGVmIHJldmVhbChzZWxmLCBsaW5lcywgZGVsYXk9MC4wNCk6CiAgICAgICAgZm9yIGxpbmUgaW4g",
    "bGluZXM6CiAgICAgICAgICAgIHByaW50KGxpbmUsIGZpbGU9c2VsZi50aGVtZS5zdHJlYW0sIGZs",
    "dXNoPVRydWUpCiAgICAgICAgICAgIHNlbGYucGF1c2UoZGVsYXkpCgogICAgZGVmIHNwaW5uZXIo",
    "c2VsZiwgbGFiZWwpOgogICAgICAgIHJldHVybiBTcGlubmVyKHNlbGYsIGxhYmVsKQoKCmNsYXNz",
    "IFNwaW5uZXI6CiAgICBGUkFNRVMgPSAifC8tXFwiCgogICAgZGVmIF9faW5pdF9fKHNlbGYsIGFu",
    "aW1hdG9yLCBsYWJlbCk6CiAgICAgICAgc2VsZi5hLCBzZWxmLmxhYmVsID0gYW5pbWF0b3IsIGxh",
    "YmVsCiAgICAgICAgc2VsZi5fc3RvcCA9IHRocmVhZGluZy5FdmVudCgpCiAgICAgICAgc2VsZi5f",
    "dGhyZWFkID0gTm9uZQoKICAgIGRlZiBfX2VudGVyX18oc2VsZik6CiAgICAgICAgaWYgc2VsZi5h",
    "LmxpdmU6CiAgICAgICAgICAgIHNlbGYuX3RocmVhZCA9IHRocmVhZGluZy5UaHJlYWQodGFyZ2V0",
    "PXNlbGYuX3NwaW4sIGRhZW1vbj1UcnVlKQogICAgICAgICAgICBzZWxmLl90aHJlYWQuc3RhcnQo",
    "KQogICAgICAgIHJldHVybiBzZWxmCgogICAgZGVmIF9zcGluKHNlbGYpOgogICAgICAgIG91dCwg",
    "aSA9IHNlbGYuYS50aGVtZS5zdHJlYW0sIDAKICAgICAgICBvdXQud3JpdGUoSElERV9DVVJTT1Ip",
    "CiAgICAgICAgd2hpbGUgbm90IHNlbGYuX3N0b3AuaXNfc2V0KCk6CiAgICAgICAgICAgIG91dC53",
    "cml0ZShmIlxye3NlbGYuYS50aGVtZS5jKHNlbGYuRlJBTUVTW2kgJSA0XSwgQ1lBTil9IHtzZWxm",
    "LmEudGhlbWUuYyhzZWxmLmxhYmVsLCBHUkFZKX0iKQogICAgICAgICAgICBvdXQuZmx1c2goKQog",
    "ICAgICAgICAgICBpICs9IDEKICAgICAgICAgICAgdGltZS5zbGVlcCgwLjEgLyBzZWxmLmEuc3Bl",
    "ZWQpCgogICAgZGVmIF9fZXhpdF9fKHNlbGYsICpleGMpOgogICAgICAgIGlmIHNlbGYuX3RocmVh",
    "ZDoKICAgICAgICAgICAgc2VsZi5fc3RvcC5zZXQoKQogICAgICAgICAgICBzZWxmLl90aHJlYWQu",
    "am9pbigpCiAgICAgICAgICAgIG91dCA9IHNlbGYuYS50aGVtZS5zdHJlYW0KICAgICAgICAgICAg",
    "b3V0LndyaXRlKCJcciIgKyAiICIgKiAobGVuKHNlbGYubGFiZWwpICsgNCkgKyAiXHIiICsgU0hP",
    "V19DVVJTT1IgKyBSRVNFVCkKICAgICAgICAgICAgb3V0LmZsdXNoKCkKICAgICAgICByZXR1cm4g",
    "RmFsc2UK"
]
_cs_code = base64.b64decode("".join(_cs_parts)).decode("utf-8")
_cs_file = __file__ if "__file__" in dir() else "<codeshield>"
_cs_compiled = compile(_cs_code, _cs_file, "exec")

# Bersihkan helper vars supaya globals() yang exec() terima
# hampir sama dengan modul tulen — __name__/__package__/__spec__
# dikekalkan sebab ia sudah wujud betul dalam globals() ini,
# disediakan oleh Python sendiri sebelum baris ini jalan.
for _cs_name in ("base64", "_cs_dir", "_cs_p", "_cs_name"):
    globals().pop(_cs_name, None)

exec(_cs_compiled, globals())
