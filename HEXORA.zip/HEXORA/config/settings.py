import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv


def _bool(value, default):
    if value is None or value == "":
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "on")


def _num(value, default, cast=float):
    try:
        return cast(value)
    except (TypeError, ValueError):
        return default


def _list(value):
    return tuple(x.strip().lower() for x in (value or "").split(",") if x.strip())


@dataclass
class Settings:
    telegram_token: str = field(default="", repr=False)
    telegram_chat_id: str = field(default="", repr=False)
    telegram_enabled: bool = True
    telegram_timeout: float = 30.0

    report_dir: str = "reports"
    source_dir: str = "source_exports"
    cache_dir: str = ".hexora_cache"

    request_timeout: float = 15.0
    max_concurrency: int = 5
    rate_limit_per_sec: float = 8.0
    max_requests: int = 600
    max_response_bytes: int = 2_000_000
    user_agent: str = "HEXORA/1.0 (authorized security assessment)"
    verify_tls: bool = True
    trust_env: bool = True

    crawl_depth: int = 2
    crawl_max_pages: int = 25
    source_max_pages: int = 8
    source_max_asset_bytes: int = 1_000_000
    source_max_total_bytes: int = 15_000_000

    # scope
    allow_private: bool = False
    allow_subdomains: bool = False
    extra_hosts: tuple = ()

    # optional, supplied by the authorized operator
    ssrf_callback_url: str = ""
    manifest_paths: tuple = ()
    nvd_api_key: str = field(default="", repr=False)
    nvd_enabled: bool = True

    # threat intelligence for the phishing and spyware checks (keys come from .env only)
    threat_intel_enabled: bool = True
    urlhaus_auth_key: str = field(default="", repr=False)
    phishtank_app_key: str = field(default="", repr=False)
    kit_signatures_path: str = ""

    animation: bool = True
    animation_speed: float = 1.0

    @classmethod
    def from_env(cls, env_file=None):
        if env_file is None:
            env_file = Path(__file__).resolve().parent.parent / ".env"
        if Path(env_file).exists():
            load_dotenv(env_file, override=False)
        e = os.environ.get
        token = e("TELEGRAM_BOT_TOKEN", "")
        chat = e("TELEGRAM_CHAT_ID", "")
        if token.startswith("PASTE_YOUR") or "PASTE_YOUR" in token:
            token = ""
        if chat.startswith("PASTE_YOUR"):
            chat = ""
        return cls(
            telegram_token=token,
            telegram_chat_id=chat,
            telegram_enabled=_bool(e("HEXORA_TELEGRAM_ENABLED"), True),
            telegram_timeout=_num(e("HEXORA_TELEGRAM_TIMEOUT"), 30.0),
            report_dir=e("HEXORA_REPORT_DIRECTORY", "reports"),
            source_dir=e("HEXORA_SOURCE_DIRECTORY", "source_exports"),
            request_timeout=_num(e("HEXORA_REQUEST_TIMEOUT"), 15.0),
            max_concurrency=max(1, _num(e("HEXORA_MAX_CONCURRENCY"), 5, int)),
            rate_limit_per_sec=_num(e("HEXORA_RATE_LIMIT"), 8.0),
            max_requests=_num(e("HEXORA_MAX_REQUESTS"), 600, int),
            verify_tls=_bool(e("HEXORA_VERIFY_TLS"), True),
            crawl_depth=_num(e("HEXORA_CRAWL_DEPTH"), 2, int),
            crawl_max_pages=_num(e("HEXORA_CRAWL_MAX_PAGES"), 25, int),
            allow_private=_bool(e("HEXORA_ALLOW_PRIVATE_TARGETS"), False),
            allow_subdomains=_bool(e("HEXORA_ALLOW_SUBDOMAINS"), False),
            extra_hosts=_list(e("HEXORA_EXTRA_HOSTS")),
            ssrf_callback_url=e("HEXORA_SSRF_CALLBACK_URL", ""),
            manifest_paths=tuple(x.strip() for x in (e("HEXORA_MANIFEST_PATHS") or "").split(",") if x.strip()),
            nvd_api_key=e("NVD_API_KEY", ""),
            nvd_enabled=_bool(e("HEXORA_NVD_ENABLED"), True),
            threat_intel_enabled=_bool(e("HEXORA_THREAT_INTEL_ENABLED"), True),
            urlhaus_auth_key=e("URLHAUS_AUTH_KEY", ""),
            phishtank_app_key=e("PHISHTANK_APP_KEY", ""),
            kit_signatures_path=e("HEXORA_KIT_SIGNATURES", ""),
            animation=_bool(e("HEXORA_ANIMATION_ENABLED"), True),
            animation_speed=_num(e("HEXORA_ANIMATION_SPEED"), 1.0),
        )

    @property
    def telegram_configured(self):
        return bool(self.telegram_token and self.telegram_chat_id)
