import pytest

from core.engine import Engine
from modules import by_option, security_modules


def run(ctx, option):
    return Engine(ctx, None).run_module(by_option(option))


def titles(result):
    return [f.title for f in result.findings]


def test_there_are_sixteen_modules_in_order():
    mods = security_modules()
    assert [m.option for m in mods] == [*range(2, 16), 17, 18] and len({m.key for m in mods}) == 16


@pytest.mark.parametrize("option", [*range(2, 16), 17, 18])
def test_every_module_dispatches_and_returns_standard_result(ctx, option):
    r = run(ctx, option)
    assert r.key == by_option(option).key
    assert r.status in ("completed", "partial", "skipped")  # CVE module is skipped when NVD is disabled
    assert r.duration >= 0 and isinstance(r.findings, list)
    for f in r.findings:
        assert f.module == r.key


def test_injection_finds_sql_error_and_reflection(ctx):
    r = run(ctx, 2)
    t = " ".join(titles(r))
    assert "SQL injection" in t and "XSS" in t
    assert all(f.status == "probable" for f in r.findings)  # never claimed as confirmed
    assert any("command injection" in x.lower() for x in r.tests_not_performed)


def test_fingerprint_detects_tech_with_confidence(ctx):
    r = run(ctx, 3)
    names = {t["technology"]: t for t in r.data["technologies"]}
    assert names["Apache HTTP Server"]["version"] == "2.4.49" and names["PHP"]["version"] == "7.4.3"
    assert all("confidence" in t and "evidence" in t and "needs_verification" in t for t in names.values())


def test_headers_module_reports_weak_headers(ctx):
    t = " ".join(titles(run(ctx, 5)))
    assert "Content-Security-Policy" in t and "X-Content-Type-Options" in t and "HttpOnly" in t


def test_tls_module_reports_plain_http(ctx):
    r = run(ctx, 6)
    assert "not served over HTTPS" in " ".join(titles(r)) and r.tests_not_performed


def test_api_module_cors_docs_and_sensitive_fields(ctx):
    t = " ".join(titles(run(ctx, 7)))
    assert "CORS reflects arbitrary origins with credentials" in t and "API documentation" in t and "sensitive-looking" in t


def test_authentication_flags_cookie_and_plain_login(ctx):
    t = " ".join(titles(run(ctx, 8)))
    assert "PHPSESSID" in t and "plain HTTP" in t


def test_authorization_states_its_limit(ctx):
    r = run(ctx, 9)
    assert any("IDOR" in x for x in r.tests_not_performed)
    assert any(f.status == "potential" for f in r.findings)  # admin path is only ever "potential"


def test_exposure_redacts_secrets_and_flags_files(ctx):
    r = run(ctx, 10)
    t = " ".join(titles(r))
    assert "Environment file" in t and "Git repository" in t and "AWS access key" in t and "Directory listing" in t
    blob = str([f.to_dict() for f in r.findings])
    assert "AKIAHEXORAFIXTURE001" not in blob and "hunter2fixture" not in blob


def test_server_config_methods(ctx):
    t = " ".join(titles(run(ctx, 11)))
    assert "TRACE" in t and "risky HTTP methods" in t


def test_dependencies_flags_old_jquery_only(ctx):
    r = run(ctx, 12)
    assert any("jquery 3.3.1" in x and "CVE-2020-11022" in x for x in titles(r))
    assert all(f.status == "potential" for f in r.findings)


def test_ssrf_never_confirmed_without_callback(ctx):
    r = run(ctx, 13)
    assert r.findings and all(f.status == "potential" for f in r.findings)
    assert any("callback" in x.lower() for x in r.tests_not_performed)


def test_availability_is_inconclusive_not_a_ddos_claim(ctx):
    r = run(ctx, 14)
    assert all(f.status in ("inconclusive", "confirmed") for f in r.findings)
    assert any("DDoS" in x for x in r.limitations)


def test_attack_surface_inventory(ctx):
    r = run(ctx, 15)
    inv = r.data["inventory"]
    assert any(p.endswith("/about") for p in inv["pages"]) and "/api/users" in inv["api_routes_from_javascript"]
    assert "/admin" in inv["robots_disallow"] and inv["forms"]
    assert any(u.endswith("/redirect-bad") for u in inv["discovered_urls"])


def test_cve_module_uses_mocked_nvd_and_marks_matches_potential(ctx, monkeypatch):
    import modules.cve_intelligence as cve
    ctx.settings.nvd_enabled = True
    calls = []

    def fake(settings, cpe, timeout=20):
        calls.append(cpe)
        return {"vulnerabilities": [{"cve": {"id": "CVE-0000-0001", "descriptions": [{"lang": "en", "value": "test"}],
                                             "metrics": {"cvssMetricV31": [{"cvssData": {"baseScore": 9.8, "baseSeverity": "CRITICAL"}}]}}}]}
    monkeypatch.setattr(cve, "fetch_nvd", fake)
    r = run(ctx, 4)
    assert any("apache:http_server:2.4.49" in c for c in calls)
    f = r.findings[0]
    assert f.status == "potential" and f.severity == "high" and f.verification["verified"] is False


def test_cve_module_survives_feed_outage(ctx, monkeypatch):
    import modules.cve_intelligence as cve
    ctx.settings.nvd_enabled = True

    def boom(*a, **k):
        raise ConnectionError("feed down")
    monkeypatch.setattr(cve, "fetch_nvd", boom)
    r = run(ctx, 4)
    assert r.status == "partial" and not r.findings and any("NVD lookup failed" in x for x in r.limitations)


def test_unreachable_target_fails_modules_instead_of_passing(settings):
    from core.context import ScanContext
    from core.scope import parse_target
    c = ScanContext(settings, parse_target("http://127.0.0.1:9/"))
    r = Engine(c, None).run_module(by_option(5))
    assert r.status == "failed" and r.error
