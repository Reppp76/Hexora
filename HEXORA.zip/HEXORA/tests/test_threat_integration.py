import io
import json

import pytest

from config.settings import Settings
from core.engine import Engine
from core.models import ModuleInfo
from integrations.telegram import Delivery
from main import main
from modules import by_option, security_modules
from reporting.terminal_report import render_report, threat_banner
from ui.menu import menu_entries
from ui.theme import Theme


class TG:
    def __init__(self, status="delivered"):
        self.sent, self.status = [], status

    def send_document(self, path, caption=""):
        self.sent.append(path.name)
        return Delivery(path.name, self.status, "ok" if self.status == "delivered" else "boom")


def test_registry_has_sixteen_security_modules_numbered_02_to_15_and_17_18():
    # 02-15 is fourteen modules plus 17 and 18 = sixteen. Option 16 is Get Source Code and is not a security module.
    mods = security_modules()
    assert [m.option for m in mods] == [*range(2, 16), 17, 18] and len(mods) == 16
    assert by_option(16) is None
    assert (by_option(17).key, by_option(18).key) == ("phishing", "spyware")
    assert len({m.key for m in mods}) == 16


def test_original_options_keep_their_modules():
    keys = [m.key for m in security_modules()][:14]
    assert keys[0] == "injection" and keys[3] == "headers" and keys[4] == "tls" and keys[13] == "attack_surface"


def test_menu_numbers_and_titles():
    entries = {n: t for n, t, _ in menu_entries()}
    assert entries[1] == "Full Security Audit" and entries[16] == "Get Source Code"
    assert entries[17] == "Phishing Check" and entries[18] == "Spyware Check" and len(entries) == 18


@pytest.mark.parametrize("option,key,sent", [(17, "phishing", "127.0.0.1_phishing.json"), (18, "spyware", "127.0.0.1_spyware.json")])
def test_single_option_runs_only_that_module_and_sends_only_its_json(ctx, option, key, sent):
    tg = TG()
    out = Engine(ctx, tg).run_option(option)
    assert out.report["scan"]["mode"] == key and [m["module"] for m in out.report["modules"]] == [key]
    assert tg.sent == [sent] and len(out.files) == 1
    assert out.report["findings"] == [] or all(f["module"] == key for f in out.report["findings"])
    assert out.report["modules"][0]["data"]["verdict"]


def test_full_audit_runs_every_module_exactly_once_in_order(ctx, monkeypatch):
    calls = []

    def wrap(info):
        def run(c):
            calls.append(info.key)
            return info.run(c)
        return ModuleInfo(info.option, info.key, info.title, info.description, run)
    wrapped = [wrap(m) for m in security_modules()]
    monkeypatch.setattr("core.engine.security_modules", lambda: wrapped)
    tg = TG()
    out = Engine(ctx, tg).run_option(1)
    assert calls == [m.key for m in wrapped] and calls.count("phishing") == 1 and calls.count("spyware") == 1
    assert calls[-2:] == ["phishing", "spyware"] and len(calls) == 16
    assert tg.sent == ["127.0.0.1.json", "127.0.0.1.html"]
    assert out.report["source_export"]["status"] == "completed"


def test_findings_are_assigned_to_the_right_module(ctx):
    out = Engine(ctx, TG()).run_option(1)
    keys = {m["module"] for m in out.report["modules"]}
    for f in out.report["findings"]:
        assert f["module"] in keys
        if f["category"] in ("phishing", "spyware"):
            assert f["module"] == f["category"]
    # the existing login-form finding categories are not hijacked by the new modules
    assert not any(f["module"] in ("phishing", "spyware") and f["category"] not in ("phishing", "spyware") for f in out.report["findings"])


def test_full_audit_json_contains_the_new_structured_fields(ctx):
    out = Engine(ctx, TG()).run_option(1)
    data = json.loads(out.files[0].read_text(encoding="utf-8"))
    mods = {m["module"]: m for m in data["modules"]}
    for key in ("phishing", "spyware"):
        d = mods[key]["data"]
        for field in ("verdict", "confidence", "risk_level", "data_flows", "destinations", "network_observations", "threat_intelligence",
                      "tests_performed", "tests_not_performed", "limitations", "recommendations", "developer_attribution", "kit_fingerprints", "evidence"):
            assert field in d, (key, field)
    for field in ("product", "report_version", "scan_id", "target", "scan", "summary", "findings", "limitations", "recommendations"):
        assert field in data  # existing schema untouched


def test_earlier_module_failure_does_not_stop_the_new_modules(ctx, monkeypatch):
    def boom(c):
        raise RuntimeError("kaboom")
    patched = [ModuleInfo(m.option, m.key, m.title, m.description, boom if m.key == "injection" else m.run) for m in security_modules()]
    monkeypatch.setattr("core.engine.security_modules", lambda: patched)
    out = Engine(ctx, TG()).run_option(1)
    ran = out.report["scan"]["modules_executed"]
    assert "phishing" in ran and "spyware" in ran and out.report["scan"]["modules_failed"][0]["module"] == "injection"


def test_telegram_failure_keeps_the_local_reports_valid(ctx):
    out = Engine(ctx, TG(status="failed")).run_option(17)
    assert out.deliveries[0].status == "failed"
    assert json.loads(out.files[0].read_text(encoding="utf-8"))["modules"][0]["module"] == "phishing"


def test_unreachable_target_fails_the_new_modules_instead_of_passing(settings):
    from core.context import ScanContext
    from core.scope import parse_target
    c = ScanContext(settings, parse_target("http://127.0.0.1:9/"))
    for opt in (17, 18):
        r = Engine(c, None).run_module(by_option(opt))
        assert r.status == "failed" and r.error


def test_cli_accepts_options_17_and_18_and_rejects_19(tmp_path, fixture_site):
    s = Settings(report_dir=str(tmp_path / "r"), source_dir=str(tmp_path / "s"), cache_dir=str(tmp_path / "c"), allow_private=True,
                 animation=False, telegram_enabled=False, threat_intel_enabled=False)
    out = io.StringIO()
    assert main(["--url", fixture_site, "--authorized", "--option", "17", "--no-animation"], settings=s, stream=out) == 0
    assert "PHISHING CHECK - DETAILS" in out.getvalue() and list((tmp_path / "r").glob("*_phishing.json"))
    out2 = io.StringIO()
    assert main(["--url", fixture_site, "--authorized", "--option", "19", "--no-animation"], settings=s, stream=out2) == 2
    assert "between 1 and 18" in out2.getvalue()


def _report(p=None, s=None):
    mods = []
    for key, v in (("phishing", p), ("spyware", s)):
        if v:
            mods.append({"module": key, "title": key, "status": "completed", "duration_seconds": 0, "tests_performed": [], "tests_not_performed": [],
                         "limitations": [], "error": "", "data": {"verdict": v}})
    return {"modules": mods}


def test_warning_text_matches_the_evidence_level():
    t = Theme(io.StringIO(), color=False)
    text = lambda r: "\n".join(threat_banner(t, r))  # noqa: E731
    assert text(_report("phishing_confirmed")) == "[CRITICAL WARNING] PHISHING ACTIVITY CONFIRMED"
    assert text(_report(s="spyware_confirmed")) == "[CRITICAL WARNING] WEBSITE SPYWARE BEHAVIOR CONFIRMED"
    assert text(_report("phishing_confirmed", "spyware_confirmed")) == "[CRITICAL WARNING] PHISHING AND SPYWARE INDICATORS CONFIRMED"
    for v in ("phishing_probable", "phishing_suspected"):
        assert "CONFIRMED" not in text(_report(v)) and "not confirmed" in text(_report(v))
    for v in ("spyware_probable", "spyware_suspected"):
        assert "CONFIRMED" not in text(_report(s=v)) and "not confirmed" in text(_report(s=v))
    assert text(_report("inconclusive", "no_spyware_indicators_detected")) == ""
    assert "CONFIRMED" not in text(_report("phishing_confirmed", "spyware_probable")).replace("PHISHING ACTIVITY CONFIRMED", "")


def test_terminal_output_for_a_full_audit_stays_narrow_and_has_required_sections(ctx):
    out = Engine(ctx, TG()).run_option(1)
    text = render_report(Theme(io.StringIO(), color=False, width=60), out.report, out.deliveries, out.files)
    for needle in ("PHISHING CHECK - DETAILS", "SPYWARE CHECK - DETAILS", "Verdict", "Developer", "Target IPs", "Tests not performed", "Limitations", "Recommended actions", "Data destinations"):
        assert needle in text
    assert max(len(line) for line in text.splitlines()) <= 100
    assert "<html" not in text.lower() and '"password"' not in text
