import json
import re
from pathlib import Path

import pytest

from bs4 import BeautifulSoup

from core.engine import Engine
from core.exceptions import CollectionError
from core.context import ScanContext
from core.scope import parse_target
from modules import source_collector


@pytest.fixture
def exported(ctx):
    path, manifest = source_collector.collect(ctx)
    return path, manifest, path.read_text(encoding="utf-8")


def test_html_css_js_and_images_are_embedded(exported):
    path, manifest, html = exported
    assert path.name == "127.0.0.1.html"
    soup = BeautifulSoup(html, "html.parser")
    assert soup.title.string == "Fixture Home"
    sources = [s["data-hexora-source"] for s in soup.find_all(["style", "script"], attrs={"data-hexora-source": True})]
    assert any(u.endswith("/static/app.css") for u in sources) and any(u.endswith("/static/app.js") for u in sources)
    assert 'fetch("/api/users")' in html and "fixture app loaded" in html
    assert soup.find("img")["src"].startswith("data:image/png;base64,")
    assert "url(data:image/png;base64," in html  # css url() inlined
    assert ".extra { color: red; }" in html  # @import inlined
    assert not soup.find("link", rel="stylesheet")
    assert any(i["type"] == "css" for i in manifest["embedded"])


def test_missing_and_external_assets_are_listed_not_hidden(exported):
    _, manifest, html = exported
    failed = {i["url"].rsplit("/", 1)[-1]: i["reason"] for i in manifest["not_embedded"]}
    assert failed["missing.png"] == "HTTP 404" and failed["missing.woff2"] == "HTTP 404"
    assert any("cdn.example.invalid" in i["url"] for i in manifest["external_dependencies"])
    assert "https://cdn.example.invalid/external-lib.js" in html  # left untouched, never fetched


def test_manifest_block_is_valid_json_and_honest(exported):
    _, _, html = exported
    raw = re.search(r'<script id="hexora-manifest" type="application/json">(.*?)</script>', html, re.S) or \
        re.search(r'id="hexora-manifest"[^>]*>(.*?)</script>', html, re.S)
    data = json.loads(raw.group(1))
    assert any("No backend source code" in n for n in data["notes"])
    assert "Exported by HEXORA" in html


def test_extra_pages_are_inert_templates(exported):
    _, manifest, html = exported
    assert any(u.endswith("/about") for u in manifest["extra_pages"])
    assert '<template data-hexora-page=' in html


def test_inlined_script_cannot_close_its_own_tag(ctx, monkeypatch):
    from core.http import Resp
    c = source_collector.Collector(ctx)
    evil = Resp(url=ctx.url("/x.js"), status=200, body=b'var s = "</script><b id=pwn>x</b>";')
    evil.headers["content-type"] = "application/javascript"
    monkeypatch.setattr(c, "_fetch", lambda url, kind: evil)
    soup = c.process('<html><body><script src="/x.js"></script></body></html>', ctx.url("/"))
    assert soup.find(id="pwn") is None and len(soup.find_all("script")) == 1
    assert "<\\/script" in str(soup)


def test_unreachable_start_page_raises_instead_of_writing_a_file(settings, tmp_path):
    c = ScanContext(settings, parse_target("http://127.0.0.1:9/"))
    with pytest.raises(CollectionError):
        source_collector.collect(c)
    assert not (tmp_path / "source").exists() or not list((tmp_path / "source").glob("*.html"))


def test_option_16_sends_only_the_html(ctx):
    class TG:
        sent = []

        def send_document(self, path, caption=""):
            self.sent.append(path.name)
            from integrations.telegram import Delivery
            return Delivery(path.name, "delivered", "ok")
    tg = TG()
    out = Engine(ctx, tg).run_option(16)
    assert tg.sent == ["127.0.0.1.html"] and out.report is None and len(out.files) == 1
    report_dir = Path(ctx.settings.report_dir)
    assert not report_dir.exists() or not list(report_dir.glob("*.json"))


def test_option_16_failure_is_reported(settings):
    class TG:
        def send_document(self, *a, **k):
            raise AssertionError("must not upload when nothing was generated")
    out = Engine(ScanContext(settings, parse_target("http://127.0.0.1:9/")), TG()).run_option(16)
    assert out.error and not out.files and not out.deliveries
