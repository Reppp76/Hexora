import json

from core.engine import Engine
from modules import _intel as intel
from modules import by_option, phishing


def run(ctx):
    return Engine(ctx, None).run_module(by_option(17))


def test_normal_login_form_is_not_phishing(scan):
    r = run(scan("/legit"))
    assert r.status == "completed" and r.data["verdict"] == "no_phishing_indicators_detected"
    assert r.data["credential_collection_present"] and not r.findings
    flow = r.data["data_flows"][0]
    assert flow["origin_relation"] == "same_origin" and flow["observation_type"] == "source_reference"


def test_lookalike_login_page_is_probable_and_names_the_brand_not_the_operator(scan):
    r = run(scan("/lookalike", host="paypa1-secure.test"))
    d = r.data
    assert d["verdict"] == "phishing_probable" and d["risk_level"] == "high"
    assert d["impersonated_brand"]["brand"] == "PayPal" and "paypal.com" in d["impersonated_brand"]["official_reference_domains"]
    assert "not the operator" in d["impersonated_brand"]["operator_note"] and d["impersonated_brand"]["alternative_explanations"]
    assert any(x["technique"] == "homograph_or_digit_substitution" for x in d["impersonated_brand"]["domain_similarity"])
    flow = next(f for f in d["data_flows"] if f["destination_hostname"] == "collect.drop-host.example")
    assert flow["origin_relation"] == "cross_origin" and flow["http_method"] == "POST" and flow["observation_type"] == "source_reference"
    assert flow["recipient_attribution"]["ultimate_recipient"].startswith("Unknown") and flow["attribution_limitations"]
    assert all(f.module == "phishing" and f.category == "phishing" for f in r.findings)


def test_external_form_destination_alone_is_not_a_phishing_verdict(scan):
    r = run(scan("/ext-form"))
    assert r.data["verdict"] == "inconclusive"  # one indicator category is not enough
    assert any("collector.example.net" in f.title for f in r.findings)
    assert all(f.status != "confirmed" for f in r.findings)
    dest = next(x for x in r.data["destinations"] if x["hostname"] == "collector.example.net")
    assert dest["observation"] == "referenced_in_source" and dest["payload_inspected"] is False


def test_script_that_serializes_the_form_is_a_static_inference_not_proof(scan):
    r = run(scan("/js-serialize"))
    flow = next(f for f in r.data["data_flows"] if f["destination_hostname"] == "drop.example.org")
    assert flow["observation_type"] == "statically_inferred" and flow["http_method"] == "POST"
    assert flow["data_category"] in ("credentials", "form_fields") and flow["confidence"] in ("medium", "low")
    assert "nothing was sent" in str(r.data["observation_types"]["statically_inferred"])
    assert r.data["verdict"] != "phishing_confirmed"


def test_request_to_local_endpoint_is_same_origin_and_harmless(scan):
    r = run(scan("/local-endpoint"))
    flows = [f for f in r.data["data_flows"] if f["observation_type"] == "statically_inferred"]
    assert flows and all(f["origin_relation"] == "same_origin" for f in flows)
    assert r.data["verdict"] == "no_phishing_indicators_detected"


def test_brand_without_credentials_is_suspected_only_with_a_lookalike_domain(scan):
    plain = run(scan("/brand-only"))
    assert plain.data["verdict"] == "inconclusive" and not plain.data["credential_collection_present"]
    look = run(scan("/brand-only", host="maybank-help.test"))
    assert look.data["verdict"] == "phishing_suspected" and not look.data["credential_collection_present"]
    assert look.data["impersonated_brand"]["brand"] == "Maybank"


def test_legitimate_identity_provider_is_neutral(scan):
    r = run(scan("/idp"))
    assert r.data["verdict"] == "no_phishing_indicators_detected"
    flow = next(f for f in r.data["data_flows"] if f["destination_hostname"] == "login.microsoftonline.com")
    assert flow["destination_class"] == "identity_provider" and flow["origin_relation"] == "cross_origin"


def test_ambiguous_evidence_is_inconclusive(scan):
    r = run(scan("/ambiguous"))
    assert r.data["verdict"] == "inconclusive" and r.data["uncertainty"]
    assert any("not retrieved" in x for x in r.data["limitations"])


def test_unavailable_threat_intelligence_is_a_limitation_not_a_clean_bill(scan, monkeypatch):
    ctx = scan("/legit")
    ctx.settings.threat_intel_enabled = True
    ctx.settings.urlhaus_auth_key = "test-key"
    monkeypatch.setattr(intel, "dns_info", lambda c, h: {"a": ["93.184.216.34"], "aaaa": [], "addresses": ["93.184.216.34"], "error": None, "flags": []})

    def down(*a, **k):
        raise intel.IntelUnavailable("connection refused")
    monkeypatch.setattr(intel, "fetch_phishtank", down)
    monkeypatch.setattr(intel, "fetch_urlhaus", down)
    r = run(ctx)
    results = {(x["source"], x["result"]) for x in r.data["threat_intelligence"]}
    assert results == {("phishtank", "unavailable"), ("urlhaus", "unavailable")}
    assert any("unavailable" in x and "not a clean result" in x or "No verdict was inferred" in x for x in r.data["limitations"])
    assert r.data["verdict"] == "no_phishing_indicators_detected"  # static analysis still ran


def test_verified_phishtank_listing_confirms_and_records_the_source(scan, monkeypatch):
    ctx = scan("/legit")
    ctx.settings.threat_intel_enabled = True
    monkeypatch.setattr(intel, "dns_info", lambda c, h: {"a": ["93.184.216.34"], "aaaa": [], "addresses": ["93.184.216.34"], "error": None, "flags": []})
    monkeypatch.setattr(intel, "fetch_phishtank", lambda s, u, timeout=10: {"results": {"in_database": True, "valid": "y", "verified": "y", "phish_id": 7}})
    monkeypatch.setattr(intel, "fetch_urlhaus", lambda *a, **k: {"query_status": "no_results"})
    r = run(ctx)
    assert r.data["verdict"] == "phishing_confirmed" and r.data["confirmed_by"] == "threat_intelligence"
    hit = next(x for x in r.data["threat_intelligence"] if x["result"] == "match")
    assert hit["source"] == "phishtank" and hit["observed_at"] and hit["record"]["verified"] is True
    assert any(f.status == "confirmed" and f.module == "phishing" for f in r.findings)


def test_unverified_listing_does_not_confirm(scan, monkeypatch):
    ctx = scan("/legit")
    ctx.settings.threat_intel_enabled = True
    monkeypatch.setattr(intel, "dns_info", lambda c, h: {"a": ["93.184.216.34"], "aaaa": [], "addresses": ["93.184.216.34"], "error": None, "flags": []})
    monkeypatch.setattr(intel, "fetch_phishtank", lambda s, u, timeout=10: {"results": {"in_database": True, "valid": "y", "verified": "n"}})
    monkeypatch.setattr(intel, "fetch_urlhaus", lambda *a, **k: {"query_status": "no_results"})
    assert run(ctx).data["verdict"] != "phishing_confirmed"


def test_private_target_is_never_sent_to_third_party_services(scan, monkeypatch):
    ctx = scan("/legit")
    ctx.settings.threat_intel_enabled = True

    def boom(*a, **k):
        raise AssertionError("a private target must not be sent to a threat-intelligence service")
    monkeypatch.setattr(intel, "fetch_phishtank", boom)
    monkeypatch.setattr(intel, "fetch_urlhaus", boom)
    r = run(ctx)
    assert {x["result"] for x in r.data["threat_intelligence"]} == {"skipped"}


def test_network_observations_report_effective_port_ips_and_timestamp(scan, threat_port):
    n = run(scan("/legit")).data["network_observations"]
    assert n["effective_port"] == threat_port and n["explicit_port"] == threat_port and n["scheme"] == "HTTP"
    assert n["dns_a"] == ["127.0.0.1"] and n["observed_at"] and n["hostname"] == "127.0.0.1"


def test_default_ports_are_reported_correctly():
    from core.scope import parse_target
    assert parse_target("http://example.com/").port == 80 and parse_target("https://example.com/").port == 443


def test_domain_similarity_does_not_flag_official_or_unrelated_domains():
    assert phishing.domain_signals("www.paypal.com") == [] and phishing.domain_signals("secure.maybank2u.com.my") == []
    assert phishing.domain_signals("pineapple.com") == [] and phishing.domain_signals("examp1e.com") == []
    assert phishing.domain_signals("paypal.com.evil.example")[0]["technique"] == "brand_in_subdomain"
    assert phishing.domain_signals("xn--pypal-4ve.com")[0]["brand"] == "PayPal"


def test_unknown_developer_is_stated_explicitly(scan):
    dev = run(scan("/legit")).data["developer_attribution"]
    assert dev["identity_statement"] == intel.UNKNOWN_DEVELOPER and dev["not_assessed"]


def test_report_fields_are_present_json_safe_and_secret_free(scan):
    r = run(scan("/lookalike", host="paypa1-secure.test"))
    for key in ("verdict", "confidence", "risk_level", "impersonated_brand", "developer_attribution", "kit_fingerprints", "data_flows", "potential_data_categories",
                "destinations", "network_observations", "threat_intelligence", "evidence", "tests_performed", "tests_not_performed", "limitations", "recommendations"):
        assert key in r.data
    flow_keys = {"source", "data_category", "destination_url", "destination_hostname", "destination_ip_addresses", "destination_port", "protocol", "http_method",
                 "observation_type", "evidence", "confidence", "recipient_attribution", "attribution_limitations"}
    assert all(flow_keys <= set(f) for f in r.data["data_flows"])
    json.dumps(r.data)
