import io
import re

from config.settings import Settings
from main import clear_screen, main, startup
from ui.animations import Animator
from ui.banner import DESCRIPTION, banner_lines, wordmark_lines
from ui.menu import menu_entries, render_menu
from ui.theme import Theme


class FakeTTY(io.StringIO):
    def isatty(self):
        return True


EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿⭐⬆✅]")


def test_startup_clears_terminal_then_shows_banner():
    out = FakeTTY()
    theme = Theme(out, color=True, width=80)
    startup(theme, Animator(theme, enabled=False))
    text = out.getvalue()
    assert text.index("\033[2J") < text.index("█")
    assert text.index("\033[H") < text.index("█")


def test_banner_spells_hexora_and_has_description_block():
    rows = wordmark_lines()
    assert len(rows) == 5 and len(set(len(r) for r in rows)) == 1
    out = FakeTTY()
    theme = Theme(out, color=False, width=80)
    startup(theme, Animator(theme, enabled=False))
    text = out.getvalue()
    assert "┌" in text and "Advanced Website Security Assessment" in text
    assert text.index("█") < text.index("Advanced Website")
    flat = " ".join(text.replace("│", " ").split())
    assert DESCRIPTION in flat


def test_narrow_terminal_falls_back_to_text_wordmark():
    assert banner_lines(Theme(io.StringIO(), color=False, width=40)) == ["HEXORA"]


def test_menu_shows_all_18_options_without_emoji():
    entries = menu_entries()
    assert [n for n, _, _ in entries] == list(range(1, 19))
    assert entries[0][1] == "Full Security Audit" and entries[15][1] == "Get Source Code"
    assert entries[16][1] == "Phishing Check" and entries[17][1] == "Spyware Check"
    text = render_menu(Theme(io.StringIO(), color=False, width=80))
    for n in range(1, 19):
        assert f"{n:02d}" in text
    assert not EMOJI.search(text)


def test_plain_stream_does_not_get_escape_codes():
    out = io.StringIO()
    theme = Theme(out)
    assert not theme.color
    clear_screen(theme)
    startup(theme, Animator(theme, enabled=True))
    assert "\033" not in out.getvalue()


def test_main_rejects_url_without_authorization_flag(tmp_path):
    out = io.StringIO()
    s = Settings(report_dir=str(tmp_path / "r"), source_dir=str(tmp_path / "s"), animation=False)
    code = main(["--url", "https://example.com", "--no-animation"], settings=s, stream=out)
    assert code == 2 and "--authorized" in out.getvalue()


def test_menu_loop_quits_and_validates_input(tmp_path, fixture_site):
    answers = iter([fixture_site, "yes", "99", "abc", "q"])
    out = io.StringIO()
    s = Settings(report_dir=str(tmp_path / "r"), source_dir=str(tmp_path / "s"), allow_private=True, animation=False)
    code = main(["--no-animation"], settings=s, stream=out, read=lambda prompt="": next(answers))
    text = out.getvalue()
    assert code == 0 and "Target accepted" in text and text.count("Enter a number from 1 to 18") == 2


def test_target_prompt_rejects_private_target_by_default(tmp_path):
    out = io.StringIO()
    s = Settings(report_dir=str(tmp_path / "r"), source_dir=str(tmp_path / "s"), allow_private=False, animation=False)
    answers = iter(["http://127.0.0.1:9/", "q"])

    def read(prompt=""):
        try:
            return next(answers)
        except StopIteration:
            raise EOFError

    assert main(["--no-animation"], settings=s, stream=out, read=read) == 130  # EOF ends the session cleanly
    assert "Rejected" in out.getvalue() and "Target accepted" not in out.getvalue()
