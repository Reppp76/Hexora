import shutil
import socket
import ssl
import subprocess
import threading

import pytest

from config.settings import Settings
from core.context import ScanContext
from core.engine import Engine
from core.scope import parse_target
from modules import by_option

pytestmark = pytest.mark.skipif(shutil.which("openssl") is None, reason="openssl CLI not available")


@pytest.fixture
def tls_server(tmp_path):
    key, crt = tmp_path / "k.pem", tmp_path / "c.pem"
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", str(key), "-out", str(crt),
                    "-days", "2", "-subj", "/CN=not-localhost.test"], check=True, capture_output=True)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(crt, key)
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    sock.listen(5)
    stop = threading.Event()

    def serve():
        sock.settimeout(0.2)
        while not stop.is_set():
            try:
                conn, _ = sock.accept()
            except OSError:
                continue
            try:
                with ctx.wrap_socket(conn, server_side=True) as s:
                    s.recv(1024)
                    s.sendall(b"HTTP/1.0 200 OK\r\nContent-Length: 2\r\nContent-Type: text/html\r\n\r\nok")
            except (ssl.SSLError, OSError):
                pass
    t = threading.Thread(target=serve, daemon=True)
    t.start()
    yield sock.getsockname()[1]
    stop.set()
    sock.close()


def test_tls_module_flags_untrusted_certificate(tls_server, tmp_path):
    s = Settings(report_dir=str(tmp_path / "r"), source_dir=str(tmp_path / "s"), allow_private=True,
                 rate_limit_per_sec=500, request_timeout=5, animation=False)
    c = ScanContext(s, parse_target(f"https://127.0.0.1:{tls_server}/"))
    r = Engine(c, None).run_module(by_option(6))
    assert r.status in ("completed", "partial")
    assert any(f.title in ("Certificate failed validation", "Certificate hostname mismatch") and f.status == "confirmed" for f in r.findings)
    assert any("cipher" in t.lower() for t in r.tests_not_performed)  # states what it did not test
