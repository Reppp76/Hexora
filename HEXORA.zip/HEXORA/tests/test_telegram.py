import requests

from config.settings import Settings
from integrations.telegram import MAX_UPLOAD, TelegramClient


class Resp:
    def __init__(self, status, body):
        self.status_code, self._body = status, body

    def json(self):
        if self._body is None:
            raise ValueError("no json")
        return self._body


class FakeSession:
    def __init__(self, *responses):
        self.responses, self.calls = list(responses), []

    def post(self, url, data=None, files=None, timeout=None):
        self.calls.append({"url": url, "data": data, "name": files["document"][0], "timeout": timeout})
        item = self.responses.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


def make(tmp_path, **kw):
    f = tmp_path / "report.json"
    f.write_text("{}")
    s = Settings(telegram_token="123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij", telegram_chat_id="7", **kw)
    return f, s


def client(s, *responses):
    sess = FakeSession(*responses)
    return TelegramClient(s, session=sess, sleep=lambda x: None), sess


def test_missing_configuration_is_reported_not_sent(tmp_path):
    f = tmp_path / "a.json"
    f.write_text("{}")
    for s, status in [(Settings(), "not_configured"), (Settings(telegram_token="t"), "not_configured"),
                      (Settings(telegram_token="t", telegram_chat_id="1", telegram_enabled=False), "disabled")]:
        c, sess = client(s)
        d = c.send_document(f)
        assert d.status == status and not d.delivered and sess.calls == []


def test_success_requires_telegram_ok_true(tmp_path):
    f, s = make(tmp_path)
    c, sess = client(s, Resp(200, {"ok": True}))
    d = c.send_document(f)
    assert d.delivered and sess.calls[0]["name"] == "report.json" and sess.calls[0]["data"]["chat_id"] == "7"
    c, _ = client(s, Resp(200, {"ok": False, "description": "nope"}))
    assert c.send_document(f).status == "failed"


def test_api_error_is_not_retried_and_token_not_leaked(tmp_path):
    f, s = make(tmp_path)
    c, sess = client(s, Resp(401, {"ok": False, "description": "Unauthorized"}))
    d = c.send_document(f)
    assert d.status == "failed" and "401" in d.detail and len(sess.calls) == 1
    assert s.telegram_token not in d.detail


def test_rate_limit_then_success(tmp_path):
    f, s = make(tmp_path)
    c, sess = client(s, Resp(429, {"ok": False, "description": "Too Many Requests", "parameters": {"retry_after": 1}}), Resp(200, {"ok": True}))
    assert c.send_document(f).delivered and len(sess.calls) == 2


def test_network_failures_retry_then_fail_without_token_in_message(tmp_path):
    f, s = make(tmp_path)
    err = requests.exceptions.ConnectionError(f"https://api.telegram.org/bot{s.telegram_token}/sendDocument refused")
    c, sess = client(s, err, err, err)
    d = c.send_document(f)
    assert d.status == "failed" and len(sess.calls) == 3
    assert s.telegram_token not in d.detail and f.exists()


def test_server_error_retries(tmp_path):
    f, s = make(tmp_path)
    c, sess = client(s, Resp(502, None), Resp(200, {"ok": True}))
    assert c.send_document(f).delivered and len(sess.calls) == 2


def test_oversized_file_is_refused_without_uploading(tmp_path, monkeypatch):
    f, s = make(tmp_path)
    monkeypatch.setattr("os.path.getsize", lambda p: MAX_UPLOAD + 1)
    c, sess = client(s)
    d = c.send_document(f)
    assert d.status == "failed" and "50 MB" in d.detail and sess.calls == []
