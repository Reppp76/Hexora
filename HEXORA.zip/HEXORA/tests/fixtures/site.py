"""Local vulnerable-by-design test site. Binds to 127.0.0.1 only and is used only by the test suite."""
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

PNG = bytes.fromhex(
    "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
    "0000000d49444154789c6360f8cfc0f01f0005000201a6d2a5f60000000049454e44ae426082"
)

JQUERY = "/*! jQuery v3.3.1 | (c) JS Foundation and other contributors */\nwindow.jQuery=function(){};\n"
APP_JS = (
    'const apiKey = "AKIAHEXORAFIXTURE001";\n'
    'fetch("/api/users").then(r => r.json());\n'
    'console.log("fixture app loaded");\n'
)
APP_CSS = (
    "@import url(/static/extra.css);\n"
    "body { background: url(/static/bg.png) no-repeat; font-family: sans-serif; }\n"
    "@font-face { font-family: Gone; src: url(/static/missing.woff2); }\n"
)


def home_html(port):
    return f"""<!doctype html>
<html><head><title>Fixture Home</title>
<meta name="generator" content="HexoraTestCMS 1.2.3">
<link rel="stylesheet" href="/static/app.css">
<script src="/static/jquery-3.3.1.min.js"></script>
<script src="https://cdn.example.invalid/external-lib.js"></script>
</head><body>
<h1>Fixture</h1>
<img src="/static/logo.png"><img src="/static/missing.png">
<a href="/about">About</a> <a href="/search?q=hello">Search</a> <a href="/item?id=1">Item</a>
<a href="/redirect-bad">Redirect</a> <a href="/error">Error</a> <a href="/files/">Files</a>
<form action="/search" method="get"><input name="q" type="text"></form>
<form action="/fetch" method="get"><input name="url" type="text"></form>
<form action="/login" method="post"><input name="user"><input name="pw" type="password"></form>
<script src="/static/app.js"></script>
</body></html>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "Apache/2.4.49"
    sys_version = ""
    protocol_version = "HTTP/1.0"

    def log_message(self, *a):
        pass

    def _send(self, status, body, ctype="text/html; charset=utf-8", extra=None):
        data = body if isinstance(body, bytes) else body.encode()
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def do_HEAD(self):
        self.do_GET()

    def do_OPTIONS(self):
        self._send(200, "", extra={"Allow": "GET, POST, OPTIONS, TRACE, PUT"})

    def do_TRACE(self):
        self._send(200, f"TRACE {self.path}\r\n{self.headers}", "message/http")

    def do_POST(self):
        self._send(200, "<html>posted</html>")

    def do_GET(self):
        u = urlsplit(self.path)
        q = parse_qs(u.query)
        path = u.path
        port = self.server.server_address[1]
        if path == "/":
            self._send(200, home_html(port), extra={"X-Powered-By": "PHP/7.4.3", "Set-Cookie": "PHPSESSID=abc123; Path=/"})
        elif path == "/about":
            self._send(200, "<html><head><title>About</title><link rel='stylesheet' href='/static/app.css'></head><body>About us <a href='/'>home</a></body></html>")
        elif path == "/search":
            term = q.get("q", [""])[0]
            self._send(200, f"<html><body>Results for: {term}</body></html>")
        elif path == "/item":
            val = q.get("id", ["1"])[0]
            if "'" in val:
                self._send(500, "<html>You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version</html>")
            else:
                self._send(200, f"<html>Item {val}</html>")
        elif path == "/fetch":
            self._send(200, "<html>fetcher</html>")
        elif path == "/redirect-bad":
            self._send(302, "", extra={"Location": "http://169.254.169.254/latest/meta-data/"})
        elif path == "/error":
            self._send(500, "<pre>Traceback (most recent call last):\n  File \"app.py\", line 1\nValueError</pre>")
        elif path == "/static/app.css":
            self._send(200, APP_CSS, "text/css")
        elif path == "/static/extra.css":
            self._send(200, ".extra { color: red; }", "text/css")
        elif path == "/static/app.js":
            self._send(200, APP_JS, "application/javascript")
        elif path == "/static/jquery-3.3.1.min.js":
            self._send(200, JQUERY, "application/javascript")
        elif path in ("/static/logo.png", "/static/bg.png"):
            self._send(200, PNG, "image/png")
        elif path == "/.env":
            self._send(200, "APP_ENV=production\nDB_PASSWORD=hunter2fixture\n", "text/plain")
        elif path == "/.git/HEAD":
            self._send(200, "ref: refs/heads/main\n", "text/plain")
        elif path == "/robots.txt":
            self._send(200, f"User-agent: *\nDisallow: /admin\nDisallow: /private-backup\nSitemap: http://127.0.0.1:{port}/sitemap.xml\n", "text/plain")
        elif path == "/sitemap.xml":
            self._send(200, f"<?xml version='1.0'?><urlset><url><loc>http://127.0.0.1:{port}/about</loc></url></urlset>", "application/xml")
        elif path == "/api/users":
            origin = self.headers.get("Origin", "")
            extra = {"Access-Control-Allow-Origin": origin, "Access-Control-Allow-Credentials": "true"} if origin else {}
            self._send(200, json.dumps([{"id": 1, "email": "a@example.test", "password_hash": "x"}]), "application/json", extra)
        elif path == "/openapi.json":
            self._send(200, json.dumps({"openapi": "3.0.0", "paths": {}}), "application/json")
        elif path == "/admin":
            self._send(200, "<html><body>Admin panel: manage users</body></html>")
        elif path == "/files/":
            self._send(200, "<html><head><title>Index of /files</title></head><body>listing</body></html>")
        else:
            self._send(404, "<html>not found</html>")


def start(host="127.0.0.1"):
    server = ThreadingHTTPServer((host, 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, f"http://{host}:{server.server_address[1]}"
