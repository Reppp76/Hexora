import pytest

from core.context import ScanContext
from core.exceptions import ScopeError
from core.scope import Scope, check_destination, parse_target, site_name
from reporting.io import safe_filename, write_atomic


@pytest.mark.parametrize("raw", ["", "example.com", "ftp://example.com", "http://", "https://user:pw@example.com", "javascript:alert(1)", "http://exa mple.com"])
def test_rejects_bad_urls(raw):
    with pytest.raises(ScopeError):
        parse_target(raw)


def test_normalizes_url():
    t = parse_target("HTTPS://Example.COM:443/path?a=1#frag")
    assert (t.hostname, t.port, t.url) == ("example.com", 443, "https://example.com/path?a=1")
    assert parse_target("http://example.com").url == "http://example.com/"


@pytest.mark.parametrize("host", ["127.0.0.1", "10.1.2.3", "192.168.0.5", "169.254.169.254", "::1", "172.16.0.1", "100.64.0.1", "0.0.0.0"])
def test_private_and_metadata_blocked_by_default(host):
    with pytest.raises(ScopeError):
        check_destination(host, allow_private=False)


def test_metadata_blocked_even_when_private_allowed():
    with pytest.raises(ScopeError):
        check_destination("169.254.169.254", allow_private=True)
    with pytest.raises(ScopeError):
        check_destination("metadata.google.internal", allow_private=True)


def test_scope_hosts_and_subdomains():
    t = parse_target("https://example.com/")
    s = Scope(t, extra_hosts=["api.partner.test"])
    assert s.host_in_scope("example.com") and s.host_in_scope("www.example.com") and s.host_in_scope("api.partner.test")
    assert not s.host_in_scope("evil.com") and not s.host_in_scope("sub.example.com")
    assert Scope(t, allow_subdomains=True).host_in_scope("sub.example.com")
    with pytest.raises(ScopeError):
        s.check_url("https://evil.com/")


def test_redirect_to_prohibited_destination_is_refused(ctx):
    resp = ctx.client.get(ctx.url("/redirect-bad"))
    assert resp.status == 302 and "169.254.169.254" in resp.blocked and "refused" in resp.blocked
    assert resp.chain == [(ctx.url("/redirect-bad"), 302)]  # the second hop was never requested


def test_redirect_to_metadata_is_refused_even_if_listed_in_scope(settings, fixture_site):
    settings.extra_hosts = ("169.254.169.254",)
    c = ScanContext(settings, parse_target(fixture_site))
    resp = c.client.get(c.url("/redirect-bad"))
    assert resp.status == 302 and "metadata" in resp.blocked


def test_default_settings_refuse_local_fixture(settings, fixture_site):
    settings.allow_private = False
    c = ScanContext(settings, parse_target(fixture_site))
    resp = c.client.get(fixture_site + "/")
    assert not resp.reached and "loopback" in resp.blocked


def test_request_budget(settings, fixture_site):
    settings.max_requests = 2
    c = ScanContext(settings, parse_target(fixture_site))
    c.client.get(c.url("/"))
    c.client.get(c.url("/"))
    from core.exceptions import BudgetExceeded
    with pytest.raises(BudgetExceeded):
        c.client.get(c.url("/"))


def test_filenames_are_sanitized(tmp_path):
    assert ".." not in site_name("exa/../mple.com") and "/" not in site_name("exa/../mple.com")
    assert "/" not in safe_filename("../../etc/passwd", "x", ext="json")
    with pytest.raises(ValueError):
        write_atomic(tmp_path, "../escape.txt", "x")
    assert write_atomic(tmp_path, "ok.txt", "x").read_text() == "x"
