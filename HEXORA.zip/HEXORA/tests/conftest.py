import socket
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from config.settings import Settings  # noqa: E402
from core.context import ScanContext  # noqa: E402
from core.scope import parse_target  # noqa: E402
from fixtures import site, threat_site  # noqa: E402


@pytest.fixture(scope="session")
def fixture_site():
    server, url = site.start()
    yield url
    server.shutdown()


@pytest.fixture
def settings(tmp_path):
    return Settings(
        telegram_token="123456789:FAKE_TOKEN_for_tests_only_abcdefghijkl",
        telegram_chat_id="42",
        report_dir=str(tmp_path / "reports"),
        source_dir=str(tmp_path / "source"),
        cache_dir=str(tmp_path / "cache"),
        allow_private=True,  # the fixture lives on 127.0.0.1
        rate_limit_per_sec=500,
        request_timeout=5,
        nvd_enabled=False,
        threat_intel_enabled=False,  # tests never call out to URLhaus/PhishTank unless they mock it
        animation=False,
    )


@pytest.fixture
def ctx(settings, fixture_site):
    return ScanContext(settings, parse_target(fixture_site + "/"))


@pytest.fixture(scope="session")
def threat_port():
    server, port = threat_site.start()
    yield port
    server.shutdown()


@pytest.fixture
def scan(settings, threat_port, monkeypatch):
    """ScanContext factory for the phishing/spyware pages. Hostnames ending in .test resolve to 127.0.0.1."""
    real = socket.getaddrinfo

    def fake(host, *a, **k):
        return real("127.0.0.1" if str(host).endswith(".test") else host, *a, **k)
    monkeypatch.setattr(socket, "getaddrinfo", fake)

    def make(path, host="127.0.0.1"):
        return ScanContext(settings, parse_target(f"http://{host}:{threat_port}{path}"))
    return make
