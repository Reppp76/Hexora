import io
import json

import pytest

from core.engine import Engine
from core.models import Finding
from core.risk import dedupe
from integrations.telegram import Delivery
from reporting.json_report import report_filename
from reporting.terminal_report import render_report
from ui.theme import Theme


class FakeTelegram:
    def __init__(self, fail_first=False):
        self.sent, self.fail_first = [], fail_first

    def send_document(self, path, caption=""):
        self.sent.append(path.name)
        if self.fail_first and len(self.sent) == 1:
            return Delivery(path.name, "failed", "simulated outage")
        return Delivery(path.name, "delivered", "confirmed by Telegram")


@pytest.fixture
def full(ctx):
    tg = FakeTelegram()
    return Engine(ctx, tg).run_option(1), tg


def test_full_audit_aggregates_all_modules_and_sends_json_then_html(full):
    out, tg = full
    r = out.report
    assert r["scan"]["mode"] == "full_audit"
    keys = [m["module"] for m in r["modules"]]
    assert len(keys) == 16 and "cve_intelligence" in keys
    assert tg.sent == ["127.0.0.1.json", "127.0.0.1.html"]
    assert [d.status for d in out.deliveries] == ["delivered", "delivered"]
    assert r["source_export"]["status"] == "completed"


def test_skipped_modules_are_reported_not_passed(full):
    r = full[0].report
    assert "cve_intelligence" in r["scan"]["modules_skipped"]
    assert "cve_intelligence" not in r["scan"]["modules_executed"]


def test_json_is_valid_and_follows_schema(full):
    out, _ = full
    data = json.loads(out.files[0].read_text(encoding="utf-8"))
    for key in ("product", "report_version", "scan_id", "target", "scan", "summary", "findings", "limitations", "recommendations"):
        assert key in data
    assert data["product"] == "HEXORA" and data["scan"]["status"] in ("completed", "completed_with_findings", "partial", "failed", "cancelled")
    ids = [f["id"] for f in data["findings"]]
    assert ids == sorted(ids) and ids[0] == "HEX-0001" and len(set(ids)) == len(ids)
    for f in data["findings"]:
        assert {"title", "category", "severity", "confidence", "status", "affected_resource", "evidence", "remediation", "verification"} <= set(f)
    s = data["summary"]
    assert sum(s[k] for k in ("critical", "high", "medium", "low", "informational")) == len(data["findings"])


def test_deduplication_across_modules(full):
    titles = [(f["category"], f["title"], f["affected_resource"]) for f in full[0].report["findings"]]
    assert len(titles) == len(set(titles))
    assert sum("PHPSESSID" in t[1] and "HttpOnly" in t[1] for t in titles) == 1  # headers + authentication both report it


def test_dedupe_keeps_strongest_and_merges_evidence():
    a = Finding("T", "c", "low", "low", "potential", "/x", "d", evidence=["one"])
    b = Finding("T", "c", "high", "high", "confirmed", "/x", "d", evidence=["two"])
    out = dedupe([a, b])
    assert len(out) == 1 and out[0].severity == "high" and set(out[0].evidence) == {"one", "two"}


def test_single_module_report_is_isolated_and_only_json_is_sent(ctx):
    tg = FakeTelegram()
    out = Engine(ctx, tg).run_option(5)
    assert tg.sent == ["127.0.0.1_headers.json"] and len(out.files) == 1
    r = out.report
    assert r["scan"]["mode"] == "headers" and [m["module"] for m in r["modules"]] == ["headers"]
    assert {f["category"] for f in r["findings"]} <= {"http_headers", "cookies"}
    assert "source_export" not in r


def test_filenames(ctx):
    assert report_filename(ctx, "full_audit") == "127.0.0.1.json"
    assert report_filename(ctx, "tls", "tls") == "127.0.0.1_tls.json"


def test_json_is_written_even_when_telegram_fails(ctx):
    tg = FakeTelegram(fail_first=True)
    out = Engine(ctx, tg).run_option(1)
    assert out.files[0].exists() and out.files[1].exists()
    assert [d.status for d in out.deliveries] == ["failed", "skipped"]
    assert tg.sent == ["127.0.0.1.json"]  # html is not sent after the JSON upload failed


def test_terminal_report_is_readable_and_not_raw_json(full):
    out, _ = full
    theme = Theme(io.StringIO(), color=False, width=80)
    text = render_report(theme, out.report, out.deliveries, out.files)
    for section in ("ASSESSMENT REPORT", "FINDINGS BY SEVERITY", "MODULES", "TESTS NOT PERFORMED", "TELEGRAM DELIVERY", "OUTPUT FILES", "Scan ID", "Duration"):
        assert section in text
    assert not text.lstrip().startswith("{") and '"findings"' not in text
    assert max(len(line) for line in text.splitlines()) <= 100


def test_secrets_never_reach_reports_or_html(full, settings):
    out, _ = full
    token, chat = settings.telegram_token, settings.telegram_chat_id
    for path in out.files:
        text = path.read_text(encoding="utf-8")
        assert token not in text and token.split(":")[1] not in text
    blob = out.files[0].read_text()
    assert "hunter2fixture" not in blob and "AKIAHEXORAFIXTURE001" not in blob and "abc123" not in blob
    assert chat == "42"
