import json

from core.engine import Engine
from modules import _intel as intel
from modules import by_option


def run(ctx):
    return Engine(ctx, None).run_module(by_option(18))


def caps(r, name):
    return [c for c in r.data["capabilities"] if c["capability"] == name]


def test_geolocation_for_a_declared_feature_is_not_spyware(scan):
    r = run(scan("/geo-declared"))
    assert r.data["verdict"] == "no_spyware_indicators_detected"
    c = caps(r, "geolocation")[0]
    assert c["state"] == "permission_requested" and c["trigger"] == "user_gesture_handler" and c["justified_by_page"] is True
    assert c["observation_basis"] == "static_code" and not c["linked_to_network_call"]


def test_camera_api_reference_without_a_call_is_only_a_capability(scan):
    r = run(scan("/camera-ref"))
    assert r.data["verdict"] == "no_spyware_indicators_detected"
    assert all(c["state"] == "capability_detected" for c in r.data["capabilities"] if c["capability"] == "camera_microphone")
    assert r.data["capability_summary"]["camera_microphone"] == "capability_detected"
    assert "Camera or microphone streams" not in r.data["potential_data_categories"]


def test_permission_request_alone_is_not_spyware(scan):
    r = run(scan("/permission"))
    assert caps(r, "notifications")[0]["state"] == "permission_requested"
    assert r.data["verdict"] == "no_spyware_indicators_detected"


def test_sensitive_access_linked_to_an_outbound_request_is_probable_but_never_observed(scan):
    r = run(scan("/clip-flow"))
    d = r.data
    assert d["verdict"] == "spyware_probable" and d["risk_level"] == "high"
    flow = d["data_flows"][0]
    assert flow["data_category"] == "clipboard_content" and flow["destination_hostname"] == "collector.example.net"
    assert flow["observation_type"] == "statically_inferred" and flow["link_type"] == "tainted_variable" and flow["http_method"] == "POST"
    assert "automatic_trigger" in flow["corroborating_indicators"] and flow["recipient_attribution"]["ultimate_recipient"].startswith("Unknown")
    states = {c["state"] for c in d["capabilities"]}
    assert "outbound_transmission_observed" not in states and "permission_granted_observed" not in states
    assert any("require a running browser" in x for x in d["limitations"])
    assert all(f.module == "spyware" for f in r.findings)


def test_ordinary_analytics_sdk_is_not_spyware(scan):
    r = run(scan("/analytics"))
    assert r.data["verdict"] == "no_spyware_indicators_detected"
    assert any(e["indicator"] == "analytics_sdk" for e in r.data["evidence"])


def test_fingerprinting_cluster_sent_off_site_is_suspected_not_probable(scan):
    r = run(scan("/fingerprint"))
    assert r.data["verdict"] == "spyware_suspected"
    flow = next(f for f in r.data["data_flows"] if f["destination_hostname"] == "fp.example.net")
    assert flow["data_category"] == "browser_fingerprint" and flow["sensitivity"] == "medium"
    assert any(e["indicator"] == "fingerprinting_cluster" for e in r.data["evidence"])


def test_unretrievable_external_script_is_inconclusive(scan):
    r = run(scan("/ext-script"))
    assert r.data["verdict"] == "inconclusive" and r.data["uncertainty"]
    assert r.data["capability_summary"]["camera_microphone"] == "inconclusive"  # absence in retrieved code is not clean
    dest = next(d for d in r.data["destinations"] if d["hostname"] == "cdn.unknown-host.invalid")
    assert "not retrieved" in dest["observation"] and dest["payload_inspected"] is False


def test_obfuscated_code_is_inconclusive_when_nothing_readable_is_found(scan):
    r = run(scan("/obfuscated"))
    assert r.data["verdict"] == "inconclusive" and any(e["indicator"] == "obfuscated_code" for e in r.data["evidence"])


def test_clean_page_reports_not_observed_states(scan):
    r = run(scan("/clean"))
    assert r.data["verdict"] == "no_spyware_indicators_detected"
    assert set(r.data["capability_summary"].values()) == {"not_observed"}


def test_same_script_is_not_enough_to_link_access_and_request(scan):
    ctx = scan("/clean")
    from modules import _clientside as cs
    js = 'navigator.geolocation.getCurrentPosition(function(p){ show(p); });\nfetch("https://x.example.net/ping", {method: "POST", body: "hello"});'
    corpus = cs.Corpus()
    corpus.units = [cs.Unit("inline", "http://a/", "http://a/", js)]
    a = cs.analyze(corpus)
    assert a.accesses and a.sinks and a.links == []  # co-located, but no data dependency


def test_confirmed_requires_a_threat_listing_and_a_correlated_flow(scan, monkeypatch):
    ctx = scan("/clip-flow")
    ctx.settings.threat_intel_enabled = True
    ctx.settings.urlhaus_auth_key = "k"
    monkeypatch.setattr(intel, "dns_info", lambda c, h: {"a": ["93.184.216.34"], "aaaa": [], "addresses": ["93.184.216.34"], "error": None, "flags": []})
    monkeypatch.setattr(intel, "fetch_phishtank", lambda s, u, timeout=10: {"results": {"in_database": False}})
    monkeypatch.setattr(intel, "fetch_urlhaus", lambda s, kind, v, timeout=10: {"query_status": "ok", "url_status": "online", "threat": "malware_download", "tags": ["t"]} if kind == "url" else {"query_status": "no_results"})
    r = run(ctx)
    assert r.data["verdict"] == "spyware_confirmed"
    assert any(c["state"] == "confirmed_malicious_behavior" for c in r.data["capabilities"])
    # the same listing without a correlated flow must not confirm
    ctx2 = scan("/clean")
    ctx2.settings.threat_intel_enabled = True
    assert run(ctx2).data["verdict"] != "spyware_confirmed"


def test_report_fields_are_present_and_json_safe(scan):
    r = run(scan("/clip-flow"))
    for key in ("verdict", "confidence", "risk_level", "developer_attribution", "kit_fingerprints", "data_flows", "potential_data_categories", "destinations",
                "network_observations", "threat_intelligence", "evidence", "tests_performed", "tests_not_performed", "limitations", "recommendations", "capabilities"):
        assert key in r.data
    assert "Clipboard content" in r.data["potential_data_categories"]
    json.dumps(r.data)


def test_secrets_in_scripts_are_not_copied_into_evidence(scan):
    from modules import _clientside as cs
    out = cs.clean('const password = "hunter2-very-secret"; token = "abcdefghijklmnopqrstuvwxyz012345"; a@b.example')
    assert "hunter2" not in out and "abcdefghijklmnop" not in out and "a@b.example" not in out
