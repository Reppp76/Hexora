import io
import logging

import pytest

import modules
from config.settings import Settings
from core.engine import Engine
from core.models import ModuleInfo
from integrations.telegram import Delivery
from main import RedactingFilter, main, restore_terminal
from ui.theme import Theme


class TG:
    def __init__(self):
        self.sent = []

    def send_document(self, path, caption=""):
        self.sent.append(path.name)
        return Delivery(path.name, "delivered", "ok")


def test_crashing_module_becomes_failed_and_audit_continues(ctx, monkeypatch):
    def boom(c):
        raise RuntimeError("kaboom 123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij")
    real = modules.security_modules()
    patched = [ModuleInfo(m.option, m.key, m.title, m.description, boom if m.key == "tls" else m.run) for m in real]
    monkeypatch.setattr("core.engine.security_modules", lambda: patched)
    out = Engine(ctx, TG()).run_option(1)
    r = out.report
    assert r["scan"]["status"] == "partial"
    assert r["scan"]["modules_failed"][0]["module"] == "tls"
    assert "ABCDEFGHIJKLMNOPQRSTUVWXYZ" not in r["scan"]["modules_failed"][0]["error"]
    assert len(r["scan"]["modules_executed"]) >= 12


def test_ctrl_c_during_full_audit_saves_partial_report_and_sends_nothing(ctx, monkeypatch):
    def interrupt(c):
        raise KeyboardInterrupt
    real = modules.security_modules()
    patched = [ModuleInfo(m.option, m.key, m.title, m.description, interrupt if m.key == "exposure" else m.run) for m in real]
    monkeypatch.setattr("core.engine.security_modules", lambda: patched)
    tg = TG()
    out = Engine(ctx, tg).run_option(1)
    assert out.cancelled and tg.sent == [] and out.report["scan"]["status"] == "cancelled"
    assert out.files[0].exists() and "partial report" in out.error


def test_ctrl_c_at_the_menu_restores_terminal_and_exits_cleanly(tmp_path):
    class FakeTTY(io.StringIO):
        def isatty(self):
            return True
    out = FakeTTY()

    def reader(prompt=""):
        raise KeyboardInterrupt
    s = Settings(report_dir=str(tmp_path / "r"), source_dir=str(tmp_path / "s"), animation=False)
    assert main(["--no-animation"], settings=s, stream=out, read=reader) == 130
    assert out.getvalue().endswith("\033[?25h") or "\033[?25h" in out.getvalue()[-30:]


def test_restore_terminal_resets_colors_and_cursor():
    class FakeTTY(io.StringIO):
        def isatty(self):
            return True
    out = FakeTTY()
    restore_terminal(Theme(out, color=True))
    assert out.getvalue() == "\033[0m\033[?25h"


def test_log_filter_redacts_tokens():
    rec = logging.LogRecord("hexora", logging.INFO, "f", 1, "uploading with %s", ("https://api.telegram.org/bot123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij/sendDocument",), None)
    RedactingFilter().filter(rec)
    assert "ABCDEFGHIJKLMNOPQRSTUVWXYZ" not in rec.getMessage()


def test_noninteractive_run_with_option(tmp_path, fixture_site):
    out = io.StringIO()
    s = Settings(report_dir=str(tmp_path / "r"), source_dir=str(tmp_path / "s"), cache_dir=str(tmp_path / "c"),
                 allow_private=True, rate_limit_per_sec=500, animation=False)
    code = main(["--url", fixture_site, "--authorized", "--option", "5", "--no-animation"], settings=s, stream=out)
    text = out.getvalue()
    assert code == 0 and "ASSESSMENT REPORT" in text and "not_configured" in text
    assert (tmp_path / "r" / "127.0.0.1_headers.json").exists()
